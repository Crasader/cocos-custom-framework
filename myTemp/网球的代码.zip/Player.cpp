#include "Player.h"
#define AnimationStand "walk"
#define AnimationWalk "walk"
#define AnimationRun "run"
#define AnimationReadyHit "run"
#define AnimationHit "walk"
#define AnimationReadyServe "walk"
#define AnimationServe "run"
#define AnimationEmbrave "jump"

Player* Player::createWithId(int playerid, int racquetsid, int shoesid)
{
	Player *pRet = new(std::nothrow) Player();
	if (pRet && pRet->initWithId(playerid, racquetsid, shoesid))
	{
		pRet->autorelease();
		return pRet;
	}
	else
	{
		delete pRet;
		pRet = nullptr;
		return nullptr;
	}
}
bool Player::initWithId(int nid, int racquetsid, int shoesid)
{
	if (BillBoard::init())
	{
		m_nplayerani = SkeletonAnimation::createWithJsonFile("spine/spineboy.json", "spine/spineboy.atlas", 0.5f);
		//m_nplayerani = SkeletonAnimation::createWithFile("spine/man1.json", "spine/man1.atlas", 1.0f);
		addChild(m_nplayerani);
		m_nplayerani->setAnimation(0, AnimationStand, true);
		MixPlayerAnimation();


		m_nplayerid = nid;
		m_nracquetsid = racquetsid;
		m_nshoesid = shoesid;
		initWithData();
		auto nlabel = Label::create();
		nlabel->setPosition(Vec2(0, -10));
		nlabel->setSystemFontSize(40);
		nlabel->setString("Player");
		addChild(nlabel);
	}
	return true;
}
void Player::initWithData()
{
	ValueMap *nrolemap = DataManager::shareDataManager()->getRoleDataById(m_nplayerid);
	ValueMap *nshoesmap = DataManager::shareDataManager()->getShoesDataById(m_nshoesid);
	ValueMap *nracquetsmap = DataManager::shareDataManager()->getRacquetsDataById(m_nracquetsid);

	auto& nroleconfig = nrolemap->at("configuration").asValueMap();
	runSpeed = nroleconfig.at("runSpeed").asFloat();
	accuracy = nroleconfig.at("accuracy").asFloat();
	intelligenceLevel = nroleconfig.at("intelligence").asInt();
	if (nshoesmap)
	{
		float naddrun = nshoesmap->at("addrun").asFloat();
		runSpeed += naddrun;
	}
	
	if (nracquetsmap)
	{
		float naddaccuracy = nracquetsmap->at("addaccuracy").asFloat();
		accuracy += naddaccuracy;
	}
	
}
void Player::movetoDestination(Vec3 des)
{
	this->stopAllActions();
	Vec3 npos = getPosition3D();
	float ndis = npos.distance(des);
	auto moveto = MoveTo::create(ndis / runSpeed, des);
	this->runAction(Sequence::create(moveto,
		CallFuncN::create([=](Node*){

	}),
		nullptr));
}
int Player::getIntelligenceLevel()
{
	return intelligenceLevel;
}
float Player::getAccuracy()
{
	return accuracy;
}
void Player::registerEventDispatcher()
{

}
void Player::MixPlayerAnimation()
{
	char* nanimationstr[] = { AnimationStand, AnimationWalk, AnimationRun, AnimationReadyHit, AnimationHit, AnimationReadyServe, AnimationServe, AnimationEmbrave };
	for (int i = 0; i < sizeof(nanimationstr) / sizeof(nanimationstr[0]); i++)
	{
		auto nanimationname1 = nanimationstr[i];
		for (int j = 0; j < sizeof(nanimationstr) / sizeof(nanimationstr[0]); j++)
		{
			if (i != j)
			{
				auto nanimationname2 = nanimationstr[j];
				m_nplayerani->setMix(nanimationname1, nanimationname2, 0.1);
			}
		}
	}
}
Player::~Player()
{

}