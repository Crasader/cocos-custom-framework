#include "ResultView.h"
#include "EventMacro.h"
Node* ResultView::createWithVec(ValueVector vec)
{
    Node *nrootnode = CSLoader::createNode("GameScene/ResultView.csb");
	ResultView *node = new (std::nothrow) ResultView();
	if (node &&  node->initwithWithVec(nrootnode, vec))
	{
		node->setName("SelfClass");
		nrootnode->addChild(node);
		node->autorelease();
		return nrootnode;
	}
	else
	{
		delete node;
		node = nullptr;
		return nullptr;
	}
}
bool ResultView::initwithWithVec(Node *node, ValueVector vec)
{
    m_nrootnode = node;
	auto nisselfwin = vec.at(0).asBool();
	auto  nResult_Text = static_cast<Text*>(UiManager::GetChildByName(m_nrootnode, "Result_Text"));
	if (nisselfwin)
	{
		nResult_Text->setText("Congratulations, You Win");

	}
	else
	{
		nResult_Text->setText("Sorry, You Lost");
	}

	auto  nRePlay_Button = static_cast<Button*>(UiManager::GetChildByName(m_nrootnode, "RePlay_Button"));
	nRePlay_Button->addClickEventListener([=](Ref* sender) {
		UiManager::CloseUI();
		EventCustom event1(Event_RePlayGame);
		_eventDispatcher->dispatchEvent(&event1);
	});
	auto  nMainScene_Button = static_cast<Button*>(UiManager::GetChildByName(m_nrootnode, "MainScene_Button"));
	nMainScene_Button->addClickEventListener([=](Ref* sender) {
		UiManager::CloseUI();
		EventCustom event1(Event_RePlayGame);
		_eventDispatcher->dispatchEvent(&event1);
	});
	setUpUIWithData();
    return true;
}
void ResultView::setUpUIWithData()
{
	
}
float ResultView::activeAction()
{
	
	return 0;
}
void ResultView::ShowCallback()
{

}
void ResultView::onEnter()
{

}
void ResultView::onEnterTransitionDidFinish()
{
	
}
void ResultView::onExitTransitionDidStart()
{

}
void ResultView::onExit()
{

}
void ResultView::cleanup()
{

}
void ResultView::CloseCallBack()
{
	
}