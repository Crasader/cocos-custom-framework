#include "SceneDressing.h"
#include "SceneManager.h"
#include "Resources.h"
#include "UiManager.h"
#include "PublicHead.h"
#include "c2d/ChainView.h"
#include "DataManager.h"

SCENE_IMPLEMENT_INFO(eSceneDressing, SceneDressing)


SceneDressing::~SceneDressing()
{
	_vBtns.clear();
}
Scene* SceneDressing::createScene()
{
    auto scene = Scene::create();
    auto layer = SceneDressing::create();
    scene->addChild(layer);
    return scene;
}

bool SceneDressing::init()
{
	if (!BaseScene::init(csb_SceneDressing))
	{
		return false;
	}

	//scheduleUpdate();
	initUI();
    return true;
}

void SceneDressing::initUI()
{

	auto btnPlus = setBtnClickListener("btnPlus", [=](Ref* sender){

	});

	auto btnClose = setBtnClickListener("btnClose", [=](Ref* sender){
		SceneManager::getInstance()->replaceScene(eSceneMain);
	});
	auto rButton_Role = getChildByPath<Button*>("Button_Role");
	auto rButton_Racket = getChildByPath<Button*>("Button_Racket");
	auto rButton_Shoe = getChildByPath<Button*>("Button_Shoe");
	_pImage_Check = getChildByPath<ImageView*>("Image_Check");
	_vBtns.pushBack(rButton_Role);
	_vBtns.pushBack(rButton_Racket);
	_vBtns.pushBack(rButton_Shoe);
	

	//��Ӧ��Ļ
	adaptScreen("Title_DressingRoom", c2d::Align::left);
	adaptScreen("icoMoney", c2d::Align::right);
	adaptScreen("M01", c2d::Align::right);

	UiManager::adaptScreen(btnClose, c2d::Align::right);
	UiManager::adaptScreen(btnPlus, c2d::Align::right);

	for (auto btn : _vBtns)
	{
		UiManager::adaptScreen(btn, c2d::Align::left);
		btn->addClickEventListener(CC_CALLBACK_1(SceneDressing::DressTypeBtnCallback,this));
	}
	UiManager::adaptScreen(_pImage_Check, c2d::Align::left);


	//ChainView
	auto Panel_ = UiManager::GetChildByName(_pRoot, "Panel_");
	_pChainView = ChainView::create();
	_pChainView->setContentSize(Panel_->getContentSize());
	_pChainView->setBounceEnabled(true);
	_pChainView->setDirection(ScrollView::Direction::HORIZONTAL);
	_pChainView->setClippingEnabled(false);
	_pChainView->setMinScale(0.85f);
	_pChainView->setItemsMargin(-20);

	auto GoodsItem = CSLoader::createNode(csb_GoodsItem);
	auto Panel = UiManager::GetChildByName<Layout*>(GoodsItem, "Panel");
	_pChainView->setItemModel(Panel);

	_pChainView->setOnChangeCurItemIndexListener([=](Ref* sender, int index){
		auto rPreviousItemIndex = _pChainView->getPreviousItemIndex();


		if (rPreviousItemIndex != index){
			if (rPreviousItemIndex != -1){
				auto previousItem = _pChainView->getItem(rPreviousItemIndex);
				auto previousCheckImage = previousItem->getChildByName("CheckImage");
				previousCheckImage->setVisible(false);
			}


			auto curItem = static_cast<Widget*>(sender);
			auto curCheckImage = curItem->getChildByName("CheckImage");
			curCheckImage->setVisible(true);
		}
	});
	Panel_->addChild(_pChainView);


	//���ж�������֮�� ���� ��ɫ ѡ��
	DressTypeBtnCallback(rButton_Role);
}

void SceneDressing::DressTypeBtnCallback(Ref* sender)
{
	auto rClickBtn = static_cast<Button*>(sender);
	auto name = rClickBtn->getName();
	_pImage_Check->setPosition(rClickBtn->getPosition());
	for (auto btn : _vBtns)
	{
		btn->setHighlighted(rClickBtn == btn);
	}

	if (StringUtil::findStr(name,"Role")){
		changeDressType(DressType::eDressRole);
		
	}
	else if (StringUtil::findStr(name, "Racket")){
		changeDressType(DressType::eDressRacket);
	}
	else if (StringUtil::findStr(name, "Shoe")){
		changeDressType(DressType::eDressShoe);
	}

}

void SceneDressing::changeDressType(DressType rDressType)
{
	if (_pCurDressType == rDressType)return;
	_pCurDressType = rDressType;
	auto rDataManager = DataManager::getInstance();
	ValueMap* rShopDataSet = nullptr;
	std::string resPath = "";

	switch (rDressType)
	{
	case SceneDressing::DressType::eDressRole:
		rShopDataSet = rDataManager->getTableDataAsValueMapByName(json_Role);
		resPath = "AllPicRes/Role/";
		break;
	case SceneDressing::DressType::eDressRacket:
		rShopDataSet = rDataManager->getTableDataAsValueMapByName(json_Racquets);
		resPath = "AllPicRes/Racket/";
		break;
	case SceneDressing::DressType::eDressShoe:
		rShopDataSet = rDataManager->getTableDataAsValueMapByName(json_Shoes);
		resPath = "AllPicRes/Shoe/";
		break;
	default:
		break;
	}
	//��������е� Item
	_pChainView->removeAllItems();
	//_pChainView->show(0);
	//�������
	for (int i = 0; i < rShopDataSet->size(); i++)
	{
		int index = i + 1;
		_pChainView->addItem();
		//��ȡjson����
		std::string resFullPath = "";
		auto rDataSet = rShopDataSet->at(StringUtil::toString(index).c_str()).asValueMap();
		auto rName = rDataSet.at("Name").asString();
		
		if (rDressType == DressType::eDressRole){
			auto rRoleResID = rDataSet.at("RoleResID").asInt();
			auto rGender = rDataSet.at("Gender").asString();
			resFullPath = StringUtils::format("%s%sHalfBody%d.png", resPath.c_str(), rGender.c_str(), rRoleResID);
		}
		else{
			auto rImgName = rDataSet.at("ImgName").asString();
			resFullPath = StringUtils::format("%s%s", resPath.c_str(), rImgName.c_str());
		}
		
		//��ȡ Widget
		auto _layout = static_cast<Layout*>(_pChainView->getChildren().back());
		auto rShowImage = static_cast<ImageView*>(_layout->getChildByName("ShowImage"));
		auto curCheckImage = _layout->getChildByName("CheckImage");

		//�滻
		_layout->setName(rName);
		rShowImage->setUnifySizeEnabled(true);
		rShowImage->loadTexture(resFullPath, cocos2d::ui::Widget::TextureResType::PLIST);
		curCheckImage->setVisible(false);


		_layout->addClickEventListener([=](Ref* sender){
			auto obj = static_cast<Layout*>(sender);
			if (_pChainView->isCheckItem(obj)){//ѡ�� �ĵ������

			}
			else{//������ѡ�е� Item ��
				_pChainView->scrollToItem(obj);
			}
		});
	}

	_pChainView->show(2);
}

