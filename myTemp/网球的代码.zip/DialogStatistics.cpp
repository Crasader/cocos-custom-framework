#include "DialogStatistics.h"
#include "EventMacro.h"

DIALOG_IMPLEMENT_INFO("GameScene/StatisticsView.csb", DialogStatistics)

void DialogStatistics::onCloseCallback()
{
	EventCustom event1(Event_ContinueGame);
	_eventDispatcher->dispatchEvent(&event1);
}

bool DialogStatistics::initWithNoParam()
{
	 setBtnClickListener("Continue_Button", [=](Ref* sender){
	 		close();
	 	});
	return true;
}
