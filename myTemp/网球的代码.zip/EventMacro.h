//
//  EventMacro.h

#ifndef _EventMacro_h
#define _EventMacro_h

#define Event_TimeUpdate "Event_TimeUpdate"
#define Event_FaultViewClose "Event_FaultViewClose"
#define Event_ScoreViewClose "Event_ScoreViewClose"
#define Event_ContinueGame "Event_ContinueGame"
#define Event_RePlayGame "Event_RePlayGame"
#define Event_UpdateScore "Event_UpdateScore"
#endif
