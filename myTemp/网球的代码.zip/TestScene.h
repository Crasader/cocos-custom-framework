#ifndef __TestScene_SCENE_H__
#define __TestScene_SCENE_H__

#include "cocos2d.h"

class TestScene : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
	
	virtual void testDataLoad();

	virtual void DataThreadCall(int threadId);
    
    CREATE_FUNC(TestScene);


	std::vector<std::string> files;
};

#endif // __TestScene_SCENE_H__
