﻿//
//  DataManager.h

#ifndef __DataManager__
#define __DataManager__
#include "c2d/DataLoader.h"
#include "DataStruct.h"
class DataManager :public DataLoader
{
public:
	static DataManager* shareDataManager();
	static DataManager* getInstance();
	bool init();
	
	virtual cocos2d::Value getValue(const cocos2d::ValueMap& setData, int id);
	virtual bool hasKey(const ValueMap& map, const std::string &key);

	//获取指定表数据接口
	ValueVector* getTableDataAsValueVectorByName(const string& filename);
	ValueMap* getTableDataAsValueMapByName(const string& filename);

	ValueMap* getRoleDataById(int roleid);
	ValueMap* getShoesDataById(int Shoesid);
	ValueMap* getRacquetsDataById(int Racquetsid);

};
#endif /* defined(__DataManager__) */
