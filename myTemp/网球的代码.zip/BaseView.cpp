#include "BaseView.h"
float BaseView::activeAction()
{
	CCLOG("BaseView::activeAction");
	return 0;
}
float BaseView::getActiveDuration()
{
	CCLOG("BaseView::getactionduration");
	return 0;
}
void BaseView::ShowCallback()
{

}
float BaseView::closeAction()
{
	CCLOG("BaseView::getactionduration");
	return 0;
}
float BaseView::getCloseDuration()
{
	CCLOG("BaseView::getCloseDuration");
	return 0;
}
void BaseView::CloseCallBack()
{
    CCLOG("BaseView::CloseCallBack");
}