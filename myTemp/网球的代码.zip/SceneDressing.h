#ifndef __SceneDressing_H__
#define __SceneDressing_H__

#include "c2d/BaseScene.h"

class ChainView;
class SceneDressing : public BaseScene
{
public:
	enum class DressType
	{
		eDressRole,
		eDressRacket,
		eDressShoe,
	};
public:
	~SceneDressing();
	SCENE_REGISTER_INFO
    static Scene* createScene();
    virtual bool init();
    CREATE_FUNC(SceneDressing);
	
protected:
	virtual void initUI();
	virtual void changeDressType(DressType rDressType);
	virtual void DressTypeBtnCallback(Ref* sender);
private:
	ChainView* _pChainView = nullptr;
	DressType _pCurDressType;

	ImageView* _pImage_Check = nullptr;
	Vector<Button*> _vBtns;
};

#endif /* defined(__SceneDressing_H__) */
