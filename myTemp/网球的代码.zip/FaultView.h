#ifndef __FaultView_H__
#define __FaultView_H__
#include "BaseView.h"
#include "UiManager.h"
class FaultView :public BaseView
{
public:
    static Node* createWithVec(ValueVector vec);
    bool initwithWithVec(Node *node,ValueVector vec);
    void setUpUIWithData();
	virtual float activeAction();
	virtual void ShowCallback();
	void onEnter();
	void onEnterTransitionDidFinish();
	void onExitTransitionDidStart();
	void onExit();
	void cleanup();
	virtual void CloseCallBack();
protected:
    Node *m_nrootnode;
	Text *m_nFault_Text;
};

#endif // __FaultView_H__
