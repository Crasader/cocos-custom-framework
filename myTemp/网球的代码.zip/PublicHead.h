
#ifndef _PublicHead_h
#define _PublicHead_h

#include "PublicCoco.h"
 
#include "c2d/Actions.h"
#include "c2d/KeysAgent.h"
#include "c2d/StringUtil.h"
#include "c2d/C2DUtils.h" 
#include "c2d/SpineRect.h"  
#include "VisibleRect.h"
#include "c2d/DataLoader.h"

#endif
