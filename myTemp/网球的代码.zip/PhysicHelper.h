#ifndef _Physic_Helper__
#define _Physic_Helper__

#include "cocos2d.h"
#include "Macro.h"
#include "3d/CCTerrain.h"
#include "3d/CCBundle3D.h"
#include "physics3d/CCPhysics3D.h"
#include "physics3d/CCPhysics3DObject.h"

class PhysicHelper
{
public:
	static PhysicsSprite3D* createPhysicBox(Vec3 size, float mass,Vec3 pos,string texturepath);
	static PhysicsSprite3D* createPhysicSphere(float radius, float mass, Vec3 pos, string texturepath);

};

#endif /* defined(_Physic_Helper__) */
