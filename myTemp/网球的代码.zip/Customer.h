#ifndef __CUSTOMER_H__
#define __CUSTOMER_H__
#include "cocos2d.h"
#include "Macro.h"
#include "UiManager.h"
#include "DataManager.h"
#include "CommonMethod.h"
class Customer: public Node
{
public:
	static Customer* createWithId(int shopid, int chapterid, int roleid, ValueVector demondvec);
	bool initWithId(int shopid, int chapterid, int roleid, ValueVector demondvec);
	void setAdditionAttri(int waitTime, int tipTime, int tipNum);
	void registerEventDispatcher();
	void activeWithDestination(Vec2 point);
	Rect getcustomerWorldRect();
	bool receiveFood(int foodid);
	//void addupStatisticsFood(int foodid);
	void setPayCallback(const NumCallback& callback);
	void setLeaveCallback(const ccMenuCallback& callback);
	ValueVector * getDemondFood();
	void popOutDemond();
	float popInDemond(float time = 0.0);
	void updateRoleStatus(float dt);
	void payAndLeave(bool immediately = false,float delaytime = 0.0 );
	void pauseCustomer();
	void resumeCustomer();
	void MixCustomerAnimation();
	int getRoleId();
	~Customer();
protected:
	Node *m_nnrootnode;
	SkeletonAnimation * m_nrole;
	ImageView *m_nDemandBg_Image;
	LoadingBar *m_nWait_LoadingBar;
	Layout* m_nFood_Panel;
    int m_nshopid;
	int m_nchapterid;
	int m_nroleid;
	bool m_nactivestatus;
	bool m_ntimeout;
	int m_nwaitTime;//���ȴ�ʱ��
	int m_ntipTime;//���С��ʱ��
	int m_nmaxTip;//���С������
	int m_naddwaitTime;
	int m_naddtipTime;
	int m_naddtipNum;
	int m_nspeed;
	int m_ncurwaitTime;//��ǰ�ȴ�ʱ��
	int m_ncurtipnum;//��ǰС�ѽ��
	int m_npayNum;//��ǰӦ�����
	int m_nbaseNum;//ʳ�Ļ����۸�
	string m_ncuranimationname;//��ǰ��������
	ValueVector m_ndemondVec;//�����ʳ��ID����
	ValueVector * m_nAnimationVec;//��ɫ�����б�
	Vector<ImageView *> m_ndemondimgvec;
	NumCallback m_npaycallback;
	ccMenuCallback m_nleavecallback;
};

#endif // __CUSTOMER_H__
