#ifndef __SceneMain_H__
#define __SceneMain_H__

#include "c2d/BaseScene.h"

class ChainView;
class SceneMain : public BaseScene
{
public:
	SCENE_REGISTER_INFO
    static Scene* createScene();
    virtual bool init();
    CREATE_FUNC(SceneMain);
	
protected:
	virtual void initUI();
	virtual void initChainView();
	virtual void onEntranceListener(Layout* node);
private:
	ChainView* _pChainView = nullptr;
};

#endif /* defined(__SceneMain_H__) */
