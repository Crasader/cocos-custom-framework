﻿//
//  Macro.h

#ifndef _Common_Macro_h
#define _Common_Macro_h
#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include "cocostudio/CocoStudio.h"
#include "spine/spine.h"
#include <spine/spine-cocos2dx.h>
#include <vector>
#include<map>
#include <iostream>
#include<string>
#include<cstring>
#include "audio/include/AudioEngine.h"
#include <stdlib.h>

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#include "../platform/android/jni/JniHelper.h"
#include <jni.h>
#include <android/log.h>
#define JniLOGD(...) __android_log_print(ANDROID_LOG_ERROR,"cocos2d-x", __VA_ARGS__)
#endif

USING_NS_CC;
using namespace cocos2d::ui;
using namespace spine;
using namespace cocos2d::experimental;
using namespace std;
using namespace cocostudio::timeline;
using namespace cocos2d;

#define WINSIZE CCDirector::sharedDirector()->getWinSize()

#define _debug 1
#define Invaild_VaLue -1
#define DesignWidth 1536
#define DesignHeight 768
#define FallSpeed 3000

typedef enum{
	TMainScene = 0,
	TGameScene = 1,
}SCENEID;
#define PI 3.1415
#define ShopNum 12
#define ReAdCost 300

typedef std::function<void(SkeletonAnimation*)>ShopCallBack;
typedef std::function<float(Ref* ref,int,int,int,int)> NumCallback;
typedef std::vector<CallFuncN *> CallFuncNVector;

#endif
