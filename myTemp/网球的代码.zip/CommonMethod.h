#ifndef _Common__Method__
#define _Common__Method__

#include "cocos2d.h"
#include "Macro.h"
#include "DataManager.h"

#define CCLOGPOINT(str,point) cocos2d::log("%s x = %f, y = %f",str ,point.x,point.y)

typedef enum{
	Shake_FD = 0,//ҡ�ڶ���
	
} CommonAction;

class CommonMethod
{
public:

	static float getForce(float velocity, float ballradius);
	static Vec2 GetDistance(Vec2 npoint1, Vec2 npoint2);
	static float GetDistanceInPoints(Vec2 npoint1, Vec2 npoint2);
	static float getTriangularLength(float side1, float side2);
	static float GetDegreesInPoints(Vec2 npoint1, Vec2 npoint2);
	static void SetRandomSeed();
	static int getRand(int nstart, int nend);
	static Rect getWorldBoundingBox(Node *node);
	static Vec2 getWorldPoint(Node * node);
	static Vec2 getInNodePoint(Node *ncurparentnode, Vec2 npoint, Node* ndesnode);
	static void PlayfoodPickAction(Node *node, float scale,Node *originnode = nullptr);
	static void PlayShake(Node *node, int times = -1, float rate = 0.1, int swing = 20,int delay=0, CallFuncN * callback = nullptr);
	static void PlayPopOutAndIn(Node *node, int times = -1,float rate=0.5, float swing=1.3);
    static void ShowUIWithAnimation(Node *sender,const ccMenuCallback& callback);
    static void HidUIWithAnimation(Node *sender,const ccMenuCallback& callback);
    static ActionInterval *GetActionByIndex(int nindex);
	static int PlayVoice(string nstr, bool nloop, float nvolume = 1.0f);
	static void SendJavaEvent(int eventcode);
	static void SendJavaString(char * nstr);
	static void ProLoadvoiceEffect();
	static void ShowWarning(const char * nwarningstr);
	static void ShowWavePrompt(const char * nstr);
	static void ShowWaveNumPrompt(const char * nstr,Node* parentnode,Vec2 worldpoint);
	static void showShieldLayer(Node *node);
	static void drawDebug(Node* root);
	static void drawDebugCircle(Node* root, float radius);
	static void drawDebugAll(Node* root);
	static void convSpriteGray(Sprite* node);
	static void convSpriteNormal(Sprite* node);
	static void convImageViewGray(ImageView* node);
	static void convImageViewNormal(ImageView* node);
	static ClippingNode* drawRoundRect(Node* newNode, float radius, unsigned int segments);//����Բ�Ǿ���
};

#endif /* defined(_Common__Method__) */
