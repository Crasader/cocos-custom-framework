#include "SceneMain.h"
#include "SceneManager.h"
#include "Resources.h"
#include "UiManager.h"
#include "PublicHead.h"
#include "c2d/ChainView.h"
#include "DataManager.h"

SCENE_IMPLEMENT_INFO(eSceneMain, SceneMain)

Scene* SceneMain::createScene()
{
    auto scene = Scene::create();
    auto layer = SceneMain::create();
    scene->addChild(layer);
    return scene;
}

bool SceneMain::init()
{
	if (!BaseScene::init(csb_SceneMain))
	{
		return false;
	}

	//scheduleUpdate();
	initUI();
	initChainView();
    return true;
}

void SceneMain::initUI()
{
	auto btnPlus = setBtnClickListener("btnPlus", [=](Ref* sender){
	});

	auto btnSet = setBtnClickListener("btnSet", [=](Ref* sender){
		DialogHelper::ShowUI("GameScene/StatisticsView.csb");
	});
	auto btnVideo = setBtnClickListener("btnVideo", [=](Ref* sender){
	});

	auto btnShare = setBtnClickListener("btnShare", [=](Ref* sender){
	});

	auto btnReward = setBtnClickListener("btnReward", [=](Ref* sender){
	});

	auto btnIntegral = setBtnClickListener("btnIntegral", [=](Ref* sender){
	});
	
	auto btnAchievement = setBtnClickListener("btnAchievement", [=](Ref* sender){
	});

	UiManager::adaptScreen(btnSet, c2d::Align::right);
	UiManager::adaptScreen(btnVideo, c2d::Align::right);
	UiManager::adaptScreen(btnShare, c2d::Align::right);
	UiManager::adaptScreen(btnReward, c2d::Align::right);
	UiManager::adaptScreen(btnIntegral, c2d::Align::right);
	UiManager::adaptScreen(btnAchievement, c2d::Align::right);

	UiManager::adaptScreen(btnPlus, c2d::Align::left);
	adaptScreen("HeadPortrait", c2d::Align::left);
	adaptScreen("icoMoney", c2d::Align::left);
	adaptScreen("M01", c2d::Align::left);
}

void SceneMain::initChainView()
{
	auto rDataManager = DataManager::getInstance();
	auto rEntranceData = rDataManager->getTableDataAsValueMapByName(json_Entrances);

	auto Panel_ = UiManager::GetChildByName(_pRoot, "Panel_");
	_pChainView = ChainView::create();
	_pChainView->setContentSize(Panel_->getContentSize());
	_pChainView->setBounceEnabled(true);
	_pChainView->setDirection(ScrollView::Direction::HORIZONTAL);
	_pChainView->setClippingEnabled(false);
	_pChainView->setMinScale(0.85f);
	_pChainView->setItemsMargin(-20);


	auto EntranceItem = CSLoader::createNode(csb_EntranceItem);
	auto Panel = UiManager::GetChildByName<Layout*>(EntranceItem, "Panel");

	_pChainView->setItemModel(Panel);

	for (int i = 0; i < rEntranceData->size(); i++)
	{
		_pChainView->addItem();
		auto rDataSet = rEntranceData->at(StringUtil::toString(i).c_str()).asValueMap();
		auto rName = rDataSet.at("Name").asString();
		auto rTitle = rDataSet.at("TitleImg").asString();
		auto rImgName = rDataSet.at("NameImg").asString();


		auto _layout = static_cast<Layout*>(_pChainView->getChildren().back());
		auto rTitleImage = static_cast<ImageView*>(_layout->getChildByName("TitleImage"));
		auto rShowImage = static_cast<ImageView*>(_layout->getChildByName("ShowImage"));
		

		_layout->setName(rName);
		rTitleImage->loadTexture(StringUtils::format("AllPicRes/SceneMain/%s", rTitle.c_str()), cocos2d::ui::Widget::TextureResType::PLIST);
		rShowImage->loadTexture(StringUtils::format("AllPicRes/SceneMain/%s", rImgName.c_str()), cocos2d::ui::Widget::TextureResType::PLIST);


		auto curCheckImage = _layout->getChildByName("CheckImage");
		curCheckImage->setVisible(false);

		_layout->addClickEventListener([=](Ref* sender){
			auto obj = static_cast<Layout*>(sender);
			if (_pChainView->isCheckItem(obj)){

				onEntranceListener(obj);

			}
			else{
				_pChainView->scrollToItem(obj);
			}
		});
	}

	_pChainView->setOnChangeCurItemIndexListener([=](Ref* sender, int index){
		auto rPreviousItemIndex = _pChainView->getPreviousItemIndex();


		if (rPreviousItemIndex != index){
			if (rPreviousItemIndex != -1){
				auto previousItem = _pChainView->getItem(rPreviousItemIndex);
				auto previousCheckImage = previousItem->getChildByName("CheckImage");
				previousCheckImage->setVisible(false);
			}
			

			auto curItem = static_cast<Widget*>(sender);
			auto curCheckImage = curItem->getChildByName("CheckImage");
			curCheckImage->setVisible(true);
		}
	});
	_pChainView->show(2);
	Panel_->addChild(_pChainView);
}

void SceneMain::onEntranceListener(Layout* node)
{
	auto name = node->getName();
	if (name == "Dressing"){
		SceneManager::getInstance()->replaceScene(eSceneDressing);
	}
	else if (name == "Practice"){

	}
	else if (name == "KingLines"){

	}
	else if (name == "OpenGame_Australian"){

	}
	else if (name == "OpenGame_French"){

	}
	else if (name == "OpenGame_Wimbledon"){

	}
	else if (name == "OpenGame_US"){

	}
}
