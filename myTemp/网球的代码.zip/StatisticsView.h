#ifndef __StatisticsView_H__
#define __StatisticsView_H__
#include "BaseView.h"
#include "UiManager.h"
class StatisticsView :public BaseView
{
public:
    static Node* createWithVec(ValueVector vec);
    bool initwithWithVec(Node *node,ValueVector vec);
    void setUpUIWithData();
	virtual float activeAction();
	virtual void ShowCallback();
	void onEnter();
	void onEnterTransitionDidFinish();
	void onExitTransitionDidStart();
	void onExit();
	void cleanup();
	virtual void CloseCallBack();
protected:
    Node *m_nrootnode;
};

#endif // __PauseView_H__
