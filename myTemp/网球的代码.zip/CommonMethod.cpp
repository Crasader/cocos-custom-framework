//
//  CommonMethod.cpp


#include "CommonMethod.h"
float CommonMethod::getForce(float velocity,float ballradius)
{
	if (velocity==0)
	{
		return 0;
	}
	
	float nforce = (1.0 / 2)*1.0*1.293 * 4 * PI*ballradius*pow(velocity, 2);
	nforce *= -fabs(velocity) / velocity;
	return nforce;
}
Vec2 CommonMethod::GetDistance(Vec2 npoint1, Vec2 npoint2)
{
	return Vec2(npoint2.x-npoint1.x,npoint2.y-npoint1.y);
}
float CommonMethod::GetDistanceInPoints(Vec2 npoint1, Vec2 npoint2)
{
	float x = npoint2.x - npoint1.x;
	float y = npoint2.y - npoint1.y;
	return sqrt(x*x + y*y);
}
float CommonMethod::getTriangularLength(float side1, float side2)
{
	return sqrt(side1*side1 + side2*side2);
}
float CommonMethod::GetDegreesInPoints(Vec2 npoint1, Vec2 npoint2)
{
	float c = GetDistanceInPoints(npoint1, npoint2);
	float a = GetDistanceInPoints(Vec2(0,0), npoint1);
	float b = GetDistanceInPoints(Vec2(0, 0), npoint2);
	if (a==0||b==0)
	{
		return 0;
	}
	
	return acos((b*b + a*a - c*c) / (2 * b*a))*2.0;
}

void CommonMethod::SetRandomSeed()
{
	struct timeval psv;
	gettimeofday(&psv, NULL);
	unsigned long int rand_seed = psv.tv_sec * 1000 + psv.tv_usec / 1000;
	srand(rand_seed);
}
int CommonMethod::getRand(int start, int end)
{
	float i = CCRANDOM_0_1()*(end - start+1) + start;  //����һ����start��end��������  
	if (i>end)
	{
		i = end;
	}
	
	return (int)i;
}
Rect CommonMethod::getWorldBoundingBox(Node *node)
{
	Rect nrect = node->boundingBox();
	nrect.origin = node->getParent()->convertToWorldSpace(nrect.origin);
	return nrect;
}
Vec2 CommonMethod::getWorldPoint(Node * node)
{
	return node->getParent()->convertToWorldSpace(node->getPosition());
}
Vec2 CommonMethod::getInNodePoint(Node *ncurparentnode, Vec2 npoint, Node* ndesnode)
{
	Vec2 nworldpoint = ncurparentnode->convertToWorldSpace(npoint);
	return ndesnode->convertToNodeSpace(nworldpoint);
}
void CommonMethod::PlayfoodPickAction(Node *node, float scale,Node *originnode)
{
	float nscale = 0.1;
	if (originnode)
	{
		nscale = originnode->boundingBox().size.width / node->boundingBox().size.width;
	}
	node->setScale(nscale);
	node->runAction(Sequence::create(ScaleTo::create(0.1, scale),
		ScaleTo::create(0.05, scale-0.09),
		ScaleTo::create(0.05, scale),
		nullptr));

}
void CommonMethod::PlayShake(Node *node, int times, float rate, int swing,int delay,CallFuncN * callback)
{
	auto nRotate1 = RotateTo::create(rate, swing);
	auto nRotate2 = RotateTo::create(rate, 0);
	auto nRotate3 = RotateTo::create(rate, -swing);
	auto nRotate4 = RotateTo::create(rate, 0);
	auto nSeq = Sequence::create(nRotate1, nRotate2, nRotate3, nRotate4, NULL);
	if (times>0)
	{
		auto action = Repeat::create(nSeq, times);
		node->runAction(Sequence::create(action, DelayTime::create(delay), callback,nullptr));
	}
	else
	{
		auto nrepeatforver = RepeatForever::create(nSeq);
		node->runAction(nrepeatforver);
	}
}
void CommonMethod::PlayPopOutAndIn(Node *node, int times, float rate, float swing)
{
	auto nscale1 = ScaleTo::create(rate, swing);
	auto nscale2 = ScaleTo::create(rate, 1.0);
	auto nscale3 = ScaleTo::create(rate, swing);
	auto nscale4 = ScaleTo::create(rate, 1.0);
	auto nSeq = Sequence::create(nscale1, nscale2, nscale3, nscale4, NULL);
	if (times > 0)
	{
		auto action = Repeat::create(nSeq, times);
		node->runAction(action);
	}
	else
	{
		auto nrepeatforver = RepeatForever::create(nSeq);
		node->runAction(nrepeatforver);
	}
}
void CommonMethod::ShowUIWithAnimation(Node *sender,const ccMenuCallback& callback)
{
    sender->setOpacity(0.0);
    sender->setScale(0.0);
    auto spawn = Spawn::create(CallFuncN::create(callback),FadeIn::create(0.16),ScaleTo::create(0.16, 1.0), NULL);
    
    sender->runAction(spawn);
    
}
void CommonMethod::HidUIWithAnimation(Node *sender,const ccMenuCallback& callback)
{
    auto spawn = Spawn::create(FadeOut::create(0.16),ScaleTo::create(0.16, 0.0), NULL);
    auto action = Sequence::create(
                                   spawn,
                                   CallFuncN::create(callback),
                                   nullptr);
    
    sender->runAction(action);
}
ActionInterval *CommonMethod::GetActionByIndex(int nindex)
{
   
    if(nindex ==0)
    {
        auto nRotate1 = RotateTo::create(0.2,20);
        auto nRotate2 = RotateTo::create(0.2,0);
        auto nRotate3 = RotateTo::create(0.2, -20);
        auto nRotate4 = RotateTo::create(0.2, 0);
        auto nSeq = Sequence::create(nRotate1,nRotate2,nRotate3,nRotate4, NULL);
        auto nRep = RepeatForever::create(nSeq);
        return nRep;
    }
    else if(nindex ==1)
    {
        auto nDelay = DelayTime::create(0.5);
        auto nFade1 = FadeTo::create(0.5, 50);
        auto nFade2 = FadeTo::create(0.5, 255);
        auto nSeq = Sequence::create(nDelay,nFade1,nFade2, NULL);
        auto nRep = RepeatForever::create(nSeq);
        return nRep; 
    }
    else if(nindex ==2)
    {
		auto nRotate = RotateBy::create(1.0, 360);
		auto nRep = RepeatForever::create(nRotate);
		return nRep;
    }
    return NULL;
    
}
int CommonMethod::PlayVoice(string nstr, bool nloop,float nvolume)
{
	bool nMusicOn = UserDefault::getInstance()->getBoolForKey("MusicOn", true);
	if (nMusicOn)
	{
		if (nstr != "~")
		{
			int nAudioID = AudioEngine::play2d(StringUtils::format("%s.ogg", nstr.c_str()).c_str(), nloop, nvolume);
			return nAudioID;
		}
	}
	return Invaild_VaLue;
}

void CommonMethod::SendJavaEvent(int eventcode)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	JniMethodInfo minfo;                         //����Jni������Ϣ�ṹ�� //getStaticMethodInfo �κ�������һ��boolֵ��ʾ�Ƿ��ҵ��˺���
	bool isHave = JniHelper::getStaticMethodInfo(minfo,
		"com/lhyy/childrencook/MainActivity", "ShowAll", "(I)V");
	if (!isHave)
	{
		CCLog("jni:�˺���������");
	}
	else
	{
		CCLog("jni:�˺�������");
		//���ô˺���
		minfo.env->CallStaticVoidMethod(minfo.classID, minfo.methodID, eventcode);
	}
	CCLog("jni-java����ִ�����");
#endif
}
void CommonMethod::SendJavaString(char * nstr)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	JniMethodInfo minfo;                         //����Jni������Ϣ�ṹ�� //getStaticMethodInfo �κ�������һ��boolֵ��ʾ�Ƿ��ҵ��˺���
	bool isHave = JniHelper::getStaticMethodInfo(minfo,
		"org/cocos2dx/cpp/AppActivity", "myprint", "(C)V");
	if (!isHave)
	{
		CCLog("jni:�˺���������");
	}
	else
	{
		CCLog("jni:�˺�������");
		//���ô˺���
		minfo.env->CallStaticVoidMethod(minfo.classID, minfo.methodID, nstr);
	}
	CCLog("jni-java����ִ�����");
#endif
}
void CommonMethod::ProLoadvoiceEffect()
{
	/*ValueVector* eledata = DataManager::shareDataManager()->GetElementDataVector();
	for (int i = 0; i < eledata->size(); ++i)
	{
	ValueMap rootmap = eledata->at(i).asValueMap();
	string nvoicename = rootmap["voice1"].asString();
	SimpleAudioEngine::getInstance()->preloadEffect(StringUtils::format("%s.ogg", nvoicename.c_str()).c_str());
	}*/

}
void CommonMethod::ShowWarning(const char * nwarningstr)
{
#ifdef _debug
    MessageBox(nwarningstr, "error");
#endif 

}
void CommonMethod::ShowWavePrompt(const char * nstr)
{
#ifdef _debug
	auto nscene = Director::getInstance()->getRunningScene();
	auto ntext = Text::create(nstr,"Fonts/zh/describe.ttf",36);
	ntext->setTextColor(Color4B(0, 0, 0, 255));
	ntext->setPosition(Vec2(DesignWidth / 2.0, DesignHeight / 2.0));
	nscene->addChild(ntext);
	ntext->runAction(Sequence::create(
									MoveBy::create(2.0, Vec2(0, 500)),
									CallFuncN::create([=](Node *node){
										node->removeFromParent();
										}),
									nullptr));


#endif 

}
void CommonMethod::ShowWaveNumPrompt(const char * nstr, Node* parentnode, Vec2 worldpoint)
{
	//setNumProperty("Number/figure4.png", 17, 19, "+");
	auto numlabel = TextAtlas::create(nstr, "Number/figure5.png", 22, 25, "+");
	Vec2 nodepoint = parentnode->convertToNodeSpace(worldpoint);
	numlabel->setPosition(nodepoint);
	//numlabel->setColor(Color3B(255, 0, 0));
	parentnode->addChild(numlabel);
	numlabel->setScale(0.8);
	auto nspawn1 = Spawn::createWithTwoActions(MoveTo::create(0.3, nodepoint + Vec2(0, 75)),
		ScaleTo::create(0.5, 1.0));
	//auto nspawn2 = Spawn::createWithTwoActions(MoveTo::create(0.1, nodepoint + Vec2(0, 180)),
	//	FadeOut::create(0.1));
	
	numlabel->runAction(Sequence::create(
		nspawn1,
		DelayTime::create(0.1),
		FadeOut::create(0.2),
		CallFuncN::create([=](Node *node){
		node->removeFromParent();
	}),
		nullptr
		));
}
void CommonMethod::showShieldLayer(Node *node)
{
	auto nshield = Layout::create();
	nshield->setTouchEnabled(true);
	nshield->setSize(Size(DesignWidth, DesignHeight));
	nshield->setPosition(Vec2(0, 0));
	nshield->setAnchorPoint(Vec2(0, 0));
	node->addChild(nshield);
}
void CommonMethod::drawDebug(Node* root)
{
	DrawNode* drawNode = DrawNode::create();
	root->addChild(drawNode);
	Vec2 point[4];
	Rect nrect = root->boundingBox();
	point[0] = Vec2(0, 0);
	point[1] = Vec2(0, nrect.size.height);
	point[2] = Vec2(nrect.size.width, nrect.size.height);
	point[3] = Vec2(nrect.size.width, 0);
	drawNode->drawPolygon(point, 4, Color4F(1, 0, 0, 0), 1, Color4F(0, 1, 0, 1));

}
void CommonMethod::drawDebugCircle(Node* root, float radius)
{
	DrawNode* drawNode = DrawNode::create();
	root->addChild(drawNode);
	Vec2 point[4];
	Rect nrect = root->boundingBox();
	point[0] = Vec2(0, 0);
	point[1] = Vec2(0, nrect.size.height);
	point[2] = Vec2(nrect.size.width, nrect.size.height);
	point[3] = Vec2(nrect.size.width, 0);
	//drawNode->drawPolygon(point, 4, Color4F(1, 0, 0, 0), 1, Color4F(0, 1, 0, 1));
	drawNode->drawCircle(Vec2(0, 0), radius,0,30,false,Color4F(255,0,0,1));
}
void CommonMethod::drawDebugAll(Node* root)
{

	if (root->getChildrenCount() > 0){
		for (Node* node : root->getChildren())
		{
			drawDebugAll(node);
		}
	}

	drawDebug(root);
}

void CommonMethod::convSpriteGray(Sprite* node)
{
	GLProgramState *glState = nullptr;
	auto program = GLProgram::createWithByteArrays(ccPositionTextureColor_noMVP_vert,
		ccPositionTexture_GrayScale_frag);
	glState = GLProgramState::getOrCreateWithGLProgram(program);
	node->setGLProgramState(glState);
}

void CommonMethod::convSpriteNormal(Sprite* node)
{
	GLProgramState *glState = GLProgramState::getOrCreateWithGLProgramName("ShaderPositionTextureColor_noMVP");
	glState->setUniformTexture("u_texture", node->getTexture()->getName());
	glState->getGLProgram()->updateUniforms();
	node->setGLProgramState(glState);
}

void CommonMethod::convImageViewGray(ImageView* iv)
{
	((cocos2d::ui::Scale9Sprite*)(iv->getVirtualRenderer()))->setState(cocos2d::ui::Scale9Sprite::State::GRAY);
}

void CommonMethod::convImageViewNormal(ImageView* iv)
{
	((cocos2d::ui::Scale9Sprite*)(iv->getVirtualRenderer()))->setState(cocos2d::ui::Scale9Sprite::State::NORMAL);
}
ClippingNode* CommonMethod::drawRoundRect(Node* newNode, float radius, unsigned int segments)
{
	Point origin = newNode->getPosition();
	Point destination = Point(newNode->getPosition().x + newNode->getContentSize().width, newNode->getPosition().y + newNode->getContentSize().height);

	ClippingNode* pClip = ClippingNode::create();

	pClip->setInverted(false);//�����Ƿ��򣬽�������������Բ��͸���Ļ��Ǻ�ɫ��  
	pClip->setAnchorPoint(Point(0, 0));

	//���1/4Բ  
	const float coef = 0.5f * (float)M_PI / segments;
	Point * vertices = new Point[segments + 1];
	Point * thisVertices = vertices;
	for (unsigned int i = 0; i <= segments; ++i, ++thisVertices)
	{
		float rads = (segments - i)*coef;
		thisVertices->x = (int)(radius * sinf(rads));
		thisVertices->y = (int)(radius * cosf(rads));
	}
	//  
	Point tagCenter;
	float minX = MIN(origin.x, destination.x);
	float maxX = MAX(origin.x, destination.x);
	float minY = MIN(origin.y, destination.y);
	float maxY = MAX(origin.y, destination.y);

	unsigned int dwPolygonPtMax = (segments + 1) * 4;
	Point * pPolygonPtArr = new Point[dwPolygonPtMax];
	Point * thisPolygonPt = pPolygonPtArr;
	int aa = 0;
	//���Ͻ�  
	tagCenter.x = minX + radius;
	tagCenter.y = maxY - radius;
	thisVertices = vertices;
	for (unsigned int i = 0; i <= segments; ++i, ++thisPolygonPt, ++thisVertices)
	{
		thisPolygonPt->x = tagCenter.x - thisVertices->x;
		thisPolygonPt->y = tagCenter.y + thisVertices->y;
		// log("%f , %f", thisPolygonPt->x, thisPolygonPt->y);  
		++aa;
	}
	//���Ͻ�  
	tagCenter.x = maxX - radius;
	tagCenter.y = maxY - radius;
	thisVertices = vertices + segments;
	for (unsigned int i = 0; i <= segments; ++i, ++thisPolygonPt, --thisVertices)
	{
		thisPolygonPt->x = tagCenter.x + thisVertices->x;
		thisPolygonPt->y = tagCenter.y + thisVertices->y;
		// log("%f , %f", thisPolygonPt->x, thisPolygonPt->y);  
		++aa;
	}
	//���½�  
	tagCenter.x = maxX - radius;
	tagCenter.y = minY + radius;
	thisVertices = vertices;
	for (unsigned int i = 0; i <= segments; ++i, ++thisPolygonPt, ++thisVertices)
	{
		thisPolygonPt->x = tagCenter.x + thisVertices->x;
		thisPolygonPt->y = tagCenter.y - thisVertices->y;
		// log("%f , %f", thisPolygonPt->x, thisPolygonPt->y);  
		++aa;
	}
	//���½�  
	tagCenter.x = minX + radius;
	tagCenter.y = minY + radius;
	thisVertices = vertices + segments;
	for (unsigned int i = 0; i <= segments; ++i, ++thisPolygonPt, --thisVertices)
	{
		thisPolygonPt->x = tagCenter.x - thisVertices->x;
		thisPolygonPt->y = tagCenter.y - thisVertices->y;
		// log("%f , %f", thisPolygonPt->x, thisPolygonPt->y);  
		++aa;
	}

	//���ò���  
	static Color4F red(1, 0, 0, 1);//������ɫ����Ϊ��ɫ��������R,G,B,͸����  

	//ע�ⲻҪ��pStencil addChild  
	DrawNode *pStencil = DrawNode::create();
	pStencil->drawPolygon(pPolygonPtArr, dwPolygonPtMax, red, 0, red);//������������  

	pStencil->setPosition(Point(0, 0));

	pClip->setStencil(pStencil);

	pClip->addChild(newNode, 1);
	pClip->setContentSize(newNode->getContentSize());

	CC_SAFE_DELETE_ARRAY(vertices);
	CC_SAFE_DELETE_ARRAY(pPolygonPtArr);

	return pClip;
}