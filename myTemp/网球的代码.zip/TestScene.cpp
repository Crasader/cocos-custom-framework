#include "TestScene.h"
#include "PublicCoco.h"
#include "VisibleRect.h"
#include "DataManager.h"
#include "c2d/StringUtil.h"
#include "PublicDefine.h"
USING_NS_CC;



Scene* TestScene::createScene()
{
    return TestScene::create();
}

// on "init" you need to initialize your instance
bool TestScene::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }
    
	


    return true;
}

void TestScene::testDataLoad()
{


	files = StringUtil::getFileTxtFiles("res/Data/Test", "file.txt");
	for (auto filename : files)
	{
		DELOG(__FILE__, __LINE__, "filename-> %s", filename.c_str());
	}


	long start = utils::getTimeInMilliseconds();


	for (int i = 0; i < 5; i++)
	{
		std::thread nthread(&TestScene::DataThreadCall, this, i);//����һ����֧�̣߳��ص���myThread������
		nthread.detach();
		//nthread.join();


		// 		int unx = files.size() / 5;
		// 
		// 		int beginId = unx * i;
		// 		int total = unx;
		// 
		// 		for (int j = beginId; j < beginId + total; j++)
		// 		{
		// 			if (j >= files.size()){
		// 				break;
		// 			}
		// 
		// 			auto filename = files.at(j);
		// 			DELOG(__FILE__, __LINE__, "filename-> %s", filename.c_str());
		// 
		// 			DataManager::getInstance()->readDataFromFile(filename.c_str());
		// 		}
	}

	long end = utils::getTimeInMilliseconds();
	DELOG(__FILE__, __LINE__, "the time is -> %d", (end - start));


}

void TestScene::DataThreadCall(int threadId)
{
	int unx = files.size() / 5;

	int beginId = unx * threadId;
	int total = unx;

	long start = utils::getTimeInMilliseconds();

	for (int j = beginId; j < beginId + total; j++)
	{
		if (j >= files.size()){
			break;
		}
		auto filename = files.at(j);
		DataManager::getInstance()->readDataFromFile(filename.c_str());
		DELOG(__FILE__, __LINE__, "threadCall filename-> %s  threadId -> %d", filename.c_str(), threadId);
	}

	long end = utils::getTimeInMilliseconds();
	DELOG(__FILE__, __LINE__, "the time is -> %d", (end - start));
	DELOG(__FILE__, __LINE__, "-------------------------------------> %d", threadId);
}
