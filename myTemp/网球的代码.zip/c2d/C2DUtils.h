// # ifndef __C2DUTILS__
// # define __C2DUTILS__
// 
// # include "PublicCoco.h"
// #include "Align.h"
// 
// using namespace cocos2d::c2d;
// 
// class C2DUtils
// {
// public :
// 	
// 	static void touchMove(Widget * node);
// 	static bool adaptScreen(Node * node, Align align);
// 	static bool adaptScreen(Node * node);
// 	static void adaptScene(Node* sceneLayer);
// 
// 	static void adaptScreen(Node* parent, const std::string& childPath);
// 	static void adaptScreenChildren(Node*node, const std::string& nodePath);
// 	static Node* getChildByPath(Node* root, const std::string& path);
// 
// 	//�ѽڵ���ΪͼƬ�������
// 	static bool saveNodeAsPng(Node* node, std::function<void(RenderTexture*, const std::string&)> callback = nullptr);
// 	/// <summary>
// 	/// Intersections the specified node1.
// 	/// node1 �� node2 �Ƿ��ཻ
// 	static bool intersection(Node* node1, Node*node2);
// 	
// 	static void drawDebug(Node* root, Color4F color = Color4F(0, 1, 0, 1));
// 	static void drawDebugAll(Node* root, Color4F color = Color4F(0, 1, 0, 1));
// 	static void drawDebugSpine(Node* root, Color4F color = Color4F(0, 1, 0, 1));
// 	static DrawNode* getDrawNode(Rect rect, Color4F color = Color4F(0, 1, 0, 1));
// 	static void setCameraMask(Node* root, Node* node);
// 	static bool is_element_in_vector(vector<int> v, int element);
// 	static void setSafeAnchor(Node* node,float anchorX, float anchorY);
// 
// 
// 	static Vec2 GetDistance(Vec2 npoint1, Vec2 npoint2);
// 	static void SetRandomSeed();
// 	static int getRand(int nstart, int nend);
// 	static float getRandFloat(float nstart, float nend);
// 	static bool getRandomBool();
// 	static Point getRectCenter(Rect rect);
// 
// 	static Rect getWorldBoundingBox(Node *node);
// 	static Vec2 getWorldPoint(Node * node);
// 	static Vec2 getInNodePoint(Node *ncurparentnode, Vec2 npoint, Node* ndesnode);
// 
// 	static bool safeReleaseRef(Ref *pRef);
// 
// 	static RenderTexture* createRenderTexture(Size size);
// 	static Image* createImageFromSprite(Sprite *pSpr);
// 	static Sprite* createSprite(Sprite* rModel, Sprite* fore);
// 
// 	//ʹ�õѿ�������ϵ
// 	static Color4B getColor4B(Image* rImage, int x, int y);
// 	static Color4B getColor4B(Image* rImage, Point rPoint);
// 	
// 	static bool isRenderTextureClearInRect(Image* image, Rect rext);// ʹ�õѿ�������ϵ ĳ�������Ƿ���ȫ����  
// 	static bool isRenderTextureClear(Image* image);//�Ƿ���ȫ����  
// 
// 	static std::vector<Rect> splitRect(Size root,int rows,int cols);
// 	
// 	static float getDurationFromSpeed(Node* self, Node* target, float speed);
// 	static float getDurationFromSpeed(const Point& self, const Point& target, float speed);
// 
// 	static long getCurrentTime();
// private:
// 	
// 
// };
// 
// 
// # endif