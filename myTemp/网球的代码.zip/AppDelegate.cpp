#include "AppDelegate.h"
#include "LoadingScene.h"
#include "GameScene.h"
#include "HelloWorldScene.h"
#include "TestScene.h"
#include "SceneManager.h"
USING_NS_CC;

AppDelegate::AppDelegate() {

}

AppDelegate::~AppDelegate() 
{
}

//if you want a different context,just modify the value of glContextAttrs
//it will takes effect on all platforms
void AppDelegate::initGLContextAttrs()
{
    //set OpenGL context attributions,now can only set six attributions:
    //red,green,blue,alpha,depth,stencil
    GLContextAttrs glContextAttrs = {8, 8, 8, 8, 24, 8};

    GLView::setGLContextAttrs(glContextAttrs);
}

bool AppDelegate::applicationDidFinishLaunching() {
    // initialize director
    auto director = Director::getInstance();
    auto glview = director->getOpenGLView();
    if(!glview) {
        glview = GLViewImpl::createWithRect("HelloCpp", Rect(0, 0, 1024, 768));
        director->setOpenGLView(glview);
    }

    director->getOpenGLView()->setDesignResolutionSize(1536, 768, ResolutionPolicy::NO_BORDER);
#if !defined(COCOS2D_DEBUG) || COCOS2D_DEBUG == 0
	director->setDisplayStats(false);
#elif COCOS2D_DEBUG >= 1
	director->setDisplayStats(true);
#endif
    director->setAnimationInterval(1.0 / 60);
    FileUtils::getInstance()->addSearchPath("res");
	FileUtils::getInstance()->addSearchPath("res/GameScene");
	FileUtils::getInstance()->addSearchPath("res/LoadingScene");

	FileUtils::getInstance()->addSearchPath("res/Data");
	FileUtils::getInstance()->addSearchPath("res/Image");
	FileUtils::getInstance()->addSearchPath("res/shadow");
	FileUtils::getInstance()->addSearchPath("res/spine");
	FileUtils::getInstance()->addSearchPath("res/3DModel");
	FileUtils::getInstance()->addSearchPath("res/Fonts");

 	//auto scene = TestScene::createScene();
//  	auto scene = LoadingScene::createSceneWithType(LoadingType::ResLoad,SCENEID::TGameScene);
//      director->runWithScene(scene);

	SceneManager::getInstance()->initLoading();
    return true;
}

// This function will be called when the app is inactive. When comes a phone call,it's be invoked too
void AppDelegate::applicationDidEnterBackground() {
    Director::getInstance()->stopAnimation();

    // if you use SimpleAudioEngine, it must be pause
    // SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
}

// this function will be called when the app is active again
void AppDelegate::applicationWillEnterForeground() {
    Director::getInstance()->startAnimation();

    // if you use SimpleAudioEngine, it must resume here
    // SimpleAudioEngine::getInstance()->resumeBackgroundMusic();
}
