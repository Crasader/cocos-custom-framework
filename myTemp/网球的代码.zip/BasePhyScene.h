#ifndef __BasePhyScene_H__
#define __BasePhyScene_H__
#include "cocos2d.h"
#include "3d/CCTerrain.h"
#include "3d/CCBundle3D.h"
#include "physics3d/CCPhysics3D.h"
#include "physics3d/CCPhysics3DObject.h"


class BasePhyScene : public cocos2d::Scene
{
public:
	CREATE_FUNC(BasePhyScene);
	BasePhyScene(void);
	virtual ~BasePhyScene(void);
	virtual bool init() override;
protected:
	cocos2d::Camera *m_ncamera;
};
#endif // __BasePhyScene_H__