//
//  DataManager.cpp

#include "DataManager.h"
static DataManager *_datamamager;
DataManager * DataManager::shareDataManager()
{
	if (!_datamamager)
	{
		_datamamager = new DataManager();
		_datamamager->init();
	}
	return _datamamager;
}

DataManager* DataManager::getInstance()
{
	return shareDataManager();
}

bool DataManager::init()
{
	if (DataLoader::init()){
		return true;
	}
	return false;
}

ValueVector* DataManager::getTableDataAsValueVectorByName(const string& filename)
{
	return &m_nConfigdata[formatStr(filename)].asValueVector();
}

ValueMap* DataManager::getTableDataAsValueMapByName(const string& filename)
{
	CCLOG("DataManager -> getTableDataAsValueMapByName -> %x", &m_nConfigdata[formatStr(filename)].asValueMap());
	return &m_nConfigdata[formatStr(filename)].asValueMap();
}

ValueMap* DataManager::getRoleDataById(int roleid)
{
	ValueVector * nvecdata = getTableDataAsValueVectorByName("Role");
	if (nvecdata)
	{
		for (int i = 0; i < nvecdata->size();i++)
		{
			ValueMap& rolemap = nvecdata->at(i).asValueMap();
			if (rolemap.at("id").asInt() == roleid)
			{
				return &rolemap;
			}
		}
	}
	return nullptr;
}
ValueMap* DataManager::getShoesDataById(int Shoesid)
{
	ValueVector * nvecdata = getTableDataAsValueVectorByName("Shoes");
	if (nvecdata)
	{
		for (int i = 0; i < nvecdata->size(); i++)
		{
			ValueMap& shoesmap = nvecdata->at(i).asValueMap();
			if (shoesmap.at("id").asInt() == Shoesid)
			{
				return &shoesmap;
			}
		}
	}
	return nullptr;
}
ValueMap* DataManager::getRacquetsDataById(int Racquetsid)
{
	ValueVector * nvecdata = getTableDataAsValueVectorByName("Racquets");
	if (nvecdata)
	{
		for (int i = 0; i < nvecdata->size(); i++)
		{
			ValueMap& racquetsmap = nvecdata->at(i).asValueMap();
			if (racquetsmap.at("id").asInt() == Racquetsid)
			{
				return &racquetsmap;
			}
		}
	}
	return nullptr;
}

cocos2d::Value DataManager::getValue(const cocos2d::ValueMap& setData, int rId)
{
	auto str = StringUtils::format("%d", rId);
	return setData.at(str);
}

bool DataManager::hasKey(const ValueMap& map, const std::string &key)
{
	bool has = map.find(key) != map.end();
	return has;
}
