#include "GameScene.h"
#include "BasePhyScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "Particle3D/CCParticleSystem3D.h"
#include "Particle3D/PU/CCPUParticleSystem3D.h"
#include "CommonMethod.h"
#include "EventMacro.h"
USING_NS_CC;
#define BackGroundSize Size(100.0,100.0)
#define PlayGroundSize Size(20.0f,17.0f)
#define BorderWidth 2.5
#define BorderHeight 3.5
#define LeftBottomPos Vec3(-10.0,0.0,-8.5)
#define RightBottomPos Vec3(10.0,0.0,-8.5)
#define CenterBottomPos Vec3(0.0,0.0,-8.5)
#define LefttTopPos Vec3(-10.0,0.0,8.5)
#define RightTopPos Vec3(10.0,0.0,8.5)
#define CenterTopPos Vec3(0.0,0.0,8.5)
#define BottomDefaultPos Vec3(0,0,-6.5)
#define TopDefaultPos Vec3(0,0,6.5)
#define  NetHeight 1.2f
#define BallRadius 0.15
#define BallMass 2.0
#define DefaultGravity Vec3(0,-9.8,0)
#define HitballVelocity 25.0
#define NetThickness 0.01
#define WallHeight 30.0
#define DeadZone 1.5
#define  InvalidPos Vec3(-999,-999,-999)
#define  BallMinHeight 1.5f
#define BallMaxHeight 4.0f
#define  HitMinHeight 1.5f

typedef enum ObjectMask
{
	BallMask = 1,
	NetMask = 2,
	GroundMask = 3,
};

using namespace cocostudio::timeline;
Scene* GameScene::createScene()
{
	GameScene *pRet = new(std::nothrow)GameScene(); 
	if (pRet && pRet->init()) 
	{ 
		pRet->autorelease(); 
	} 
	else 
	{ 
		delete pRet;
		pRet = nullptr; 
	} 
	return pRet;
}

bool GameScene::init()
{
	BasePhyScene::init();
	initData();
	setupPhysicScene();
	registerUI();
	registerEventDispatcher();
	registerGameSceneSystemKeyBoard();
	schedule(CC_SCHEDULE_SELECTOR(GameScene::updateGameLogic), 1.0/60.0f);
    return true;
}
void GameScene::initData()
{
	//��Ϸ��״̬����
	m_nScoreVec.clear();//�ַܾ�����¼
	m_nCurScore.reset();//��ǰ�ֶԱ�
	
	m_ntouchstartpos = Vec3(-999, -999, -999);
	m_ntouchendpos = Vec3(-999, -999, -999);

	m_state = GameState::PlayingState; //��Ϸ״̬
	m_nchangepos_z = 0;
	m_naddgravity = Vec3(0, 0, 0);
	m_nselffirst = true;//�Ƿ����Լ�����
	m_nisfirstplay = true;//�Ƿ��ǿ�����
	m_nhittoward = "left";//��һ�λ�����
	if (m_nselffirst)
	{
		m_nplayerturn = "self";
	}
	else
	{
		m_nplayerturn = "opponen";//��ǰ��Ҫ�������
	}

	m_ncurhitgroundcount = 0;//��ǰ��ײ�������
	m_nfirsthitpos = InvalidPos;

	m_nhitgroundcount = 0;//��ײ�������
	m_nisvolley = false;//�Ƿ�����ǰ�ػ�
	m_nisselfwin = false;//�Ƿ��Ǽ���ʤ��
	m_nfaultcount = 0; //����ʧ�����

	m_nball = nullptr;
	m_nballBody = nullptr;
	m_nshadow = nullptr;
	m_nstreak = nullptr;

	m_nStatisticsView = nullptr;
	m_nFaultView = nullptr;
	m_nScoreView = nullptr;
	m_nResultView = nullptr;

	auto listener = EventListenerTouchAllAtOnce::create();
	listener->onTouchesBegan = CC_CALLBACK_2(GameScene::onTouchesBegan, this);
	listener->onTouchesMoved = CC_CALLBACK_2(GameScene::onTouchesMoved, this);
	listener->onTouchesEnded = CC_CALLBACK_2(GameScene::onTouchesEnded, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);

}
void GameScene::setupPhysicScene()
{
	//��������
	setupGround();
	setupDrawLine();
	setupPlayer();
	this->setCameraMask((unsigned short)CameraFlag::USER1);
}
void GameScene::setupGround()
{
	//��ײ�ں��
	float thickness = 6.0f;
	//ǽ�ڳ�����
	float nbottomLength = 40.0f;
	float nsideLength = 27.0f;
	float nwallheight = WallHeight;
	
	//�� �� �� �� �� ǰ
	Vec3 nWallSize[] = { Vec3(nbottomLength, thickness,nsideLength),
										Vec3(nbottomLength, thickness, nsideLength),
										Vec3(thickness, nwallheight,nsideLength ),
										Vec3(nbottomLength, nwallheight, thickness),
										Vec3(thickness, nwallheight, nsideLength),
										Vec3(nbottomLength, nwallheight, thickness),
										Vec3(PlayGroundSize.width, NetHeight, NetThickness)//����
	};
	Vec3 nWallPos[] = { Vec3(0, -thickness / 2.0, 0),
		Vec3(0, nwallheight + thickness / 2.0, 0),
		Vec3(-nbottomLength / 2.0 - thickness / 2.0, nwallheight / 2.0, 0),
		Vec3(0, nwallheight / 2.0, -nsideLength / 2.0 - thickness / 2.0),
		Vec3(nbottomLength / 2.0 + thickness / 2.0, nwallheight / 2.0, 0),
		Vec3(0, nwallheight / 2.0, nsideLength / 2.0 + thickness / 2.0),
		Vec3(0, NetHeight / 2.0, 0)//����
	};
	string ntexturepath[] = { "Image/background.png",
		"Image/background.png",
		"Image/bluebackground.png",
		"Image/bluebackground.png",
		"Image/bluebackground.png",
		"Image/bluebackground.png",
		"Image/GreenBackGround.png"
	};
	for (int i = 0; i < 7;i++)
	{
		auto nbox = PhysicHelper::createPhysicBox(nWallSize[i], 0, nWallPos[i], ntexturepath[i]);
		this->addChild(nbox);
		//nbox->setPosition3D(nWallPos[i]);
		if (i == 0)
		{
			m_nfloor = nbox;
		}
		auto nboxBody = static_cast<Physics3DRigidBody*>(nbox->getPhysicsObj());
		nboxBody->setMask(GroundMask);
		if (i==6)
		{
			nboxBody->setMask(NetMask);
		}
		
	}
	/*auto nCenterGround = Sprite3D::create("Sprite3DTest/box.c3t", "Image/playground.png");
	nCenterGround->setScaleX(PlayGroundSize.width);
	nCenterGround->setScaleY(0.001);
	nCenterGround->setScaleZ(PlayGroundSize.height);
	nCenterGround->setCameraMask((unsigned short)CameraFlag::USER1);
	nCenterGround->setPosition3D(Vec3(0, 0, 0));
	//nCenterGround->setGlobalZOrder(-2);
	this->addChild(nCenterGround);*/

}
void GameScene::setupPlayer()
{
	m_nplayer = Player::createWithId(1, 1, 1);
	m_nplayer->setScale(0.02/3);
	m_nplayer->setPosition3D(Vec3(0, 0, PlayGroundSize.height / 2.0 ));
	addChild(m_nplayer);

	m_nopponen = Player::createWithId(1, 1, 1);
	m_nopponen->setScale(0.02/3);
	m_nopponen->setPosition3D(Vec3(0, 0, -PlayGroundSize.height / 2.0 ));
	addChild(m_nopponen);
}
void GameScene::setupBall(bool isselfplay)
{
	Vec3 ntransform = m_nplayer->getPosition3D() + Vec3(0, 8, 0);
	if (!isselfplay)
	{
		ntransform = m_nopponen->getPosition3D() + Vec3(0, 8, 0);
	}
	
	m_nball = PhysicHelper::createPhysicSphere(BallRadius, BallMass, ntransform, "Image/wangqiu.png");
	this->addChild(m_nball);
	m_nballBody = static_cast<Physics3DRigidBody*>(m_nball->getPhysicsObj());
	m_nballBody->setCollisionCallback(CC_CALLBACK_1(GameScene::BallCollisionGround, this));
	m_nballBody->setMask(BallMask);

	//������Ӱ
	auto mat = Sprite3DMaterial::createWithFilename("shadow/FakeShadow.material");
	m_nstate = mat->getTechniqueByIndex(0)->getPassByIndex(0)->getGLProgramState();
	m_nfloor->setMaterial(mat);
	m_nstate->setUniformMat4("u_model_matrix", m_nfloor->getNodeToWorldTransform());
	m_nstate->setUniformVec3("u_target_pos", m_nball->getPosition3D());
	//m_nstate->setUniformTexture("u_sampler0",Sprite::create("Image/graybackground.png")->getTexture());
	
	//m_nshadow = Sprite3D::create();
	//auto nshadowsprite = Sprite::create("Image/shadow.png");
	//m_nshadow->addChild(nshadowsprite);
	//nshadowsprite->setScaleX(1.0 / nshadowsprite->getContentSize().width);
	//nshadowsprite->setScaleY(1.0 / nshadowsprite->getContentSize().height);
	//nshadowsprite->runAction(RepeatForever::create(RotateBy::create(3, Vec3(0.f, 0.f, 360.f))));
	////m_nshadow->setRotation3D(Vec3(90, 0, 0));
	//m_nshadow->setCameraMask((unsigned short)CameraFlag::USER1);
	//this->addChild(m_nshadow);

	//������β����
	m_nstreak = cocos2d::MotionStreak3D::create(0.15f, 0.1f, 0.6f, Color3B(255, 255, 255), "Images/streak.png");
	auto colorAction = RepeatForever::create(Sequence::create(
		TintTo::create(0.2f, 255, 0, 0),
		TintTo::create(0.2f, 0, 255, 0),
		TintTo::create(0.2f, 0, 0, 255),
		TintTo::create(0.2f, 0, 255, 255),
		TintTo::create(0.2f, 255, 255, 0),
		TintTo::create(0.2f, 255, 0, 255),
		TintTo::create(0.2f, 255, 255, 255),
		nullptr));
	m_nstreak->setCameraMask((unsigned short)CameraFlag::USER1);
	m_nstreak->runAction(colorAction);
	this->addChild(m_nstreak);
}
void GameScene::VirtualBallCollisionGround(const Physics3DCollisionInfo &ci)
{

}
void GameScene::BallCollisionGround(const Physics3DCollisionInfo &ci)
{
	if (!ci.collisionPointList.empty()){
		//CCLOG("ci.objA->getMask() = %d", ci.objA->getMask());//ǽ��
		//CCLOG("ci.objB->getMask() = %d", ci.objB->getMask());//��
		/*m_ncurhitgroundcount++;
		if (m_ncurhitgroundcount == 1 )
		{
			Vec3 nballpos = m_nball->getPosition3D();
			Vec3 npos = ci.collisionPointList[0].worldPositionOnB;
			Vec3 nvel = m_nballBody->getLinearVelocity();
			CCLOG("npos.x=%.02f,  npos.y=%.02f,  npos.z=%.02f", npos.x, npos.y, npos.z);
			CCLOG("nballpos.x = %.03f, nballpos.y = %.03f, nballpos.z = %.03f", nballpos.x, nballpos.y, nballpos.z);
			CCLOG("nvel.x = %.03f, nvel.y = %.03f, nvel.z = %.03f", nvel.x, nvel.y, nvel.z);
			float nmin_y = 10.0;
			float nmax_y = 20.0f;
			float g = fabs(DefaultGravity.y);
			float t1 = sqrt(2.0*nmin_y / g);
			float nminvel = g*t1;
			float t2 = sqrt(2.0*nmax_y / g);
			float nmaxvel = g*t2;
			if (nvel.y<nminvel)
			{
				nvel.y = nminvel;
			}
			else if (nvel.y>nmaxvel)
			{
				nvel.y = nmaxvel;
			}
			m_nballBody->setLinearVelocity(nvel);
		}
		*/
		
		if ((ci.objA->getMask() == GroundMask&&ci.objB->getMask() == BallMask) ||
			(ci.objA->getMask() == BallMask&&ci.objB->getMask() == GroundMask))
		{
			Vec3 nvel = m_nballBody->getLinearVelocity();
			Vec3 npos = ci.collisionPointList[0].worldPositionOnB;
			m_ncurhitgroundcount++;
			CCLOG("m_nplayerturn = %s  m_ncurhitgroundcount=%d  BallCollisionGround nvel.x = %.02f  nvel.y = %.02f  nvel.z = %.02f ", m_nplayerturn.c_str(), m_ncurhitgroundcount, nvel.x, nvel.y, nvel.z);

			if (m_ncurhitgroundcount ==1)
			{
				m_nfirsthitpos = npos;
				BallCollisionGroundInterval(ci);
			}
			else
			{
				//������ײ�������������͸߶�,��ֹһ����ײ�������δ�뿪����
				if (m_nfirsthitpos.distance(npos)>BallMinHeight)
				{
					BallCollisionGroundInterval(ci);
				}
			}
		}
	}
}
void GameScene::BallCollisionGroundInterval(const Physics3DCollisionInfo &ci)
{
	Vec3 nballpos = m_nball->getPosition3D();
	Vec3 npos = ci.collisionPointList[0].worldPositionOnB;
	m_naddgravity = Vec3(0, 0, 0);
	getPhysics3DWorld()->setGravity(DefaultGravity + m_naddgravity);
	m_nhitgroundcount++;
	CCLOG("BallCollisionGround m_nhitgroundcount = %d", m_nhitgroundcount);
	CCLOG("npos.x=%.02f,  npos.y=%.02f,  npos.z=%.02f", npos.x, npos.y, npos.z);
	CCLOG("nballpos.x = %.03f, nballpos.y = %.03f, nballpos.z = %.03f",nballpos.x, nballpos.y, nballpos.z);
	if (m_nhitgroundcount == 1)
	{
		//��һ����ײ
		Vec3 nvel = m_nballBody->getLinearVelocity();
		float nmin_y = BallMinHeight;
		float nmax_y = BallMaxHeight;
		float g = fabs(DefaultGravity.y);
		float t1 = sqrt(2.0*nmin_y / g);
		float nminvel = g*t1;
		float t2 = sqrt(2.0*nmax_y / g);
		float nmaxvel = g*t2;
		if (nvel.y<nminvel)
		{
			nvel.y = nminvel;
		}
		else if (nvel.y>nmaxvel)
		{
			nvel.y = nmaxvel;
		}
		m_nballBody->setLinearVelocity(nvel);
		
		if (m_nisfirstplay)
		{
			m_nisfirstplay = false;
			//������
			if (m_nselffirst)
			{
				//�Լ�����
				if (m_nhittoward == "left")
				{
					if (npos.x >= -(PlayGroundSize.width / 2.0 - BorderWidth) &&
						npos.x <= 0 &&
						npos.z <= 0 &&
						npos.z >= -(PlayGroundSize.height / 2.0 - BorderHeight))
					{
						m_nhittoward = "right";
						m_nfaultcount = 0;
						return;
					}
					else
					{
						m_nfaultcount++;
						if (m_nfaultcount == 2)
						{
							m_nhittoward = "right";
							m_nfaultcount = 0;
							statisticsScore(false);
							return;
						}
						else if (m_nfaultcount < 2)
						{
							resetNextGame();
							ChangeGameState(FaultState);
							return;
						}
					}
				}
				else if (m_nhittoward == "right")
				{
					if (npos.x >= 0 &&
						npos.x <= (PlayGroundSize.width / 2.0 - BorderWidth) &&
						npos.z <= 0 &&
						npos.z >= -(PlayGroundSize.height / 2.0 - BorderHeight))
					{
						m_nhittoward = "left";
						m_nfaultcount = 0;
						return;
					}
					else
					{
						m_nfaultcount++;
						if (m_nfaultcount == 2)
						{
							m_nhittoward = "left";
							m_nfaultcount = 0;
							statisticsScore(false);
							return;
						}
						else
						{
							resetNextGame();
							ChangeGameState(FaultState);
							return;
						}
					}
				}
			}
			else
			{
				//��������
				if (m_nhittoward == "left")
				{
					if (npos.x >= 0 &&
						npos.x <= (PlayGroundSize.width / 2.0 - BorderWidth) &&
						npos.z <= (PlayGroundSize.height / 2.0 - BorderHeight) &&
						npos.z >= 0)
					{
						m_nhittoward = "right";
						m_nfaultcount = 0;
						return;
					}
					else
					{
						m_nfaultcount++;
						if (m_nfaultcount == 2)
						{
							m_nhittoward = "right";
							m_nfaultcount = 0;
							statisticsScore(true);
							return;
						}
						else
						{
							resetNextGame();
							ChangeGameState(FaultState);
							return;
						}
					}
				}
				else if (m_nhittoward == "right")
				{
					if (npos.x >= -(PlayGroundSize.width / 2.0 - BorderWidth) &&
						npos.x <= 0 &&
						npos.z <= (PlayGroundSize.height / 2.0 - BorderHeight) &&
						npos.z >= 0)
					{
						m_nhittoward = "left";
						m_nfaultcount = 0;
						return;
					}
					else
					{
						m_nfaultcount++;
						if (m_nfaultcount == 2)
						{
							m_nhittoward = "left";
							m_nfaultcount = 0;
							statisticsScore(true);
							return;
						}
						else
						{
							resetNextGame();
							ChangeGameState(FaultState);
							return;
						}
					}
				}
			}
		}
		else
		{
			if (m_nplayerturn == "self")
			{
				//���ֻ���������
				if (npos.x >= -(PlayGroundSize.width / 2.0 - BorderWidth) &&
					npos.x <= (PlayGroundSize.width / 2.0 - BorderWidth) &&
					npos.z <= PlayGroundSize.height / 2.0 &&
					npos.z >= 0)
				{

				}
				else
				{
					statisticsScore(true);
					return;
				}

			}
			else if (m_nplayerturn == "opponen")
			{
				//�Լ�����������
				if (npos.x >= -(PlayGroundSize.width / 2.0 - BorderWidth) &&
					npos.x <= (PlayGroundSize.width / 2.0 - BorderWidth) &&
					npos.z <= 0 &&
					npos.z >= -PlayGroundSize.height / 2.0)
				{

				}
				else
				{
					statisticsScore(false);
					return;
				}
			}
		}
	}
	else if (m_nhitgroundcount > 1)
	{
		if (m_nplayerturn == "self")
		{//���ֻ���������
			statisticsScore(false);
			return;
		}
		else if (m_nplayerturn == "opponen")
		{//�Լ�����������
			statisticsScore(true);
			return;
		}
	}
}
void GameScene::statisticsScore(bool isself)
{
	bool iswin = false;
	if (isself)
	{
		m_nCurScore.SelfPoint++;
		if (m_nCurScore.SelfPoint > 3)
		{
			if (m_nCurScore.OpponenPoint > 3)
			{
				m_nCurScore.SelfPoint = 3;
				m_nCurScore.OpponenPoint = 3;
				//��ʾ��ǰ�ȷ�
			}
			else if (m_nCurScore.OpponenPoint < 3)
			{
				ScoreData nScore = m_nCurScore;
				m_nCurScore.reset();
				//you win
				//��ʾ��ͣ����
				iswin = true;
				m_nScoreVec.push_back(nScore);
			}
			else if (m_nCurScore.OpponenPoint == 3)
			{
				if (m_nCurScore.SelfPoint >= 5)
				{
					ScoreData nScore = m_nCurScore;
					m_nCurScore.reset();
					//you win
					iswin = true;
					m_nScoreVec.push_back(nScore);
				}
			}
		}
	}
	else
	{
		m_nCurScore.OpponenPoint++;
		if (m_nCurScore.OpponenPoint > 3)
		{
			if (m_nCurScore.SelfPoint > 3)
			{
				m_nCurScore.SelfPoint = 3;
				m_nCurScore.OpponenPoint = 3;
			}
			else if (m_nCurScore.SelfPoint < 3)
			{
				ScoreData nScore = m_nCurScore;
				m_nCurScore.reset();
				//opponen win
				iswin = true;
				m_nScoreVec.push_back(nScore);
			}
			else if (m_nCurScore.SelfPoint == 3)
			{
				if (m_nCurScore.OpponenPoint >= 5)
				{
					ScoreData nScore = m_nCurScore;
					m_nCurScore.reset();
					//opponen win
					iswin = true;
					m_nScoreVec.push_back(nScore);
				}
			}
		}
	}

	resetNextGame();
	if (!checkRound())
	{
		if (iswin)
		{
			//��ת����ͣ
			resetNewRound();
			ChangeGameState(GameState::PauseState);
			CCLOG("jump to pause");
		}
		else
		{
			//��ת���ȷ���ʾ
			CCLOG("show score ");
			ChangeGameState(ScoreState);
		}
	}

	EventCustom event1(Event_UpdateScore);
	_eventDispatcher->dispatchEvent(&event1);

}
bool GameScene::checkRound()
{
	int nselfwincount = 0;
	int nopponenwincount = 0;
	for (int i = 0; i < m_nScoreVec.size(); i++)
	{
		ScoreData nscore = m_nScoreVec.at(i);
		if (nscore.SelfPoint > nscore.OpponenPoint)
		{
			nselfwincount++;
		}
		else
		{
			nopponenwincount++;
		}
	}
	if (nselfwincount >= 6)
	{
		if ((nselfwincount - nopponenwincount) >= 2)
		{
			//you win
			m_nisselfwin = true;
			ChangeGameState(FinishState);
			return true;
		}
	}
	if (nopponenwincount >= 6)
	{
		if ((nopponenwincount - nselfwincount) >= 2)
		{
			//opponen win
			m_nisselfwin = false;
			ChangeGameState(FinishState);
			return true;
		}
	}
	return false;
}
void GameScene::setupDrawLine()
{
	float y = 0.01;
	Size bordersize = PlayGroundSize + Size(0.01, 0.01);
	m_ndrawGrid = DrawNode3D::create();
	m_ndrawGrid->drawLine(Vec3(-bordersize.width / 2.0, y, bordersize.height / 2.0), Vec3(-bordersize.width / 2.0, y, -bordersize.height / 2.0), Color4F(1, 1, 1, 1));
	m_ndrawGrid->drawLine(Vec3(-bordersize.width / 2.0, y, -bordersize.height / 2.0), Vec3(bordersize.width / 2.0, y, -bordersize.height / 2.0), Color4F(1, 1, 1, 1));
	m_ndrawGrid->drawLine(Vec3(bordersize.width / 2.0, y, -bordersize.height / 2.0), Vec3(bordersize.width / 2.0, y, bordersize.height / 2.0), Color4F(1, 1, 1, 1));
	m_ndrawGrid->drawLine(Vec3(bordersize.width / 2.0, y, bordersize.height / 2.0), Vec3(-bordersize.width / 2.0, y, bordersize.height / 2.0), Color4F(1, 1, 1, 1));
	
	m_ndrawGrid->drawLine(Vec3(-bordersize.width / 2.0 + BorderWidth, y, bordersize.height / 2.0), Vec3(-bordersize.width / 2.0 + BorderWidth, y, -bordersize.height / 2.0), Color4F(1, 1, 1, 1));
	m_ndrawGrid->drawLine(Vec3(bordersize.width / 2.0 - BorderWidth, y, -bordersize.height / 2.0), Vec3(bordersize.width / 2.0 - BorderWidth, y, bordersize.height / 2.0), Color4F(1, 1, 1, 1));
	
	m_ndrawGrid->drawLine(Vec3(-bordersize.width / 2.0 + BorderWidth, y, bordersize.height / 2.0 - BorderHeight), Vec3(bordersize.width / 2.0 - BorderWidth, y, bordersize.height / 2.0 - BorderHeight), Color4F(1, 1, 1, 1));
	m_ndrawGrid->drawLine(Vec3(-bordersize.width / 2.0 + BorderWidth, y, -bordersize.height / 2.0 + BorderHeight), Vec3(bordersize.width / 2.0 - BorderWidth, y, -bordersize.height / 2.0 + BorderHeight), Color4F(1, 1, 1, 1));

	m_ndrawGrid->drawLine(Vec3(0, y, bordersize.height / 2.0), Vec3(0, y, bordersize.height / 2.0 - BorderHeight/7.0), Color4F(1, 1, 1, 1));
	m_ndrawGrid->drawLine(Vec3(0, y, bordersize.height / 2.0 - BorderHeight), Vec3(0, y, -bordersize.height / 2.0 + BorderHeight), Color4F(1, 1, 1, 1));
	m_ndrawGrid->drawLine(Vec3(0, y, -bordersize.height / 2.0 ), Vec3(0, y, -bordersize.height / 2.0 + BorderHeight/7.0), Color4F(1, 1, 1, 1));
	//m_ndrawGrid->drawLine(Vec3(0, y, 0), Vec3(2000, y, 0), Color4F(1, 1, 0, 1));//x�� ��
	//m_ndrawGrid->drawLine(Vec3(0, y, 0), Vec3(0, y+2000, 0), Color4F(1, 0, 1, 1));//y�� ��
	//m_ndrawGrid->drawLine(Vec3(0, y, 0), Vec3(0, y, 2000), Color4F(0, 1, 1, 1));//z�� ��
	addChild(m_ndrawGrid);
}
void GameScene::registerUI()
{
	//ע����ڵ�
	auto layer = Layer::create();
	layer->setName("rootlayer");
	addChild(layer);
	//ע����Ϸ����UI
	Node *nrootnode = CSLoader::createNode("GameScene/GameView.csb");
	m_nYourScore_Text = static_cast<Text*>(UiManager::GetChildByName(nrootnode, "YourScore_Text"));
	m_nOpponen_Text = static_cast<Text*>(UiManager::GetChildByName(nrootnode, "Opponen_Text"));
	m_nTotal_Text = static_cast<Text*>(UiManager::GetChildByName(nrootnode, "Total_Text"));

	
	auto  nPause_Button = static_cast<Button*>(UiManager::GetChildByName(nrootnode, "Pause_Button"));

	nPause_Button->addClickEventListener([=](Ref* sender) {
		ChangeGameState(PauseState);
	});
	layer->addChild(nrootnode);

}
void GameScene::setUpUIWithData()
{

}
void GameScene::registerEventDispatcher()
{
	auto nFaultViewCloselistener = EventListenerCustom::create(Event_FaultViewClose, [=](EventCustom* event){
		m_nFaultView = nullptr;
		ChangeGameState(PlayingState);
	});
	auto nScoreViewCloselistener = EventListenerCustom::create(Event_ScoreViewClose, [=](EventCustom* event){
		m_nScoreView = nullptr;
		ChangeGameState(PlayingState);
	});
	auto ncontinuelistener = EventListenerCustom::create(Event_ContinueGame, [=](EventCustom* event){
		m_nStatisticsView = nullptr;
		ChangeGameState(PlayingState);
	});
	auto nreplaylistener = EventListenerCustom::create(Event_RePlayGame, [=](EventCustom* event){
		Director::sharedDirector()->replaceScene(GameScene::createScene());

	});
	auto nupdateScorelistener = EventListenerCustom::create(Event_UpdateScore, [=](EventCustom* event){
		m_nYourScore_Text->setText(StringUtils::format("Your Score:%d",m_nCurScore.SelfPoint));
		m_nOpponen_Text->setText(StringUtils::format("Opponen Score:%d", m_nCurScore.OpponenPoint));;
		string nmyscore = "|";
		string nopponenscore = "|";
		for (int i = 0; i < m_nScoreVec.size();i++)
		{
			nmyscore += StringUtils::format("%d|", m_nScoreVec.at(i).SelfPoint);
			nopponenscore += StringUtils::format("%d|", m_nScoreVec.at(i).OpponenPoint);
		}
		if (m_nScoreVec.size() > 0)
		{
			m_nTotal_Text->setText(nmyscore + "\n" + nopponenscore);
		}
	});

	_eventDispatcher->addEventListenerWithSceneGraphPriority(nFaultViewCloselistener, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(nScoreViewCloselistener, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(ncontinuelistener, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(nreplaylistener, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(nupdateScorelistener, this);
}
void GameScene::registerGameSceneSystemKeyBoard()
{
	auto listener = EventListenerKeyboard::create();
	listener->onKeyPressed = CC_CALLBACK_2(GameScene::GameSceneonKeyPressed, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
}
void GameScene::GameSceneonKeyPressed(cocos2d::EventKeyboard::KeyCode code, cocos2d::Event* event)
{
	if (code == EventKeyboard::KeyCode::KEY_UP_ARROW)
	{
		m_nballBody->setLinearVelocity(Vec3(0, 5, -15));
	}
	else if (code == EventKeyboard::KeyCode::KEY_DOWN_ARROW)
	{
		m_nballBody->setLinearVelocity(Vec3(0, 5, 15));
		//m_nballBody->setAngularVelocity(Vec3(50, 0, 0));
		//m_nballBody->applyCentralForce(Vec3(0, -1000, 0));	
	}
	else if (code == EventKeyboard::KeyCode::KEY_LEFT_ARROW)
	{
		m_nballBody->setLinearVelocity(Vec3(-20,5,0 ));
		//m_nballBody->setAngularVelocity(Vec3(0, 0, -50));
		//m_nballBody->setAngularFactor(Vec3(0, 0, 5);
	/*	m_nballBody->applyCentralForce(Vec3(-1000, 0, 0));
		Vec3 nvec = m_nballBody->getTotalForce();*/
		/*m_nballBody->setLinearVelocity(Vec3(0,0,50));*/
	}
	else if (code == EventKeyboard::KeyCode::KEY_RIGHT_ARROW)
	{
		m_nballBody->setLinearVelocity(Vec3(20, 5, 0));
		//m_nballBody->setAngularVelocity(Vec3(0, 0, 50));
		//m_nballBody->setDamping(0, 0.01);
		//m_nballBody->setLinearFactor()
		//m_nballBody->setAngularFactor(Vec3(0, 0, -5));
		/*m_nballBody->applyCentralForce(Vec3(1000, 0, 0));*/
	}
	else if (code == EventKeyboard::KeyCode::KEY_PG_UP)
	{
		m_nballBody->applyCentralForce(Vec3(0, 0, -1000));
	}
	else if (code == EventKeyboard::KeyCode::KEY_PG_DOWN)
	{
		m_nballBody->applyCentralForce(Vec3(0, 0, 1000));
		Vec3 nForce = m_nballBody->getTotalForce();
		CCLOG("nForce x= %02f,y = %02f,z = %02f", nForce.x, nForce.y, nForce.z);
	}
	else if (code == EventKeyboard::KeyCode::KEY_F1)
	{
		m_naddgravity = Vec3(3, -9.8*2, 0);
		//PausePhysicScene();
	}
	else if (code == EventKeyboard::KeyCode::KEY_F2)
	{
		m_naddgravity = Vec3(-3, -9.8*2, 0);
		//ResumePhysicScene();
	}
	else if (code == EventKeyboard::KeyCode::KEY_F3)
	{
		m_naddgravity = Vec3(0, -9.8 * 2, 3);
	}
	else if (code == EventKeyboard::KeyCode::KEY_F4)
	{
		m_naddgravity = Vec3(0, -9.8 * 2, -3);
	}
	else if (code == EventKeyboard::KeyCode::KEY_SPACE)
	{
		
	}
}

void GameScene::resetNextGame()
{
	m_nchangepos_z = 0;
	m_naddgravity = Vec3(0, 0, 0);
	m_ntouchstartpos = Vec3(-999, -999, -999);
	m_ntouchendpos = Vec3(-999, -999, -999);
	m_ncurhitgroundcount = 0;
	m_nhitgroundcount = 0;
	m_nisfirstplay = true;
	if (m_nselffirst)
	{
		m_nplayerturn = "self";
	}
	else
	{
		m_nplayerturn = "opponen";
	}
	
	m_nisvolley = false;

	if (m_nball)
	{
		m_nballBody->setCollisionCallback(nullptr);
		m_nball->runAction(Sequence::create(DelayTime::create(0.1),
			CallFuncN::create([=](Node *node){
			node->removeFromParent();
		}),
			nullptr));
		//getPhysics3DWorld()->removePhysics3DObject(m_nballBody);
		m_nball = nullptr;
		m_nballBody = nullptr;
		m_nstate->setUniformVec3("u_target_pos", Vec3(PlayGroundSize.width / 2.0, 0, PlayGroundSize.height / 2.0 + 5));
		//m_nstate->setUniformTexture("u_sampler1", Sprite::create("Image/background.png")->getTexture());
	}
	if (m_nstreak)
	{
		m_nstreak->removeFromParent();
		m_nstreak = nullptr;
	}
	if (m_nshadow)
	{
		m_nshadow->removeFromParent();
		m_nshadow = nullptr;
	}

	if (m_nplayer)
	{
		m_nplayer->stopAllActions();
		m_nplayer->setPosition3D(Vec3(0, 0, PlayGroundSize.height / 2.0));
	}
	if (m_nopponen)
	{
		m_nopponen->stopAllActions();
		m_nopponen->setPosition3D(Vec3(0, 0, -PlayGroundSize.height / 2.0));
	}
}
void GameScene::resetNewRound()
{
	m_nselffirst = !m_nselffirst;
	m_nhittoward = "left";
	if (m_nselffirst)
	{
		//��������
		m_nplayerturn = "self";
	}
	else
	{
		//��������
		m_nplayerturn = "opponen";
	}
}


void GameScene::test()
{
	//������ײ�ص�
	/*rigidBody->setCollisionCallback([=](const Physics3DCollisionInfo &ci){
		if (!ci.collisionPointList.empty()){
			if (ci.objA->getMask() != 0){
				auto ps = PUParticleSystem3D::create("Particle3D/scripts/mp_hit_04.pu");
				ps->setPosition3D(ci.collisionPointList[0].worldPositionOnB);
				ps->setScale(0.05f);
				ps->startParticleSystem();
				ps->setCameraMask(2);
				this->addChild(ps);
				ps->runAction(Sequence::create(DelayTime::create(1.0f), CallFunc::create([=](){
					ps->removeFromParent();
				}), nullptr));
				ci.objA->setMask(0);
			}
		}*/

	//�����2D ��3D���
	/*auto circleBack = Sprite3D::create();
	auto circle = Sprite::create("Sprite3DTest/circle.png");
	circleBack->setScale(0.5f);
	circleBack->addChild(circle);
	circle->runAction(RepeatForever::create(RotateBy::create(3, Vec3(0.f, 0.f, 360.f))));

	circleBack->setRotation3D(Vec3(90, 90, 0));

	auto pos = sprite->getPosition3D();
	circleBack->setPosition3D(Vec3(pos.x, pos.y, pos.z - 1));

	sprite->setOpacity(250);
	sprite->setCameraMask(2);
	circleBack->setCameraMask(2);
	sprite->setTag(3);
	circleBack->setTag(2);

	auto node = Node::create();
	node->addChild(sprite);
	node->addChild(circleBack);*/

	//3D��ײ���
	/*auto sprite = Sprite3D::create(fileName);
	AABB aabb = sprite->getAABB();
	_obbt = OBB(aabb);*/
	//_drawOBB->drawCube(corners, _obbt.intersects(_obb[i]) ? Color4F(1, 0, 0, 1) : Color4F(0, 1, 0, 1));
}
void GameScene::onTouchesBegan(const std::vector<cocos2d::Touch*>& touches, cocos2d::Event  *event)
{
	if (!touches.empty())
	{
		m_nismakeball = false;
		if (m_nselffirst)
		{
			if (!m_nball&&!m_nballBody&&!m_nstreak)
			{
				//�������֣����ҵ�ǰû�д�������
				//��������
				setupBall(m_nselffirst);
				m_nismakeball = true;
			}
		}
		
		if (!m_nismakeball&&m_nplayerturn == "self")//�ڶԷ���Ա����󣬲ſ�ʼ����
		{
			//��������Ļλ��ת��Ϊ3d�ռ�λ��
			auto touch = touches[0];
			auto location = touch->getLocationInView();
			Vec3 nearP(location.x, location.y, -1.0f), farP(location.x, location.y, 1.0f);
			auto size = Director::getInstance()->getWinSize();
			nearP = m_ncamera->unproject(nearP);
			farP = m_ncamera->unproject(farP);
			Vec3 dir(farP - nearP);
			float dist = 0.0f;
			float ndd = Vec3::dot(Vec3(0, 1, 0), dir);
			if (ndd == 0)
				dist = 0.0f;
			float ndo = Vec3::dot(Vec3(0, 1, 0), nearP);
			dist = (0 - ndo) / ndd;
			Vec3 p = nearP + dist *  dir;
			/*if (p.x > 100)
			p.x = 100;
			if (p.x < -100)
			p.x = -100;
			if (p.z > 100)
			p.z = 100;
			if (p.z < -100)
			p.z = -100;*/
			m_ntouchstartpos = p;
			m_ntouchendpos = p;
			//CCLOG("m_ntouchstartpos x = %.02f, y = %.02f, z = %.02f", m_ntouchstartpos.x, m_ntouchstartpos.y, m_ntouchstartpos.z);
			event->stopPropagation();
		}
	}
}
void GameScene::onTouchesMoved(const std::vector<cocos2d::Touch*>& touches, cocos2d::Event  *event)
{
	if (!m_nismakeball&&m_nplayerturn == "self")
	{
		if (!touches.empty())
		{
			//��������Ļλ��ת��Ϊ3d�ؼ�λ��
			auto touch = touches[0];
			auto location = touch->getLocationInView();
			Vec3 nearP(location.x, location.y, -1.0f), farP(location.x, location.y, 1.0f);
			auto size = Director::getInstance()->getWinSize();
			nearP = m_ncamera->unproject(nearP);
			farP = m_ncamera->unproject(farP);
			Vec3 dir(farP - nearP);
			float dist = 0.0f;
			float ndd = Vec3::dot(Vec3(0, 1, 0), dir);
			if (ndd == 0)
				dist = 0.0f;
			float ndo = Vec3::dot(Vec3(0, 1, 0), nearP);
			dist = (0 - ndo) / ndd;
			Vec3 p = nearP + dist *  dir;
			m_ntouchendpos = p;
			//CCLOG("m_ntouchendpos x = %.02f, y = %.02f, z = %.02f", m_ntouchendpos.x, m_ntouchendpos.y, m_ntouchendpos.z);
			event->stopPropagation();
		}
	}
}
void GameScene::onTouchesEnded(const std::vector<cocos2d::Touch*>& touches, cocos2d::Event  *event)
{
	if (!m_nismakeball&&m_nplayerturn == "self")
	{
		if (!touches.empty())
		{
			//��������Ļλ��ת��Ϊ3d�ؼ�λ��
			auto touch = touches[0];
			auto location = touch->getLocationInView();
			Vec3 nearP(location.x, location.y, -1.0f), farP(location.x, location.y, 1.0f);
			auto size = Director::getInstance()->getWinSize();
			nearP = m_ncamera->unproject(nearP);
			farP = m_ncamera->unproject(farP);
			Vec3 dir(farP - nearP);
			float dist = 0.0f;
			float ndd = Vec3::dot(Vec3(0, 1, 0), dir);
			if (ndd == 0)
				dist = 0.0f;
			float ndo = Vec3::dot(Vec3(0, 1, 0), nearP);
			dist = (0 - ndo) / ndd;
			Vec3 p = nearP + dist *  dir;
			m_ntouchendpos = p;
			//CCLOG("m_ntouchendpos x = %.02f, y = %.02f, z = %.02f", m_ntouchendpos.x, m_ntouchendpos.y, m_ntouchendpos.z);
			event->stopPropagation();
		}
	}
}
//Vec3 GameScene::HitBall(Vec3 startpos, Vec3 endpos)
//{
//	float nlength = (endpos - startpos).length();
//	auto noperatecache = endpos - startpos;
//	Vec3 nhittargetpos = BottomDefaultPos;
//
//	if (noperatecache.length()<0.1)
//	{
//		//�����߻���
//		Vec3 nballpos = m_nball->getPosition3D();//����λ��
//		Vec3 nvelocity = getVelocityByDestination(nhittargetpos);
//		m_nballBody->setLinearVelocity(nvelocity);
//	}
//	else
//	{
//		if (m_nhittoward=="left")
//		{
//			//��һ�λ����ж�������
//			float nbasewidth = 10.0f;
//			float ndis = 0.5f;
//			float nlmin_x = -PlayGroundSize.width / 2.0 + BorderWidth;
//			float nrange = fabs(noperatecache.x / nbasewidth);
//			nrange = nrange < 1.0 ? nrange : 1.0;
//			int nrandom = CommonMethod::getRand(1, 100);
//			nhittargetpos.x = nrange*(nlmin_x + ndis) - ndis*nrandom / 100;
//
//
//			ndis = 0.5;
//			float unarrivedis = 1.0;
//			float nbmiddle_z = -PlayGroundSize.height / 2.0 + BorderHeight;//�в�����z������
//			nrandom = CommonMethod::getRand(1, 100);
//			nhittargetpos.z = nbmiddle_z + fabs(nrange*(nbmiddle_z + ndis + unarrivedis)) + ndis*nrandom / 100.0;
//			m_nhittoward = "notleft";
//		}
//		else if (m_nhittoward == "right")
//		{
//			//��һ�λ����ж�������
//			float nbasewidth = 10.0f;
//			float ndis = 0.5f;
//			float nrmax_x = PlayGroundSize.width / 2.0 - BorderWidth;
//			float nrange = fabs(noperatecache.x / nbasewidth);
//			nrange = nrange < 1.0 ? nrange : 1.0;
//			int nrandom = CommonMethod::getRand(1, 100);
//			nhittargetpos.x = nrange*(nrmax_x - ndis) + ndis*nrandom / 100;
//
//
//			ndis = 0.5;
//			float unarrivedis = 1.0;
//			float nbmiddle_z = -PlayGroundSize.height / 2.0 + BorderHeight;//�в�����z������
//			nrandom = CommonMethod::getRand(1, 100);
//			nhittargetpos.z = nbmiddle_z + fabs(nrange*(nbmiddle_z + ndis + unarrivedis)) + ndis*nrandom / 100.0;
//			m_nhittoward = "notright";
//		}
//		else
//		{
//			//��������վ��λ�ú����λ���ж�ʹ�����ַ��֣�����������෴�ֻ������������Ҳ����ֻ���
//			//���ݱ���������ļнǼ���
//			Vec3 nRcbdis = RightBottomPos - CenterTopPos;
//			Vec3 nLcbdis = LeftBottomPos - CenterTopPos;
//			Vec3 nRctdis = RightTopPos - CenterBottomPos;
//			Vec3 nLctdis = LefttTopPos - CenterBottomPos;
//
//			float nRcbRadian = atan(fabs(nRcbdis.x) / fabs(nRcbdis.z));//�Ҳ�ײ����߼н�
//			float nLcbRadian = atan(fabs(nLcbdis.x) / fabs(nLcbdis.z));//���ײ����߼н�
//			float nRctRadian = atan(fabs(nRctdis.x) / fabs(nRctdis.z));//�Ҳඥ���߼н�
//			float nLctRadian = atan(fabs(nLctdis.x) / fabs(nLctdis.z));//��ඥ�����߼н�
//
//			Vec3 nballpos = m_nball->getPosition3D();//����λ��
//			Vec3 nballRbdis = RightBottomPos - nballpos;
//			Vec3 nballLbdis = LeftBottomPos - nballpos;
//			float nRbRadian = atan(fabs(nballRbdis.x) / fabs(nballRbdis.z));//�����Ҳ�׶�
//			float nLbRadian = atan(fabs(nballLbdis.x) / fabs(nballLbdis.z));//�������׶�
//
//			//Vec3 nvelocity = Vec3(0, 5, 0);
//			float ndis = 1.0;
//			if (noperatecache.x > 0.0)
//			{
//				//���Ҳ����
//				float nrmax_x = PlayGroundSize.width / 2.0 - BorderWidth;
//				int nrandom = CommonMethod::getRand(1, 100);
//				if (nRbRadian < nRcbRadian / 3.0)
//				{
//					//������Ҳ�߽����1.0m����
//					nhittargetpos.x = nrmax_x - ndis*nrandom / 100;
//				}
//				else
//				{
//					float nbasewidth = 10.0f;//�ж���ָ�ƶ��������ֵ
//					float nrange = noperatecache.x / nbasewidth;
//					nrange = nrange < 1.0 ? nrange : 1.0;
//					if (nballpos.x>0)
//					{
//						//�����Ҳ�
//						//���λ�õ��ұ߽�λ�þ����
//						//���ݲ�������ȡ���ֵ
//						nhittargetpos.x = nballpos.x + nrange*(nrmax_x - nballpos.x - ndis) + ndis*nrandom / 100;
//					}
//					else
//					{
//						//�������,
//						//0λ�õ��ұ߽�����
//						//���ݲ�������ȡ���ֵ
//						nhittargetpos.x = nrange*(nrmax_x - ndis) + ndis*nrandom / 100;
//					}
//				}
//			}
//			else
//			{
//				//��������
//				float nlmin_x = -PlayGroundSize.width / 2.0 + BorderWidth;
//				int nrandom = CommonMethod::getRand(1, 100);
//				if (nLbRadian < nLcbRadian / 3.0)
//				{
//					//��������߽����1.0m����
//					nhittargetpos.x = nlmin_x + ndis*nrandom / 100;
//				}
//				else
//				{
//					float nbasewidth = 10.0f;//�ж���ָ�ƶ��������ֵ
//					float nrange = fabs(noperatecache.x / nbasewidth);
//					nrange = nrange < 1.0 ? nrange : 1.0;
//					if (nballpos.x < 0)
//					{
//						//�������
//						//���λ�õ���߽�λ�þ����
//						//���ݲ�������ȡ���ֵ
//						nhittargetpos.x = nballpos.x + nrange*(nlmin_x - nballpos.x + ndis) - ndis*nrandom / 100;
//					}
//					else
//					{
//						//�����Ҳ�,
//						//0λ�õ���߽�����
//						//���ݲ�������ȡ���ֵ
//						nhittargetpos.x = nrange*(nlmin_x + ndis) - ndis*nrandom / 100;
//					}
//				}
//			}
//
//			if (noperatecache.z < 0)
//			{
//				//����߻���
//				float nbasewidth = 15.0f;//�ж���ָ�ƶ��������ֵ
//				float nrange = fabs(noperatecache.z / nbasewidth);
//				nrange = nrange < 1.0 ? nrange : 1.0;
//				float ndis = 0.5;
//				float nbmin_z = -PlayGroundSize.height / 2.0 + ndis;//�ײ�z������ֵ
//				int nrandom = CommonMethod::getRand(1, 100);
//				nhittargetpos.z = -PlayGroundSize.height / 2.0 + BorderHeight - nrange*(BorderHeight - ndis) + ndis*nrandom / 100.0;
//			}
//			else if (noperatecache.z>0)
//			{
//				//�����߸�������
//				float nbasewidth = 15.0f;//�ж���ָ�ƶ��������ֵ
//				float nrange = fabs(noperatecache.z / nbasewidth);
//				nrange = nrange < 1.0 ? nrange : 1.0;
//				float ndis = 1.0;
//				float unarrivedis = 1.0;
//				float nbmiddle_z = -PlayGroundSize.height / 2.0 + BorderHeight;//�в�����z������
//				int nrandom = CommonMethod::getRand(1, 100);
//				nhittargetpos.z = nbmiddle_z + fabs(nrange*(nbmiddle_z + ndis + unarrivedis)) + ndis*nrandom / 100.0;
//			}
//			else
//			{
//				nhittargetpos.z = BottomDefaultPos.z;
//			}
//		}
//		Vec3 nvelocity = getVelocityByDestination(nhittargetpos);
//		m_nballBody->setLinearVelocity(nvelocity);
//	}
//	return nhittargetpos;
//}
void GameScene::updateGameLogic(float dt)
{
	if (m_state == ReadyState)
	{
		ReadyStateUpdate(dt);
	}
	else if (m_state == PlayingState)
	{
		PlayingStateUpdate(dt);
	}
	else if (m_state == FaultState)
	{
		FaultStateUpdate(dt);
	}
	else if (m_state == ScoreState)
	{
		ScoreStateUpdate(dt);
	}
	else if (m_state == PauseState)
	{
		PauseStateUpdate(dt);
	}
	else if (m_state == FinishState)
	{
		FinishStateUpdate(dt);
	}
}
void GameScene::ChangeGameState(GameState nstate)
{
	m_state = nstate;
}
void GameScene::ReadyStateUpdate(float dt)
{

}
void GameScene::PlayingStateUpdate(float dt)
{
	if (_ispause)
	{
		ResumePhysicScene();
	}
	getPhysics3DWorld()->setGravity(DefaultGravity);
	//���²���λ��
	if (m_nstreak&&m_nball)
	{
		m_nstreak->setPosition3D(m_nball->getPosition3D());
	}
	if (m_nball)
	{
		m_nstate->setUniformVec3("u_target_pos", m_nball->getPosition3D());
	}

	/*if (m_nshadow&&m_nball)
	{
	Vec3 nballpos = m_nball->getPosition3D();
	m_nshadow->setPosition3D(Vec3(nballpos.x, 1.0, nballpos.z));
	}*/

	//��������ͨ�������Ч��������ʱ��
	if (m_nball)
	{
		Vec3 nballpos = m_nball->getPosition3D();
		if (m_nplayerturn == "opponen")
		{
			//���ֻ���
			Vec3 nopponenpos = m_nopponen->getPosition3D() + Vec3(0, 1, 0);
			//����Ч�������뾶1m
			//CCLOG("nopponenpos.distance(m_nball->getPosition3D() ) = %.04f", nopponenpos.distance(m_nball->getPosition3D()));
			CCLOG("opponen nballpos.x = %.04f nballpos.z = %.04f  nballpos.y = %.04f", nballpos.x, nballpos.z, nballpos.y);
			if (nopponenpos.distance(nballpos) <= 2)
			{
				if (nballpos.z<0 && nballpos.y >= HitMinHeight)
				{
					CCLOG("m_nisfirstplay = %d  m_nselffirst = %d  m_nisvolley = %d  m_nhitgroundcount=%d", m_nisfirstplay, m_nselffirst, m_nisvolley, m_nhitgroundcount);
				}	
			}
			
			if ((nopponenpos.distance(nballpos) <= 2 && nballpos.z<0 && nballpos.y >= HitMinHeight) &&
				((m_nisfirstplay&&!m_nselffirst) ||
				m_nisvolley ||
				m_nhitgroundcount == 1)
				)
			{
				
				m_naddgravity = Vec3(0, 0, 0);
				Vec3 ntargetpos = getOpponenHitTargetPos();
				Vec3 nhitballvelocity = getVelocityByDestination(ntargetpos);
				Vec3 nstandpos = simulationBallFlightPos(nballpos, nhitballvelocity, m_naddgravity, "self");
				CCLOG("PlayingStateUpdate m_nplayerturn == opponen nhitballvelocity.x = %.03f, nhitballvelocity.y = %.03f, nhitballvelocity.z = %.03f", nhitballvelocity.x, nhitballvelocity.y, nhitballvelocity.z);
				CCLOG("PlayingStateUpdate m_nplayerturn == opponen nstandpos.x = %.03f, nstandpos.y = %.03f, nstandpos.z = %.03f", nstandpos.x, nstandpos.y, nstandpos.z);

				m_nballBody->setLinearVelocity(nhitballvelocity);
				if (nstandpos==Vec3(0,0,0))
				{
					nstandpos = ntargetpos;
				}
				
				//�����ƶ�
				m_nopponen->movetoDestination(BottomDefaultPos);
				m_nplayer->movetoDestination(nstandpos);

				m_nplayerturn = "self";
				m_ncurhitgroundcount = 0;
				m_nhitgroundcount = 0;
				return;
			}
			if (nballpos.z <= m_nchangepos_z)
			{
				getPhysics3DWorld()->setGravity(DefaultGravity + m_naddgravity);

			}
		}
		else if (m_nplayerturn == "self")
		{
			//��������
			Vec3 nplayerpos = m_nplayer->getPosition3D() + Vec3(0, 1, 0);
			CCLOG("self nballpos.x = %.04f nballpos.z = %.04f  nballpos.y = %.04f", nballpos.x, nballpos.z, nballpos.y);
			if (nplayerpos.distance(nballpos) <= 2)
			{
				if (nballpos.z<0 && nballpos.y >= HitMinHeight)
				{
					CCLOG("m_nisfirstplay = %d  m_nselffirst = %d  m_nisvolley = %d  m_nhitgroundcount=%d", m_nisfirstplay, m_nselffirst, m_nisvolley, m_nhitgroundcount);
				}
			}
			if ((nplayerpos.distance(nballpos) <= 2 && nballpos.z >= 0 && nballpos.y >= HitMinHeight) &&
				((m_nisfirstplay&&m_nselffirst) ||
				m_nisvolley ||
				m_nhitgroundcount == 1))
			{
				//����Ч�������뾶1m
				if (m_ntouchstartpos != Vec3(-999, -999, -999) && m_ntouchendpos != Vec3(-999, -999, -999))
				{
					m_naddgravity = Vec3(0, 0, 0);
					Vec3 ntargetpos = getPlayerHitTargetPos(m_ntouchstartpos, m_ntouchendpos);
					Vec3 nhitballvelocity = getVelocityByDestination(ntargetpos);
					
					Vec3 nstandpos = simulationBallFlightPos(nballpos, nhitballvelocity, m_naddgravity, "opponen");
					CCLOG("PlayingStateUpdate m_nplayerturn == self nhitballvelocity.x = %.03f, nhitballvelocity.y = %.03f, nhitballvelocity.z = %.03f", nhitballvelocity.x, nhitballvelocity.y, nhitballvelocity.z);
					CCLOG("PlayingStateUpdate m_nplayerturn == self nstandpos.x = %.03f, nstandpos.y = %.03f, nstandpos.z = %.03f", nstandpos.x, nstandpos.y, nstandpos.z);

					m_nballBody->setLinearVelocity(nhitballvelocity);

					if (nstandpos == Vec3(0, 0, 0))
					{
						nstandpos = ntargetpos;
					}
					m_nplayer->movetoDestination(TopDefaultPos);
					m_nopponen->movetoDestination(nstandpos);
					m_nplayerturn = "opponen";
					m_ntouchstartpos = Vec3(-999, -999, -999);
					m_ntouchendpos = Vec3(-999, -999, -999);
					m_ncurhitgroundcount = 0;
					m_nhitgroundcount = 0;
					return;
				}
			}
			if (nballpos.z >= m_nchangepos_z)
			{
				getPhysics3DWorld()->setGravity(DefaultGravity + m_naddgravity);
			}
		}
	}
	else
	{
		if (m_nisfirstplay&&!m_nselffirst)
		{
			setupBall(m_nselffirst);
		}
		
		//if (m_nplayerturn == "opponen")
		//{
		//	//�����ȷ�
		//	this->runAction(Sequence::create(DelayTime::create(0.2),
		//		CallFuncN::create([=](Node* node){
		//		setupBall(m_nselffirst);
		//	}),
		//		nullptr));	
		//}
	}
}
void GameScene::FaultStateUpdate(float dt)
{
	if (!m_nFaultView)
	{
		ValueVector vec;
		m_nFaultView = UiManager::shareManager()->ShowUI("GameScene/FaultView.csb", vec, CloseType::Auto_Close);
	}
}
void GameScene::ScoreStateUpdate(float dt)
{
	if (!m_nScoreView)
	{
		ValueVector vec;
		vec.push_back(cocos2d::Value(m_nCurScore.SelfPoint));
		vec.push_back(cocos2d::Value(m_nCurScore.OpponenPoint));
		m_nScoreView = UiManager::shareManager()->ShowUI("GameScene/ScoreView.csb", vec, CloseType::Auto_Close);
	}
}
void GameScene::PauseStateUpdate(float dt)
{
	if (!_ispause)
	{
		//���ú󲻻��ٵ���update
		PausePhysicScene();
	}
	if (!m_nStatisticsView)
	{
		ValueVector vec;
		m_nStatisticsView = UiManager::shareManager()->ShowUI("GameScene/StatisticsView.csb", vec);
	}
	
}
void GameScene::FinishStateUpdate(float dt)
{
	if (!m_nResultView)
	{
		ValueVector vec;
		vec.push_back(cocos2d::Value(m_nisselfwin));
		m_nResultView = UiManager::shareManager()->ShowUI("GameScene/ResultView.csb", vec);
	}
}
Vec3 GameScene::simulationBallFlightPos(Vec3 pos, Vec3 velocity,Vec3 gravity,string playturn)
{
	m_nballBody->setLinearVelocity(velocity);
	//m_nballBody->setCollisionCallback(CC_CALLBACK_1(GameScene::VirtualBallCollisionGround, this));
	m_nvirtualhitcount = 0;

	m_nballBody->setCollisionCallback([this](const Physics3DCollisionInfo &ci) 
	{
		m_nvirtualhitcount++;
		CCLOG("m_nvirtualhitcount = %d  ci.objA->getMask() = %d  ci.objB->getMask() = %d", m_nvirtualhitcount, ci.objA->getMask(), ci.objB->getMask());
		if (m_nvirtualhitcount == 1)
		{
			if ((ci.objA->getMask() == GroundMask&&ci.objB->getMask() == BallMask)||
				(ci.objA->getMask() == BallMask&&ci.objB->getMask() == GroundMask))
			{
				getPhysics3DWorld()->setGravity(DefaultGravity);
				//��һ����ײ
				Vec3 nvel = m_nballBody->getLinearVelocity();
				float nmin_y = BallMinHeight;
				float nmax_y = BallMaxHeight;
				float g = fabs(DefaultGravity.y);
				float t1 = sqrt(2.0*nmin_y / g);
				float nminvel = g*t1;
				float t2 = sqrt(2.0*nmax_y / g);
				float nmaxvel = g*t2;
				if (nvel.y<nminvel)
				{
					nvel.y = nminvel;
				}
				else if (nvel.y>nmaxvel)
				{
					nvel.y = nmaxvel;
				}
				m_nballBody->setLinearVelocity(nvel);
			}
		}
	});

	Vec3 nstandpos = Vec3(0, 0, 0);
	for (int i = 0; i<120;i++)//����2s�����е�
	{
		Vec3 nballpos = m_nball->getPosition3D();
		if (playturn =="opponen")
		{
			if (nballpos.z>m_nchangepos_z)
			{
				getPhysics3DWorld()->setGravity(DefaultGravity);
			}
			else
			{
				getPhysics3DWorld()->setGravity(DefaultGravity + gravity);
			}
		}
		else if (playturn == "self")
		{
			if (nballpos.z>m_nchangepos_z)
			{
				getPhysics3DWorld()->setGravity(DefaultGravity + gravity);
			}
			else
			{
				getPhysics3DWorld()->setGravity(DefaultGravity);
			}
		}
		if (m_nvirtualhitcount >= 1)
		{
			getPhysics3DWorld()->setGravity(DefaultGravity);
		}
		_physics3DWorld->stepSimulate(1 / 60.0);
		if (m_nvirtualhitcount>=1)
		{
			Vec3 npos = m_nball->getPosition3D();
			CCLOG("simulationBallFlightPos npos.x = %.03f npos.y = %.03f, npos.z = %.03f", npos.x, npos.y, npos.z);
			if (npos.y <= HitMinHeight&&npos.y >= nstandpos.y)
			{
				nstandpos = npos;
			}
			else if (npos.y > HitMinHeight)
			{
				break;
			}
			
		}
	}
	CCLOG("simulationBallFlightPos nstandpos.x = %.03f nstandpos.y = %.03f, nstandpos.z = %.03f", nstandpos.x, nstandpos.y, nstandpos.z);

	nstandpos.y = 0;
	///*while (true)
	//{
	//	_physics3DWorld->stepSimulate(1 / 60.0);
	//	
	//}*/
	m_nball->setPosition3D(pos);
	getPhysics3DWorld()->setGravity(DefaultGravity);
	m_nballBody->setCollisionCallback(CC_CALLBACK_1(GameScene::BallCollisionGround, this));

	return nstandpos;
}
Vec3 GameScene::getPlayerHitTargetPos(Vec3 startpos, Vec3 endpos)
{
	float nlength = (endpos - startpos).length();
	auto noperatecache = endpos - startpos;
	Vec3 nhittargetpos = BottomDefaultPos;
	if (noperatecache.length() < 0.1)
	{
		//�����߻���
		return nhittargetpos;
	}
	else
	{
		if (m_nisfirstplay)
		{
			//������
			float nsensitivity_x = 10.0f;
			float nbaselength_x = 0.5f;
			float nextremum_x = 0;

			float nstart_z = -DeadZone;
			float nextremum_z = -PlayGroundSize.height/2.0+BorderHeight;
			float nBoundary_z = nstart_z+(nextremum_z - nstart_z) / 2.0;
			float nsensitivity_z = 10.0f;
			float nbaselength_z = 0.5f;

			if (m_nhittoward == "left")
			{
				nextremum_x = -PlayGroundSize.width / 2.0 + BorderWidth;
			}
			else if (m_nhittoward == "right")
			{
				nextremum_x = PlayGroundSize.width / 2.0 - BorderWidth;
			}

			float x = calculateHitTargetPosX(0, nextremum_x, noperatecache.x, nsensitivity_x, nbaselength_x);
			float z = calculateHitTargetPosZ(nstart_z, nextremum_z, nBoundary_z, noperatecache.z, nsensitivity_z, nbaselength_z);
			nhittargetpos.x = x;
			nhittargetpos.z = z;
			return nhittargetpos;
		}
		else
		{
			//��������վ��λ�ú����λ���ж�ʹ�����ַ��֣�����������෴�ֻ������������Ҳ����ֻ���
			//���ݱ���������ļнǼ���
			Vec3 nRcbdis = RightBottomPos - CenterTopPos;
			Vec3 nLcbdis = LeftBottomPos - CenterTopPos;
			Vec3 nRctdis = RightTopPos - CenterBottomPos;
			Vec3 nLctdis = LefttTopPos - CenterBottomPos;

			float nRcbRadian = atan(fabs(nRcbdis.x) / fabs(nRcbdis.z));//�Ҳ�ײ����߼н�
			float nLcbRadian = atan(fabs(nLcbdis.x) / fabs(nLcbdis.z));//���ײ����߼н�
			float nRctRadian = atan(fabs(nRctdis.x) / fabs(nRctdis.z));//�Ҳඥ���߼н�
			float nLctRadian = atan(fabs(nLctdis.x) / fabs(nLctdis.z));//��ඥ�����߼н�

			Vec3 nballpos = m_nball->getPosition3D();//����λ��
			Vec3 nballRbdis = RightBottomPos - nballpos;
			Vec3 nballLbdis = LeftBottomPos - nballpos;
			float nRbRadian = atan(fabs(nballRbdis.x) / fabs(nballRbdis.z));//�����Ҳ�׶�
			float nLbRadian = atan(fabs(nballLbdis.x) / fabs(nballLbdis.z));//�������׶�

			if (noperatecache.x > 0.0)
			{
				//���Ҳ����
				float nextremum_x = PlayGroundSize.width / 2.0 - BorderWidth;
				float nsensitivity_x = 10.0f;
				float nbaselength_x = 0.5f;
				float nstart_x = nballpos.x > 0 ? nballpos.x : 0;
				if (nRbRadian < nRcbRadian / 3.0)
				{
					//������Ҳ�߽����1.0m����
					int nrandom = CommonMethod::getRand(1, 100);
					nhittargetpos.x = nextremum_x - nbaselength_x*nrandom / 100;
				}
				else
				{
					float x = calculateHitTargetPosX(nstart_x, nextremum_x, noperatecache.x, nsensitivity_x, nbaselength_x);
					nhittargetpos.x = x;
				}
			}
			else if (noperatecache.x < 0.0)
			{
				//��������
				float nextremum_x = -PlayGroundSize.width / 2.0 + BorderWidth;
				float nsensitivity_x = 10.0f;
				float nbaselength_x = 0.5f;
				float nstart_x = nballpos.x < 0 ? nballpos.x : 0;
				if (nLbRadian < nLcbRadian / 3.0)
				{
					//��������߽����1.0m����
					int nrandom = CommonMethod::getRand(1, 100);
					nhittargetpos.x = nextremum_x + nbaselength_x*nrandom / 100;
				}
				else
				{
					float x = calculateHitTargetPosX(nstart_x, nextremum_x, noperatecache.x, nsensitivity_x, nbaselength_x);
					nhittargetpos.x = x;
				}
			}

			float nstart_z = -DeadZone;
			float nextremum_z = -PlayGroundSize.height / 2.0;
			float nBoundary_z = -PlayGroundSize.height / 2.0 + BorderHeight;
			float nsensitivity_z = 10.0f;
			float nbaselength_z = 0.5f;

			float z = calculateHitTargetPosZ(nstart_z, nextremum_z, nBoundary_z, noperatecache.z, nsensitivity_z, nbaselength_z);
			nhittargetpos.z = z;
			return nhittargetpos;
		}
	}
	return nhittargetpos;
}
float GameScene::calculateHitTargetPosX(float start, float extremum, float operatelength, float sensitivity, float baselength)
{
	float npos = start;
	float nrange = fabs(operatelength / sensitivity);
	nrange = nrange < 1.0 ? nrange : 1.0;
	int nrandom = CommonMethod::getRand(1, 100);
	if (extremum>0)
	{
		npos = start + (extremum - start - baselength)*nrange + baselength*nrandom / 100.0;
	}
	else
	{
		npos = start + (extremum - start + baselength)*nrange - baselength*nrandom / 100.0;

	}
	return npos;
}
float GameScene::calculateHitTargetPosZ(float start, float extremum, float Boundary,float operatelength, float sensitivity, float baselength)
{
	//extremum С��0
	float npos = start;
	float nrange = fabs(operatelength / sensitivity);
	nrange = nrange < 1.0 ? nrange : 1.0;
	int nrandom = CommonMethod::getRand(1, 100);
	if (operatelength < 0)
	{
		//��ǰ��
		npos = Boundary + (extremum - Boundary + baselength)*nrange - baselength*nrandom/100.0;
	}
	else
	{
		//�����
		npos = Boundary + fabs((Boundary - start + baselength))*nrange + baselength*nrandom/100.0;
	}
	return npos;
}
Vec3 GameScene::getOpponenHitTargetPos()
{
	Vec3 ntargetpos = TopDefaultPos;
	int nrandx = CommonMethod::getRand(1, 100);
	int nrandz = CommonMethod::getRand(1, 100);
	float nDeadZone = DeadZone;//ä������
	if (m_nisfirstplay)
	{
		if (m_nhittoward == "left")
		{
			ntargetpos.x = (PlayGroundSize.width / 2.0 - BorderWidth) * nrandx / 100.0;
			ntargetpos.z = nDeadZone + (PlayGroundSize.height / 2.0 - BorderHeight - nDeadZone)*nrandz / 100.0;
		}
		else if (m_nhittoward == "right")
		{
			ntargetpos.x = (-PlayGroundSize.width / 2.0 + BorderWidth) * nrandx / 100.0;
			ntargetpos.z = nDeadZone + (PlayGroundSize.height / 2.0 - BorderHeight - nDeadZone)*nrandz / 100.0;
		}
	}
	else
	{
		//���ݶ���Ai�����������λ��
		//���ݾ�ȷ�ȵ�����㷶Χ����

		float noutsideodds = m_nopponen->getAccuracy();//�����߾�ȷ��
		ntargetpos.x = (PlayGroundSize.width / 2.0 - BorderWidth)*(nrandx - 50) / 50.0;
		ntargetpos.z = nDeadZone + (PlayGroundSize.height / 2.0 - nDeadZone)*nrandz / 100.0;
	}
	return ntargetpos;
}
float GameScene::getOpponenHitTargetX()
{
	Vec3 nplayerpos = m_nplayer->getPosition3D();
	int nintelligenceLevel = m_nopponen->getIntelligenceLevel();
	int nrand = CommonMethod::getRand(1, 100);
	string nforward = "left";

	if (nplayerpos.x > 0)
	{
		//70%�������� 
		//30%��������
		if (nrand<=70)
		{
			nforward = "left";
		}
		else
		{
			nforward = "right";
		}
	}
	else
	{
		//30%�������� 
		//70%��������
		if (nrand <= 70)
		{
			nforward = "right";
		}
		else
		{
			nforward = "left";
		}
	}

	nrand = CommonMethod::getRand(1, 100);
	if (nforward=="left")
	{
		for (int i = 0; i <= 10;i++)
		{

		}
		//80%�ڱ߽絽�������֮��
		//20%�ڼ�����뵽0֮��

	}
	else
	{
		//80%�ڱ߽絽�������֮��
		//20%�ڼ�����뵽0֮��

	}

	return 1.0;
}
float GameScene::getOpponenHitTargetZ()
{
	return 1.0;
}
Vec3 GameScene::getVelocityByDestination(Vec3 despos)
{
	//Y���ٶȲ�����10m/s
	//X�� velocity.x*t = despos.x-ballpos.x

	//Y�� velocity.y+g*t1 = velocity.tempy
	//Y�� ballpos.y+velocity.y*t1+g*t1*t1/2.0 = S
	//Y�� velocity.tempy*t2+tempg*t2*t2/2.0 = -S

	//Z�� velocity.z*t1 = -ballpos.z
	//Z�� veclocity.z*t2+a*t2*t2/2.0 = despos.z
	
	Vec3 nballpos = m_nball->getPosition3D();
	m_nchangepos_z = 0;
	float npercent = 0.0;
	if (fabs(despos.z)<3.0)
	{

		npercent = fabs(nballpos.z / despos.z);

		float ndis = 2.0*(despos.z - nballpos.z) / 5.0;
		m_nchangepos_z = despos.z - ndis;
	}
	
	float g = DefaultGravity.y;
	float throughnet = 0.5f;//Ԥ���0.5sͨ����
	float t1 = fabs(((m_nchangepos_z-nballpos.z) / (PlayGroundSize.height / 2.0))*throughnet);//����z��λ�ü���ʱ��
	float speedz = (m_nchangepos_z - nballpos.z) / t1;
	float t2 = ((despos.z - m_nchangepos_z) / speedz)*1.2;

	float t2percent = fabs((0 - m_nchangepos_z ) / (despos.z - m_nchangepos_z))*t2;

	float a = 2.0*((despos.z - m_nchangepos_z) - speedz*t2) / (t2*t2);//Z�᷽����ٶ�
	float speedx = (despos.x - nballpos.x)/(t1+t2);
	//0 - nballpos.y = speedy*(t1 + t2) + g / 2.0*(t1 + t2)*(*t1 + t2);
	float speedytemp1 = (-g*(t1 + t2)*(t1 + t2) / 2.0 - nballpos.y)/(t1+t2);
	//NetHeight - nballpos.y = speedy*t1+g/2.0*t1*t1;
	float speedytemp2 = (NetHeight +BallRadius+0.2 - nballpos.y - g*t1*t1 / 2.0) / t1;
	float speedytemp3 = 0;
	if (t2percent!=0)
	{
		//speedytemp3 = (-(NetHeight + BallRadius + 0.2 - nballpos.y) - g*t2percent*t2percent / 2.0) / t2percent - g*t1;
		speedytemp3 = ((NetHeight + BallRadius + 0.2 - nballpos.y) - g*t1*t1 / 2.0 - g*t2percent*t2percent / 2.0 - g*t1*t2percent) / (t1 + t2percent);
		//float speedtemp4 = ;

	}
	
	
	float speedy = speedytemp1 > speedytemp2 ? speedytemp1 : speedytemp2;
	speedy = speedy > speedytemp3 ? speedy : speedytemp3;
	if (m_nchangepos_z!=0)
	{
		speedy = speedy*1.5;
	}
	else
	{
		speedy = speedy*1.1;
	}
	

	float S = nballpos.y + speedy*t1 + g*t1*t1 / 2.0;
	float tempspeedy = speedy + g*t1;
	//tempspeedy*t2 + tempg*t2*t2 / 2.0 = -S;
	float g1 = (-S - tempspeedy*t2)*2.0 / (t2*t2);//Y�����������ٶ�
	g1 = g1 - DefaultGravity.y;

	m_naddgravity = Vec3(0, g1, a);
	return Vec3(speedx, speedy, speedz);

}
//Vec3 GameScene::getVelocityByDestination(Vec3 despos, Vec3 addgravity)
//{
//
//
//
//	//��֪t1 t2 vx vy vz addgravity
//
//	//����Ŀ�����������ʼ�ٶ�
//	/*
//	//����������������Ӱ����ʹ�����ĺ���
//	//��ʱ��Ϊt ��ǰʱ��Ϊt1 ����ʱ��Ϊt2 t = t1+t2
//	//����˼·����Ԥ�������������仯Ϊ0,�������������,�ٸ��ݶ��ֲ��һ�ţ�ٵ��������������ֵ
//	//���ַ����򵥵�������ţ�ٵ��������ҽط��ȣ���C++����ʵ�֣����е���gsl�⺯���Ľⷨ
//	
//	//X�� velocity.x*t = despos.x-ballpos.x
//	
//	//Y�� velocity.y+g*t1 = velocity.tempy
//	//Y�� ballpos.y+velocity.y*t1+g*t1*t1/2.0 = S
//	//Y�� velocity.tempy*t2+tempg*t2*t2/2.0 = S
//
//	//Z�� velocity.z*t1 = -ballpos.z
//	//Z�� veclocity.z*t2+a*t2*t2/2.0 = despos.z
//
//	velocity.x*velocity.x+velocity.y*velocity.y+velocity.z*velocity.z = HitballVelocity*HitballVelocity
//	t = t1+t2
//	*/
//	int ncount = 0;
//	float t1 = 10.0f;
//	float g = DefaultGravity.y;
//	float g1 = DefaultGravity.y + addgravity.y;
//	float a = addgravity.z;
//	Vec3 nballpos = m_nball->getPosition3D();
//	float nUb = t1;
//	float nDb = 0.0;
//	Vec3 nvelocity = Vec3(0, 0, 0);
//	while (ncount<=300)
//	{
//		t1 = t1 / 2;
//		float nspeedz = -nballpos.z/t1;
//		if ((2 * despos.z / a + pow((nspeedz / a), 2)<0))
//		{
//			
//			//nUb = t1;
//			continue;
//		}
//		float temp = sqrt(2 * despos.z / a + pow((nspeedz / a), 2));
//		float temp2 = nspeedz / a;
//
//		float t2 = sqrt(2 * despos.z / a + pow((nspeedz / a), 2)) - nspeedz / a;
//		float nspeedx = (despos.x - nballpos.x) / (t1 + t2);
//		//float nspeedy = (2 *g* t1*t2 - 2 * nballpos.y + g1*t2*t2 - g*t1*t1) / (2*(t1 - t2));
//		float nspeedy = (-nballpos.y - g*t1*t1 / 2.0 - g1*t2*t2 / 2.0 - g*t1*t2) / (t1 + t2);
//		float ndeviation = nspeedx*nspeedx + nspeedy*nspeedy + nspeedz*nspeedz - HitballVelocity*HitballVelocity;
//		nvelocity.x = nspeedx;
//		nvelocity.y = nspeedy;
//		nvelocity.z = nspeedz;
//		CCLOG("ncount = %d  t1 = %.06f t2 = %.06f  nUb = %.06f   nDb = %.06f  ndeviation = %.06f", ncount, t1, t2, nUb, nDb, ndeviation);
//
//		if (ndeviation >= -0.01 && ndeviation <= 0.01)
//		{
//			break;
//		}
//		//else if (ndeviation<0)
//		//{//ʱ���̣��ٶȱ��
//		//	nUb = t1;
//		//	t1 = (nDb + nUb) / 2.0;
//		//}
//		//else if (ndeviation>0)
//		//{//ʱ��䳤���ٶȱ�С
//		//	nDb = t1;
//		//	t1 = (nDb + nUb) / 2.0;
//		//}
//		//ncount++;
//	}
//	
//	/*
//	//X�� velocity.x*t = despos.x-ballpos.x
//	//Y�� velocity.y*t+g*t*t/2.0 = -ballpos.y
//	//Z�� velocity.z*t = despos.z-ballpos.z
//	velocity.x*velocity.x+velocity.y*velocity.y+velocity.z*velocity.z = HitballVelocity*HitballVelocity
//	
//	*/
//	return nvelocity;
//}