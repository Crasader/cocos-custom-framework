#ifndef __LOADING_SCENE_H__
#define __LOADING_SCENE_H__

#include "cocos2d.h"
#include "UiManager.h"
#include "DataManager.h"
#include "Macro.h"

#include <chrono>
#include <thread>
typedef enum 
{
	ResLoad = 0,
	NormalLoad = 1,
	AdLoad = 2,
}LoadingType;
class LoadingScene : public cocos2d::Layer
{
public:
   // static cocos2d::Scene* createScene();
	static cocos2d::Scene*createSceneWithType(LoadingType loadingtype, SCENEID sceneid);
	bool initwithType(LoadingType loadingtype, SCENEID sceneid);
	void initSystemData();
	void initSystemSchedule();
	void registerUI();
	void setUpUIWithData();
	void registerLoadingSceneSystemKeyBoard();
	void LoadingSceneonKeyPressed(EventKeyboard::KeyCode code, Event* event);
	void update(float dt);
	void updateResloading(float dt);
	void updateNormalloading(float dt);
	void updateAdloading(float dt);
	void LoadData(int threadid);
	void onEnter();
	void onEnterTransitionDidFinish();
	void onExitTransitionDidStart();
	void onExit();
	void cleanup();
	CREATE_FUNC(LoadingScene);
protected:
	LoadingType m_nloadtype;
	SCENEID m_nsceneid;
	bool m_nchangescene;
	bool m_nprocessThread;
	float m_npercent;

	Node *m_nrootNode;
	LoadingBar*m_nLoadingBar;
	
};

#endif // __LOADING_SCENE_H__
