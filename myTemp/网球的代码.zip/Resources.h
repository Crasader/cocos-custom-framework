#ifndef _AUTO_RESOURCES_H_
#define _AUTO_RESOURCES_H_

// search paths
static const std::vector<std::string> searchPaths = {
	"fonts",
	"res",
	"res/3DModel",
	"res/AllPicRes",
	"res/AllPicRes/Background",
	"res/AllPicRes/General",
	"res/AllPicRes/Racket",
	"res/AllPicRes/Role",
	"res/AllPicRes/SceneDressing",
	"res/AllPicRes/SceneLoading",
	"res/AllPicRes/SceneLoading/tennis_anim",
	"res/AllPicRes/SceneMain",
	"res/AllPicRes/Shoe",
	"res/Data",
	"res/Default",
	"res/Fonts",
	"res/Fonts/zh",
	"res/GameScene",
	"res/Image",
	"res/Images",
	"res/Images/.blocks9ss_PList.Dir",
	"res/Images/.bug12847_spriteframe_PList.Dir",
	"res/Images/.ui_PList.Dir",
	"res/Images/bugs",
	"res/Images/bugs/.circle_PList.Dir",
	"res/Images/sprites_test",
	"res/iphone",
	"res/LoadingScene",
	"res/model",
	"res/Scene",
	"res/Scene/SceneDressing",
	"res/Scene/SceneLoading",
	"res/Scene/SceneMain",
	"res/Shaders3D",
	"res/shadow",
	"res/spine",
	"res/Sprite3DTest",
	"res/Sprite3DTest/skybox",
};

// files
static const char img_ball[]		 = "ball.png"; 
static const char img_CloseNormal[]		 = "CloseNormal.png"; 
static const char img_CloseSelected[]		 = "CloseSelected.png"; 
static const char img_dot[]		 = "dot.png"; 
static const char json_file_list[]		 = "file_list.json"; 
static const char img_HelloWorld[]		 = "HelloWorld.png"; 
static const char json_Test[]		 = "Test.json"; 
static const char ttf_arial[]		 = "fonts/arial.ttf"; 
static const char ttf_MarkerFelt[]		 = "fonts/Marker Felt.ttf"; 
static const char file_gitkeep[]		 = "res/.gitkeep"; 
static const char csb_MainScene[]		 = "res/MainScene.csb"; 
static const char c3t_box[]		 = "res/3DModel/box.c3t"; 
static const char c3b_sphere[]		 = "res/3DModel/sphere.c3b"; 
static const char img_Background[]		 = "res/AllPicRes/Background/Background.png"; 
static const char plist_PlistGeneral[]		 = "res/AllPicRes/General/PlistGeneral.plist"; 
static const char img_PlistGeneral[]		 = "res/AllPicRes/General/PlistGeneral.png"; 
static const char plist_PlistRacket[]		 = "res/AllPicRes/Racket/PlistRacket.plist"; 
static const char img_PlistRacket[]		 = "res/AllPicRes/Racket/PlistRacket.png"; 
static const char plist_PlistRole[]		 = "res/AllPicRes/Role/PlistRole.plist"; 
static const char img_PlistRole[]		 = "res/AllPicRes/Role/PlistRole.png"; 
static const char plist_PlistSceneDressing[]		 = "res/AllPicRes/SceneDressing/PlistSceneDressing.plist"; 
static const char img_PlistSceneDressing[]		 = "res/AllPicRes/SceneDressing/PlistSceneDressing.png"; 
static const char img_Loading01[]		 = "res/AllPicRes/SceneLoading/Loading01.png"; 
static const char plist_PlistTennis[]		 = "res/AllPicRes/SceneLoading/tennis_anim/PlistTennis.plist"; 
static const char img_PlistTennis[]		 = "res/AllPicRes/SceneLoading/tennis_anim/PlistTennis.png"; 
static const char plist_PlistSceneMain[]		 = "res/AllPicRes/SceneMain/PlistSceneMain.plist"; 
static const char img_PlistSceneMain[]		 = "res/AllPicRes/SceneMain/PlistSceneMain.png"; 
static const char plist_PlistDressRoomShoe[]		 = "res/AllPicRes/Shoe/PlistDressRoomShoe.plist"; 
static const char img_PlistDressRoomShoe[]		 = "res/AllPicRes/Shoe/PlistDressRoomShoe.png"; 
static const char json_Entrances[]		 = "res/Data/Entrances.json"; 
static const char json_Racquets[]		 = "res/Data/Racquets.json"; 
static const char json_Role[]		 = "res/Data/Role.json"; 
static const char json_Shoes[]		 = "res/Data/Shoes.json"; 
static const char img_Button_Disable[]		 = "res/Default/Button_Disable.png"; 
static const char img_Button_Normal[]		 = "res/Default/Button_Normal.png"; 
static const char img_Button_Press[]		 = "res/Default/Button_Press.png"; 
static const char ttf_describe[]		 = "res/Fonts/zh/describe.ttf"; 
static const char csb_FaultView[]		 = "res/GameScene/FaultView.csb"; 
static const char csb_GameView[]		 = "res/GameScene/GameView.csb"; 
static const char csb_ResultView[]		 = "res/GameScene/ResultView.csb"; 
static const char csb_ScoreView[]		 = "res/GameScene/ScoreView.csb"; 
static const char csb_StatisticsView[]		 = "res/GameScene/StatisticsView.csb"; 
static const char img_background[]		 = "res/Image/background.png"; 
static const char img_bluebackground[]		 = "res/Image/bluebackground.png"; 
static const char img_graybackground[]		 = "res/Image/graybackground.png"; 
static const char img_GreenBackGround[]		 = "res/Image/GreenBackGround.png"; 
static const char img_null[]		 = "res/Image/null.png"; 
static const char img_playground[]		 = "res/Image/playground.png"; 
static const char img_S128[]		 = "res/Image/S128.png"; 
static const char img_S143[]		 = "res/Image/S143.png"; 
static const char img_S144[]		 = "res/Image/S144.png"; 
static const char img_shadow[]		 = "res/Image/shadow.png"; 
static const char img_wangqiu[]		 = "res/Image/wangqiu.png"; 
static const char img_arrows_hd[]		 = "res/Images/arrows-hd.png"; 
static const char img_arrows[]		 = "res/Images/arrows.png"; 
static const char img_arrowsBar_hd[]		 = "res/Images/arrowsBar-hd.png"; 
static const char img_arrowsBar[]		 = "res/Images/arrowsBar.png"; 
static const char img_assetMgrBackground1[]		 = "res/Images/assetMgrBackground1.jpg"; 
static const char img_assetMgrBackground2[]		 = "res/Images/assetMgrBackground2.png"; 
static const char img_assetMgrBackground3[]		 = "res/Images/assetMgrBackground3.png"; 
static const char img_atlastest[]		 = "res/Images/atlastest.png"; 
static const char img_b1[]		 = "res/Images/b1.png"; 
static const char img_b2[]		 = "res/Images/b2.png"; 
static const char fnt_bitmapFontTest3[]		 = "res/Images/bitmapFontTest3.fnt"; 
static const char img_bitmapFontTest3[]		 = "res/Images/bitmapFontTest3.png"; 
static const char img_blocks[]		 = "res/Images/blocks.png"; 
static const char img_blocks9[]		 = "res/Images/blocks9.png"; 
static const char img_blocks9c[]		 = "res/Images/blocks9c.png"; 
static const char img_blocks9cr[]		 = "res/Images/blocks9cr.png"; 
static const char img_blocks9r[]		 = "res/Images/blocks9r.png"; 
static const char plist_blocks9ss[]		 = "res/Images/blocks9ss.plist"; 
static const char img_blocks9ss[]		 = "res/Images/blocks9ss.png"; 
static const char tps_blocks9ss[]		 = "res/Images/blocks9ss.tps"; 
static const char plist_BoilingFoam[]		 = "res/Images/BoilingFoam.plist"; 
static const char img_btn_about_normal_vertical[]		 = "res/Images/btn-about-normal-vertical.png"; 
static const char img_btn_about_normal[]		 = "res/Images/btn-about-normal.png"; 
static const char img_btn_about_selected[]		 = "res/Images/btn-about-selected.png"; 
static const char img_btn_highscores_normal[]		 = "res/Images/btn-highscores-normal.png"; 
static const char img_btn_highscores_selected[]		 = "res/Images/btn-highscores-selected.png"; 
static const char img_btn_play_normal[]		 = "res/Images/btn-play-normal.png"; 
static const char img_btn_play_selected[]		 = "res/Images/btn-play-selected.png"; 
static const char img_bug12847_sprite[]		 = "res/Images/bug12847_sprite.png"; 
static const char plist_bug12847_spriteframe[]		 = "res/Images/bug12847_spriteframe.plist"; 
static const char img_bug12847_spriteframe[]		 = "res/Images/bug12847_spriteframe.png"; 
static const char img_close[]		 = "res/Images/close.png"; 
static const char img_cocos_html5[]		 = "res/Images/cocos-html5.png"; 
static const char img_cocos2dbanner[]		 = "res/Images/cocos2dbanner.png"; 
static const char img_Comet[]		 = "res/Images/Comet.png"; 
static const char img_CyanSquare[]		 = "res/Images/CyanSquare.png"; 
static const char img_CyanTriangle[]		 = "res/Images/CyanTriangle.png"; 
static const char img_elephant1_Diffuse[]		 = "res/Images/elephant1_Diffuse.png"; 
static const char img_elephant1_Normal[]		 = "res/Images/elephant1_Normal.png"; 
static const char tps_encryptedAtlas[]		 = "res/Images/encryptedAtlas.tps"; 
static const char pkm_ETC1[]		 = "res/Images/ETC1.pkm"; 
static const char img_f1[]		 = "res/Images/f1.png"; 
static const char img_f2[]		 = "res/Images/f2.png"; 
static const char ico_favicon[]		 = "res/Images/favicon.ico"; 
static const char img_fire_grayscale[]		 = "res/Images/fire-grayscale.png"; 
static const char img_fire[]		 = "res/Images/fire.png"; 
static const char img_Fog[]		 = "res/Images/Fog.png"; 
static const char img_fps_images[]		 = "res/Images/fps_images.png"; 
static const char img_grossini[]		 = "res/Images/grossini.png"; 
static const char img_grossinis_sister1_testalpha[]		 = "res/Images/grossinis_sister1-testalpha.png"; 
static const char ppng_grossinis_sister1_testalpha[]		 = "res/Images/grossinis_sister1-testalpha.ppng"; 
static const char img_grossinis_sister1[]		 = "res/Images/grossinis_sister1.png"; 
static const char img_grossinis_sister2[]		 = "res/Images/grossinis_sister2.png"; 
static const char img_grossini_dance_01[]		 = "res/Images/grossini_dance_01.png"; 
static const char img_grossini_dance_02[]		 = "res/Images/grossini_dance_02.png"; 
static const char img_grossini_dance_03[]		 = "res/Images/grossini_dance_03.png"; 
static const char img_grossini_dance_04[]		 = "res/Images/grossini_dance_04.png"; 
static const char img_grossini_dance_05[]		 = "res/Images/grossini_dance_05.png"; 
static const char img_grossini_dance_06[]		 = "res/Images/grossini_dance_06.png"; 
static const char img_grossini_dance_07[]		 = "res/Images/grossini_dance_07.png"; 
static const char img_grossini_dance_08[]		 = "res/Images/grossini_dance_08.png"; 
static const char img_grossini_dance_09[]		 = "res/Images/grossini_dance_09.png"; 
static const char img_grossini_dance_10[]		 = "res/Images/grossini_dance_10.png"; 
static const char img_grossini_dance_11[]		 = "res/Images/grossini_dance_11.png"; 
static const char img_grossini_dance_12[]		 = "res/Images/grossini_dance_12.png"; 
static const char img_grossini_dance_13[]		 = "res/Images/grossini_dance_13.png"; 
static const char img_grossini_dance_14[]		 = "res/Images/grossini_dance_14.png"; 
static const char img_grossini_dance_atlas_mono[]		 = "res/Images/grossini_dance_atlas-mono.png"; 
static const char img_grossini_dance_atlas[]		 = "res/Images/grossini_dance_atlas.png"; 
static const char img_grossini_dance_atlas_nomipmap[]		 = "res/Images/grossini_dance_atlas_nomipmap.png"; 
static const char raw_heightfield64x64[]		 = "res/Images/heightfield64x64.raw"; 
static const char img_hole_effect[]		 = "res/Images/hole_effect.png"; 
static const char img_hole_stencil[]		 = "res/Images/hole_stencil.png"; 
static const char img_Icon[]		 = "res/Images/Icon.png"; 
static const char img_labelatlas[]		 = "res/Images/labelatlas.png"; 
static const char plist_lookup_desktop[]		 = "res/Images/lookup-desktop.plist"; 
static const char plist_lookup_html5[]		 = "res/Images/lookup-html5.plist"; 
static const char plist_lookup_mobile[]		 = "res/Images/lookup-mobile.plist"; 
static const char img_MagentaSquare[]		 = "res/Images/MagentaSquare.png"; 
static const char img_menuitemsprite[]		 = "res/Images/menuitemsprite.png"; 
static const char img_movement[]		 = "res/Images/movement.png"; 
static const char img_noise[]		 = "res/Images/noise.png"; 
static const char tps_nonencryptedAtlas[]		 = "res/Images/nonencryptedAtlas.tps"; 
static const char img_paddle[]		 = "res/Images/paddle.png"; 
static const char img_particles_hd[]		 = "res/Images/particles-hd.png"; 
static const char img_particles[]		 = "res/Images/particles.png"; 
static const char img_pattern1[]		 = "res/Images/pattern1.png"; 
static const char img_Pea[]		 = "res/Images/Pea.png"; 
static const char img_piece[]		 = "res/Images/piece.png"; 
static const char img_powered[]		 = "res/Images/powered.png"; 
static const char img_r1[]		 = "res/Images/r1.png"; 
static const char img_r2[]		 = "res/Images/r2.png"; 
static const char img_SendScoreButton[]		 = "res/Images/SendScoreButton.png"; 
static const char img_SendScoreButtonPressed[]		 = "res/Images/SendScoreButtonPressed.png"; 
static const char img_shapemode[]		 = "res/Images/shapemode.png"; 
static const char img_snow[]		 = "res/Images/snow.png"; 
static const char img_SpinningPeas[]		 = "res/Images/SpinningPeas.png"; 
static const char img_SpookyPeas[]		 = "res/Images/SpookyPeas.png"; 
static const char img_stars_grayscale[]		 = "res/Images/stars-grayscale.png"; 
static const char img_stars[]		 = "res/Images/stars.png"; 
static const char img_stars2_grayscale[]		 = "res/Images/stars2-grayscale.png"; 
static const char img_stars2[]		 = "res/Images/stars2.png"; 
static const char img_stone[]		 = "res/Images/stone.png"; 
static const char img_streak[]		 = "res/Images/streak.png"; 
static const char img_test_rgba1[]		 = "res/Images/test-rgba1.png"; 
static const char gz_test_1021x1024_a8_pvr[]		 = "res/Images/test_1021x1024_a8.pvr.gz"; 
static const char ktx_test_256x256_ATC_RGBA_Explicit_mipmaps[]		 = "res/Images/test_256x256_ATC_RGBA_Explicit_mipmaps.ktx"; 
static const char ktx_test_256x256_ATC_RGBA_Interpolated_mipmaps[]		 = "res/Images/test_256x256_ATC_RGBA_Interpolated_mipmaps.ktx"; 
static const char ktx_test_256x256_ATC_RGB_mipmaps[]		 = "res/Images/test_256x256_ATC_RGB_mipmaps.ktx"; 
static const char dds_test_256x256_s3tc_dxt1_mipmaps[]		 = "res/Images/test_256x256_s3tc_dxt1_mipmaps.dds"; 
static const char dds_test_256x256_s3tc_dxt3_mipmaps[]		 = "res/Images/test_256x256_s3tc_dxt3_mipmaps.dds"; 
static const char dds_test_256x256_s3tc_dxt5_mipmaps[]		 = "res/Images/test_256x256_s3tc_dxt5_mipmaps.dds"; 
static const char dds_test_512x512_s3tc_dxt5_with_no_mipmaps[]		 = "res/Images/test_512x512_s3tc_dxt5_with_no_mipmaps.dds"; 
static const char img_test_blend[]		 = "res/Images/test_blend.png"; 
static const char jpeg_test_image[]		 = "res/Images/test_image.jpeg"; 
static const char img_test_image[]		 = "res/Images/test_image.png"; 
static const char tiff_test_image[]		 = "res/Images/test_image.tiff"; 
static const char webp_test_image[]		 = "res/Images/test_image.webp"; 
static const char img_test_image_ai88[]		 = "res/Images/test_image_ai88.png"; 
static const char img_test_image_i8[]		 = "res/Images/test_image_i8.png"; 
static const char webp_test_image_no_alpha[]		 = "res/Images/test_image_no_alpha.webp"; 
static const char img_test_image_rgb888[]		 = "res/Images/test_image_rgb888.png"; 
static const char ccz_test_image_rgba4444_pvr[]		 = "res/Images/test_image_rgba4444.pvr.ccz"; 
static const char gz_test_image_rgba4444_pvr[]		 = "res/Images/test_image_rgba4444.pvr.gz"; 
static const char img_test_image_rgba8888[]		 = "res/Images/test_image_rgba8888.png"; 
static const char img_texture1024x1024[]		 = "res/Images/texture1024x1024.png"; 
static const char img_texture2048x2048[]		 = "res/Images/texture2048x2048.png"; 
static const char img_texture512x512[]		 = "res/Images/texture512x512.png"; 
static const char img_texturemode[]		 = "res/Images/texturemode.png"; 
static const char plist_ui[]		 = "res/Images/ui.plist"; 
static const char img_ui[]		 = "res/Images/ui.png"; 
static const char dds_water_2_dxt1[]		 = "res/Images/water_2_dxt1.dds"; 
static const char dds_water_2_dxt3[]		 = "res/Images/water_2_dxt3.dds"; 
static const char dds_water_2_dxt5[]		 = "res/Images/water_2_dxt5.dds"; 
static const char img_white_512x512[]		 = "res/Images/white-512x512.png"; 
static const char img_wood[]		 = "res/Images/wood.jpg"; 
static const char img_YellowSquare[]		 = "res/Images/YellowSquare.png"; 
static const char img_YellowTriangle[]		 = "res/Images/YellowTriangle.png"; 
static const char img_grossini_dance01[]		 = "res/Images/.blocks9ss_PList.Dir/grossini_dance01.png"; 
static const char img_grossini_dance02[]		 = "res/Images/.blocks9ss_PList.Dir/grossini_dance02.png"; 
static const char img_grossini_dance03[]		 = "res/Images/.blocks9ss_PList.Dir/grossini_dance03.png"; 
static const char xml_InfoConfig[]		 = "res/Images/.blocks9ss_PList.Dir/InfoConfig.xml"; 
static const char img_bug12847_sprite2[]		 = "res/Images/.bug12847_spriteframe_PList.Dir/bug12847_sprite2.png"; 
static const char img_button_actived[]		 = "res/Images/.ui_PList.Dir/button_actived.png"; 
static const char img_button_normal[]		 = "res/Images/.ui_PList.Dir/button_normal.png"; 
static const char img_coin[]		 = "res/Images/.ui_PList.Dir/coin.png"; 
static const char img_crystal[]		 = "res/Images/.ui_PList.Dir/crystal.png"; 
static const char img_dialog_bg[]		 = "res/Images/.ui_PList.Dir/dialog_bg.png"; 
static const char img_dialog_corner[]		 = "res/Images/.ui_PList.Dir/dialog_corner.png"; 
static const char img_item_bg[]		 = "res/Images/.ui_PList.Dir/item_bg.png"; 
static const char img_mini_map_bg[]		 = "res/Images/.ui_PList.Dir/mini_map_bg.png"; 
static const char img_user_info_panel[]		 = "res/Images/.ui_PList.Dir/user_info_panel.png"; 
static const char plist_circle[]		 = "res/Images/bugs/circle.plist"; 
static const char img_circle[]		 = "res/Images/bugs/circle.png"; 
static const char img_corner[]		 = "res/Images/bugs/corner.png"; 
static const char img_edge[]		 = "res/Images/bugs/edge.png"; 
static const char img_fill[]		 = "res/Images/bugs/fill.png"; 
static const char img_picture[]		 = "res/Images/bugs/picture.png"; 
static const char img_RetinaDisplay[]		 = "res/Images/bugs/RetinaDisplay.jpg"; 
static const char img_sprite_0_0[]		 = "res/Images/sprites_test/sprite-0-0.png"; 
static const char img_sprite_0_1[]		 = "res/Images/sprites_test/sprite-0-1.png"; 
static const char img_sprite_0_2[]		 = "res/Images/sprites_test/sprite-0-2.png"; 
static const char img_sprite_0_3[]		 = "res/Images/sprites_test/sprite-0-3.png"; 
static const char img_sprite_0_4[]		 = "res/Images/sprites_test/sprite-0-4.png"; 
static const char img_sprite_0_5[]		 = "res/Images/sprites_test/sprite-0-5.png"; 
static const char img_sprite_0_6[]		 = "res/Images/sprites_test/sprite-0-6.png"; 
static const char img_sprite_0_7[]		 = "res/Images/sprites_test/sprite-0-7.png"; 
static const char img_sprite_1_0[]		 = "res/Images/sprites_test/sprite-1-0.png"; 
static const char img_sprite_1_1[]		 = "res/Images/sprites_test/sprite-1-1.png"; 
static const char img_sprite_1_2[]		 = "res/Images/sprites_test/sprite-1-2.png"; 
static const char img_sprite_1_3[]		 = "res/Images/sprites_test/sprite-1-3.png"; 
static const char img_sprite_1_4[]		 = "res/Images/sprites_test/sprite-1-4.png"; 
static const char img_sprite_1_5[]		 = "res/Images/sprites_test/sprite-1-5.png"; 
static const char img_sprite_1_6[]		 = "res/Images/sprites_test/sprite-1-6.png"; 
static const char img_sprite_1_7[]		 = "res/Images/sprites_test/sprite-1-7.png"; 
static const char img_sprite_2_0[]		 = "res/Images/sprites_test/sprite-2-0.png"; 
static const char img_sprite_2_1[]		 = "res/Images/sprites_test/sprite-2-1.png"; 
static const char img_sprite_2_2[]		 = "res/Images/sprites_test/sprite-2-2.png"; 
static const char img_sprite_2_3[]		 = "res/Images/sprites_test/sprite-2-3.png"; 
static const char img_sprite_2_4[]		 = "res/Images/sprites_test/sprite-2-4.png"; 
static const char img_sprite_2_5[]		 = "res/Images/sprites_test/sprite-2-5.png"; 
static const char img_sprite_2_6[]		 = "res/Images/sprites_test/sprite-2-6.png"; 
static const char img_sprite_2_7[]		 = "res/Images/sprites_test/sprite-2-7.png"; 
static const char img_sprite_3_0[]		 = "res/Images/sprites_test/sprite-3-0.png"; 
static const char img_sprite_3_1[]		 = "res/Images/sprites_test/sprite-3-1.png"; 
static const char img_sprite_3_2[]		 = "res/Images/sprites_test/sprite-3-2.png"; 
static const char img_sprite_3_3[]		 = "res/Images/sprites_test/sprite-3-3.png"; 
static const char img_sprite_3_4[]		 = "res/Images/sprites_test/sprite-3-4.png"; 
static const char img_sprite_3_5[]		 = "res/Images/sprites_test/sprite-3-5.png"; 
static const char img_sprite_3_6[]		 = "res/Images/sprites_test/sprite-3-6.png"; 
static const char img_sprite_3_7[]		 = "res/Images/sprites_test/sprite-3-7.png"; 
static const char img_sprite_4_0[]		 = "res/Images/sprites_test/sprite-4-0.png"; 
static const char img_sprite_4_1[]		 = "res/Images/sprites_test/sprite-4-1.png"; 
static const char img_sprite_4_2[]		 = "res/Images/sprites_test/sprite-4-2.png"; 
static const char img_sprite_4_3[]		 = "res/Images/sprites_test/sprite-4-3.png"; 
static const char img_sprite_4_4[]		 = "res/Images/sprites_test/sprite-4-4.png"; 
static const char img_sprite_4_5[]		 = "res/Images/sprites_test/sprite-4-5.png"; 
static const char img_sprite_4_6[]		 = "res/Images/sprites_test/sprite-4-6.png"; 
static const char img_sprite_4_7[]		 = "res/Images/sprites_test/sprite-4-7.png"; 
static const char img_sprite_5_0[]		 = "res/Images/sprites_test/sprite-5-0.png"; 
static const char img_sprite_5_1[]		 = "res/Images/sprites_test/sprite-5-1.png"; 
static const char img_sprite_5_2[]		 = "res/Images/sprites_test/sprite-5-2.png"; 
static const char img_sprite_5_3[]		 = "res/Images/sprites_test/sprite-5-3.png"; 
static const char img_sprite_5_4[]		 = "res/Images/sprites_test/sprite-5-4.png"; 
static const char img_sprite_5_5[]		 = "res/Images/sprites_test/sprite-5-5.png"; 
static const char img_sprite_5_6[]		 = "res/Images/sprites_test/sprite-5-6.png"; 
static const char img_sprite_5_7[]		 = "res/Images/sprites_test/sprite-5-7.png"; 
static const char img_sprite_6_0[]		 = "res/Images/sprites_test/sprite-6-0.png"; 
static const char img_sprite_6_1[]		 = "res/Images/sprites_test/sprite-6-1.png"; 
static const char img_sprite_6_2[]		 = "res/Images/sprites_test/sprite-6-2.png"; 
static const char img_sprite_6_3[]		 = "res/Images/sprites_test/sprite-6-3.png"; 
static const char img_sprite_6_4[]		 = "res/Images/sprites_test/sprite-6-4.png"; 
static const char img_sprite_6_5[]		 = "res/Images/sprites_test/sprite-6-5.png"; 
static const char img_sprite_6_6[]		 = "res/Images/sprites_test/sprite-6-6.png"; 
static const char img_sprite_6_7[]		 = "res/Images/sprites_test/sprite-6-7.png"; 
static const char img_sprite_7_0[]		 = "res/Images/sprites_test/sprite-7-0.png"; 
static const char img_sprite_7_1[]		 = "res/Images/sprites_test/sprite-7-1.png"; 
static const char img_sprite_7_2[]		 = "res/Images/sprites_test/sprite-7-2.png"; 
static const char img_sprite_7_3[]		 = "res/Images/sprites_test/sprite-7-3.png"; 
static const char img_sprite_7_4[]		 = "res/Images/sprites_test/sprite-7-4.png"; 
static const char img_sprite_7_5[]		 = "res/Images/sprites_test/sprite-7-5.png"; 
static const char img_sprite_7_6[]		 = "res/Images/sprites_test/sprite-7-6.png"; 
static const char img_sprite_7_7[]		 = "res/Images/sprites_test/sprite-7-7.png"; 
static const char csb_LoadingScene[]		 = "res/LoadingScene/LoadingScene.csb"; 
static const char c3b_box[]		 = "res/model/box.c3b"; 
static const char img_brick[]		 = "res/model/brick.jpg"; 
static const char c3b_ground[]		 = "res/model/ground.c3b"; 
static const char csb_GoodsItem[]		 = "res/Scene/SceneDressing/GoodsItem.csb"; 
static const char csb_SceneDressing[]		 = "res/Scene/SceneDressing/SceneDressing.csb"; 
static const char csb_SceneLoading[]		 = "res/Scene/SceneLoading/SceneLoading.csb"; 
static const char csb_EntranceItem[]		 = "res/Scene/SceneMain/EntranceItem.csb"; 
static const char csb_SceneMain[]		 = "res/Scene/SceneMain/SceneMain.csb"; 
static const char frag_3d_color_normal_tex[]		 = "res/Shaders3D/3d_color_normal_tex.frag"; 
static const char frag_3d_color_tex[]		 = "res/Shaders3D/3d_color_tex.frag"; 
static const char vert_3d_position_normal_tex[]		 = "res/Shaders3D/3d_position_normal_tex.vert"; 
static const char vert_3d_position_skin_tex[]		 = "res/Shaders3D/3d_position_skin_tex.vert"; 
static const char vert_3d_position_tex[]		 = "res/Shaders3D/3d_position_tex.vert"; 
static const char frag_Normal[]		 = "res/Shaders3D/Normal.frag"; 
static const char frag_OutLine[]		 = "res/Shaders3D/OutLine.frag"; 
static const char vert_OutLine[]		 = "res/Shaders3D/OutLine.vert"; 
static const char vert_SkinnedOutline[]		 = "res/Shaders3D/SkinnedOutline.vert"; 
static const char material_FakeShadow[]		 = "res/shadow/FakeShadow.material"; 
static const char img_shadowCircle[]		 = "res/shadow/shadowCircle.png"; 
static const char frag_simple_shadow[]		 = "res/shadow/simple_shadow.frag"; 
static const char vert_simple_shadow[]		 = "res/shadow/simple_shadow.vert"; 
static const char atlas_goblins_ffd[]		 = "res/spine/goblins-ffd.atlas"; 
static const char json_goblins_ffd[]		 = "res/spine/goblins-ffd.json"; 
static const char img_goblins_ffd[]		 = "res/spine/goblins-ffd.png"; 
static const char atlas_goblins[]		 = "res/spine/goblins.atlas"; 
static const char json_goblins[]		 = "res/spine/goblins.json"; 
static const char img_goblins[]		 = "res/spine/goblins.png"; 
static const char atlas_man1[]		 = "res/spine/man1.atlas"; 
static const char json_man1[]		 = "res/spine/man1.json"; 
static const char img_man1[]		 = "res/spine/man1.png"; 
static const char atlas_man1_z[]		 = "res/spine/man1_z.atlas"; 
static const char json_man1_z[]		 = "res/spine/man1_z.json"; 
static const char img_man1_z[]		 = "res/spine/man1_z.png"; 
static const char atlas_raptor[]		 = "res/spine/raptor.atlas"; 
static const char json_raptor[]		 = "res/spine/raptor.json"; 
static const char img_raptor[]		 = "res/spine/raptor.png"; 
static const char atlas_spineboy[]		 = "res/spine/spineboy.atlas"; 
static const char json_spineboy[]		 = "res/spine/spineboy.json"; 
static const char img_spineboy[]		 = "res/spine/spineboy.png"; 
static const char img_sprite[]		 = "res/spine/sprite.png"; 
static const char img_arx[]		 = "res/Sprite3DTest/arx.png"; 
static const char c3b_axe[]		 = "res/Sprite3DTest/axe.c3b"; 
static const char c3b_ball[]		 = "res/Sprite3DTest/ball.c3b"; 
static const char material_BasicToon[]		 = "res/Sprite3DTest/BasicToon.material"; 
static const char img_body[]		 = "res/Sprite3DTest/body.png"; 
static const char c3b_boss[]		 = "res/Sprite3DTest/boss.c3b"; 
static const char img_boss[]		 = "res/Sprite3DTest/boss.png"; 
static const char c3t_box_VertexCol[]		 = "res/Sprite3DTest/box_VertexCol.c3t"; 
static const char img_brickwork_texture[]		 = "res/Sprite3DTest/brickwork-texture.jpg"; 
static const char img_brickwork_normal_map[]		 = "res/Sprite3DTest/brickwork_normal-map.jpg"; 
static const char img_caustics[]		 = "res/Sprite3DTest/caustics.png"; 
static const char material_CubeMap[]		 = "res/Sprite3DTest/CubeMap.material"; 
static const char frag_cube_map[]		 = "res/Sprite3DTest/cube_map.frag"; 
static const char vert_cube_map[]		 = "res/Sprite3DTest/cube_map.vert"; 
static const char c3b_cylinder[]		 = "res/Sprite3DTest/cylinder.c3b"; 
static const char frag_cylinder[]		 = "res/Sprite3DTest/cylinder.frag"; 
static const char vert_cylinder[]		 = "res/Sprite3DTest/cylinder.vert"; 
static const char img_dragon[]		 = "res/Sprite3DTest/dragon.png"; 
static const char img_Floor[]		 = "res/Sprite3DTest/Floor.png"; 
static const char frag_fog[]		 = "res/Sprite3DTest/fog.frag"; 
static const char vert_fog[]		 = "res/Sprite3DTest/fog.vert"; 
static const char c3b_girl[]		 = "res/Sprite3DTest/girl.c3b"; 
static const char img_Girl_Face[]		 = "res/Sprite3DTest/Girl_Face.png"; 
static const char img_Girl_Glasses01[]		 = "res/Sprite3DTest/Girl_Glasses01.png"; 
static const char img_Girl_Hair01[]		 = "res/Sprite3DTest/Girl_Hair01.png"; 
static const char img_Girl_Hair02[]		 = "res/Sprite3DTest/Girl_Hair02.png"; 
static const char img_Girl_Hand[]		 = "res/Sprite3DTest/Girl_Hand.png"; 
static const char img_Girl_LowerBody01[]		 = "res/Sprite3DTest/Girl_LowerBody01.png"; 
static const char img_Girl_LowerBody02[]		 = "res/Sprite3DTest/Girl_LowerBody02.png"; 
static const char img_Girl_Shoes01[]		 = "res/Sprite3DTest/Girl_Shoes01.png"; 
static const char img_Girl_Shoes02[]		 = "res/Sprite3DTest/Girl_Shoes02.png"; 
static const char img_Girl_UpperBody01[]		 = "res/Sprite3DTest/Girl_UpperBody01.png"; 
static const char img_Girl_UpperBody02[]		 = "res/Sprite3DTest/Girl_UpperBody02.png"; 
static const char c3b_LightMapScene[]		 = "res/Sprite3DTest/LightMapScene.c3b"; 
static const char c3b_mesh_model[]		 = "res/Sprite3DTest/mesh_model.c3b"; 
static const char tga_monguger[]		 = "res/Sprite3DTest/monguger.tga"; 
static const char c3b_orc[]		 = "res/Sprite3DTest/orc.c3b"; 
static const char c3t_orc[]		 = "res/Sprite3DTest/orc.c3t"; 
static const char c3t_orc_jump[]		 = "res/Sprite3DTest/orc_jump.c3t"; 
static const char material_outline[]		 = "res/Sprite3DTest/outline.material"; 
static const char c3t_plane[]		 = "res/Sprite3DTest/plane.c3t"; 
static const char img_plane[]		 = "res/Sprite3DTest/plane.png"; 
static const char c3b_ReskinGirl[]		 = "res/Sprite3DTest/ReskinGirl.c3b"; 
static const char img_spheretex[]		 = "res/Sprite3DTest/spheretex.png"; 
static const char c3b_sphere_bumped[]		 = "res/Sprite3DTest/sphere_bumped.c3b"; 
static const char c3b_teapot[]		 = "res/Sprite3DTest/teapot.c3b"; 
static const char img_teapot[]		 = "res/Sprite3DTest/teapot.png"; 
static const char img_texture[]		 = "res/Sprite3DTest/texture.png"; 
static const char frag_toon[]		 = "res/Sprite3DTest/toon.frag"; 
static const char vert_toon[]		 = "res/Sprite3DTest/toon.vert"; 
static const char c3b_tortoise[]		 = "res/Sprite3DTest/tortoise.c3b"; 
static const char img_tortoise[]		 = "res/Sprite3DTest/tortoise.png"; 
static const char material_UVAnimation[]		 = "res/Sprite3DTest/UVAnimation.material"; 
static const char frag_VertexColor[]		 = "res/Sprite3DTest/VertexColor.frag"; 
static const char material_VertexColor[]		 = "res/Sprite3DTest/VertexColor.material"; 
static const char vert_VertexColor[]		 = "res/Sprite3DTest/VertexColor.vert"; 
static const char img_Xie_01[]		 = "res/Sprite3DTest/Xie_01.png"; 
static const char img_back[]		 = "res/Sprite3DTest/skybox/back.png"; 
static const char img_bottom[]		 = "res/Sprite3DTest/skybox/bottom.png"; 
static const char img_front[]		 = "res/Sprite3DTest/skybox/front.png"; 
static const char img_left[]		 = "res/Sprite3DTest/skybox/left.png"; 
static const char img_right[]		 = "res/Sprite3DTest/skybox/right.png"; 
static const char img_top[]		 = "res/Sprite3DTest/skybox/top.png"; 


//----------- texture -----------//

// PlistGeneral.plist
static const char img_btnCloseNormal[]		 = "AllPicRes/General/btnCloseNormal.png"; 
static const char img_btnClosePress[]		 = "AllPicRes/General/btnClosePress.png"; 
static const char img_btnPlus[]		 = "AllPicRes/General/btnPlus.png"; 
static const char img_G01[]		 = "AllPicRes/General/G01.png"; 
static const char img_icoMoney[]		 = "AllPicRes/General/icoMoney.png"; 

// PlistRacket.plist
static const char img_Racket1[]		 = "AllPicRes/Racket/Racket1.png"; 
static const char img_Racket10[]		 = "AllPicRes/Racket/Racket10.png"; 
static const char img_Racket2[]		 = "AllPicRes/Racket/Racket2.png"; 
static const char img_Racket3[]		 = "AllPicRes/Racket/Racket3.png"; 
static const char img_Racket4[]		 = "AllPicRes/Racket/Racket4.png"; 
static const char img_Racket5[]		 = "AllPicRes/Racket/Racket5.png"; 
static const char img_Racket6[]		 = "AllPicRes/Racket/Racket6.png"; 
static const char img_Racket7[]		 = "AllPicRes/Racket/Racket7.png"; 
static const char img_Racket8[]		 = "AllPicRes/Racket/Racket8.png"; 
static const char img_Racket9[]		 = "AllPicRes/Racket/Racket9.png"; 

// PlistRole.plist
static const char img_ManHalfBody1[]		 = "AllPicRes/Role/ManHalfBody1.png"; 
static const char img_ManHalfBody2[]		 = "AllPicRes/Role/ManHalfBody2.png"; 
static const char img_ManHalfBody3[]		 = "AllPicRes/Role/ManHalfBody3.png"; 
static const char img_ManHalfBody4[]		 = "AllPicRes/Role/ManHalfBody4.png"; 
static const char img_ManHalfBody5[]		 = "AllPicRes/Role/ManHalfBody5.png"; 
static const char img_ManHead1[]		 = "AllPicRes/Role/ManHead1.png"; 
static const char img_ManHead2[]		 = "AllPicRes/Role/ManHead2.png"; 
static const char img_ManHead3[]		 = "AllPicRes/Role/ManHead3.png"; 
static const char img_ManHead4[]		 = "AllPicRes/Role/ManHead4.png"; 
static const char img_ManHead5[]		 = "AllPicRes/Role/ManHead5.png"; 
static const char img_WomanHalfBody1[]		 = "AllPicRes/Role/WomanHalfBody1.png"; 
static const char img_WomanHalfBody2[]		 = "AllPicRes/Role/WomanHalfBody2.png"; 
static const char img_WomanHalfBody3[]		 = "AllPicRes/Role/WomanHalfBody3.png"; 
static const char img_WomanHalfBody4[]		 = "AllPicRes/Role/WomanHalfBody4.png"; 
static const char img_WomanHalfBody5[]		 = "AllPicRes/Role/WomanHalfBody5.png"; 
static const char img_WomanHead1[]		 = "AllPicRes/Role/WomanHead1.png"; 
static const char img_WomanHead2[]		 = "AllPicRes/Role/WomanHead2.png"; 
static const char img_WomanHead3[]		 = "AllPicRes/Role/WomanHead3.png"; 
static const char img_WomanHead4[]		 = "AllPicRes/Role/WomanHead4.png"; 
static const char img_WomanHead5[]		 = "AllPicRes/Role/WomanHead5.png"; 

// PlistSceneDressing.plist
static const char img_agility[]		 = "AllPicRes/SceneDressing/agility.png"; 
static const char img_btnBuyNormal[]		 = "AllPicRes/SceneDressing/btnBuyNormal.png"; 
static const char img_btnBuyPress[]		 = "AllPicRes/SceneDressing/btnBuyPress.png"; 
static const char img_btnUsingNormal[]		 = "AllPicRes/SceneDressing/btnUsingNormal.png"; 
static const char img_btnUsingPress[]		 = "AllPicRes/SceneDressing/btnUsingPress.png"; 
static const char img_C_CheckBox[]		 = "AllPicRes/SceneDressing/C_CheckBox.png"; 
static const char img_C_Racket_Check[]		 = "AllPicRes/SceneDressing/C_Racket_Check.png"; 
static const char img_C_Racket_Normal[]		 = "AllPicRes/SceneDressing/C_Racket_Normal.png"; 
static const char img_C_Role_Check[]		 = "AllPicRes/SceneDressing/C_Role_Check.png"; 
static const char img_C_Role_Normal[]		 = "AllPicRes/SceneDressing/C_Role_Normal.png"; 
static const char img_C_Shoe_Check[]		 = "AllPicRes/SceneDressing/C_Shoe_Check.png"; 
static const char img_C_Shoe_Normal[]		 = "AllPicRes/SceneDressing/C_Shoe_Normal.png"; 
static const char img_energy[]		 = "AllPicRes/SceneDressing/energy.png"; 
static const char img_GoodsBG[]		 = "AllPicRes/SceneDressing/GoodsBG.png"; 
static const char img_GoodsCheckBox[]		 = "AllPicRes/SceneDressing/GoodsCheckBox.png"; 
static const char img_Point[]		 = "AllPicRes/SceneDressing/Point.png"; 
static const char img_PointBG[]		 = "AllPicRes/SceneDressing/PointBG.png"; 
static const char img_TipBuySuccess[]		 = "AllPicRes/SceneDressing/TipBuySuccess.png"; 
static const char img_TipDressed[]		 = "AllPicRes/SceneDressing/TipDressed.png"; 
static const char img_Title_DressingRoom[]		 = "AllPicRes/SceneDressing/Title_DressingRoom.png"; 

// PlistTennis.plist
static const char img_Tennis01[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis01.png"; 
static const char img_Tennis02[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis02.png"; 
static const char img_Tennis03[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis03.png"; 
static const char img_Tennis04[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis04.png"; 
static const char img_Tennis05[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis05.png"; 
static const char img_Tennis06[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis06.png"; 
static const char img_Tennis07[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis07.png"; 
static const char img_Tennis08[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis08.png"; 
static const char img_Tennis09[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis09.png"; 
static const char img_Tennis10[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis10.png"; 
static const char img_Tennis11[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis11.png"; 
static const char img_Tennis12[]		 = "AllPicRes/SceneLoading/tennis_anim/Tennis12.png"; 

// PlistSceneMain.plist
static const char img_btnAchievement[]		 = "AllPicRes/SceneMain/btnAchievement.png"; 
static const char img_btnIntegral[]		 = "AllPicRes/SceneMain/btnIntegral.png"; 
static const char img_btnReward[]		 = "AllPicRes/SceneMain/btnReward.png"; 
static const char img_btnSet[]		 = "AllPicRes/SceneMain/btnSet.png"; 
static const char img_btnShare[]		 = "AllPicRes/SceneMain/btnShare.png"; 
static const char img_btnVideo[]		 = "AllPicRes/SceneMain/btnVideo.png"; 
static const char img_M02B[]		 = "AllPicRes/SceneMain/M02B.png"; 
static const char img_MECheck[]		 = "AllPicRes/SceneMain/MECheck.png"; 
static const char img_MEDressing[]		 = "AllPicRes/SceneMain/MEDressing.png"; 
static const char img_MEKingLines[]		 = "AllPicRes/SceneMain/MEKingLines.png"; 
static const char img_MEOpenGame[]		 = "AllPicRes/SceneMain/MEOpenGame.png"; 
static const char img_MEOpenGame_Australian[]		 = "AllPicRes/SceneMain/MEOpenGame_Australian.png"; 
static const char img_MEOpenGame_French[]		 = "AllPicRes/SceneMain/MEOpenGame_French.png"; 
static const char img_MEOpenGame_US[]		 = "AllPicRes/SceneMain/MEOpenGame_US.png"; 
static const char img_MEOpenGame_Wimbledon[]		 = "AllPicRes/SceneMain/MEOpenGame_Wimbledon.png"; 
static const char img_MEPractice[]		 = "AllPicRes/SceneMain/MEPractice.png"; 
static const char img_METitle_Australian[]		 = "AllPicRes/SceneMain/METitle_Australian.png"; 
static const char img_METitle_Dressing[]		 = "AllPicRes/SceneMain/METitle_Dressing.png"; 
static const char img_METitle_French[]		 = "AllPicRes/SceneMain/METitle_French.png"; 
static const char img_METitle_KingLines[]		 = "AllPicRes/SceneMain/METitle_KingLines.png"; 
static const char img_METitle_Practice[]		 = "AllPicRes/SceneMain/METitle_Practice.png"; 
static const char img_METitle_US[]		 = "AllPicRes/SceneMain/METitle_US.png"; 
static const char img_METitle_Wimbledon[]		 = "AllPicRes/SceneMain/METitle_Wimbledon.png"; 

// PlistDressRoomShoe.plist
static const char img_DressRoomShoe1[]		 = "AllPicRes/Shoe/DressRoomShoe1.png"; 
static const char img_DressRoomShoe10[]		 = "AllPicRes/Shoe/DressRoomShoe10.png"; 
static const char img_DressRoomShoe2[]		 = "AllPicRes/Shoe/DressRoomShoe2.png"; 
static const char img_DressRoomShoe3[]		 = "AllPicRes/Shoe/DressRoomShoe3.png"; 
static const char img_DressRoomShoe4[]		 = "AllPicRes/Shoe/DressRoomShoe4.png"; 
static const char img_DressRoomShoe5[]		 = "AllPicRes/Shoe/DressRoomShoe5.png"; 
static const char img_DressRoomShoe6[]		 = "AllPicRes/Shoe/DressRoomShoe6.png"; 
static const char img_DressRoomShoe7[]		 = "AllPicRes/Shoe/DressRoomShoe7.png"; 
static const char img_DressRoomShoe8[]		 = "AllPicRes/Shoe/DressRoomShoe8.png"; 
static const char img_DressRoomShoe9[]		 = "AllPicRes/Shoe/DressRoomShoe9.png"; 

// blocks9ss.plist

// bug12847_spriteframe.plist

// ui.plist

// circle.plist

// json key
static const char file_name[]		 = "file_name"; 
static const char file_index[]		 = "file_index"; 
static const char texture_name[]		 = "texture_name"; 
static const char texture_plist[]		 = "texture_plist"; 
static const char texture_image[]		 = "texture_image"; 

#endif // _AUTO_RESOURCES_H_
