#ifndef __DataStruct__
#define __DataStruct__

typedef enum 
{
	Activate = 0,
	UnActivate = 1,
	Unlock = 2,
}ShopStatus;

struct Cmp_by_AchieveType   //Ϊ�����д�Ľṹ��
{
	bool operator()(cocos2d::Value achieve1, cocos2d::Value achieve2)
	{
		ValueMap& achievemap1 = achieve1.asValueMap();
		ValueMap& achievemap2 = achieve2.asValueMap();
		int nid1 = achievemap1.at("id").asInt();
		int ntype1 = achievemap1.at("type").asInt();
		int nsubtype1 = achievemap1.at("subtype").asInt();
		int ngoal1 = achievemap1.at("goal").asInt();

		int nid2 = achievemap2.at("id").asInt();
		int ntype2 = achievemap2.at("type").asInt();
		int nsubtype2 = achievemap2.at("subtype").asInt();
		int ngoal2 = achievemap2.at("goal").asInt();

		if (ntype1 < ntype2)
		{
			return true;
		}
		else if ((ntype1 == ntype2) && (nsubtype1 < nsubtype2))
		{
			return true;
		}
		else if ((ntype1 == ntype2) && (nsubtype1 == nsubtype2) && (ngoal1 < ngoal2))
		{
			return true;
		}
		return false;
	}
};
static char* configdatas[] = {
	"Role",
	"Shoes",
	"Racquets"
};
#endif/* __DataStruct__ */