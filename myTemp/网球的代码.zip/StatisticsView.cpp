#include "StatisticsView.h"
#include "EventMacro.h"
Node* StatisticsView::createWithVec(ValueVector vec)
{
    Node *nrootnode = CSLoader::createNode("GameScene/StatisticsView.csb");
	StatisticsView *node = new (std::nothrow) StatisticsView();
	if (node &&  node->initwithWithVec(nrootnode, vec))
	{
		node->setName("SelfClass");
		nrootnode->addChild(node);
		node->autorelease();
		return nrootnode;
	}
	else
	{
		delete node;
		node = nullptr;
		return nullptr;
	}
}
bool StatisticsView::initwithWithVec(Node *node, ValueVector vec)
{
    m_nrootnode = node;
    auto  nContinue_Button = static_cast<ImageView*>(UiManager::GetChildByName(m_nrootnode, "Continue_Button"));
	nContinue_Button->addClickEventListener([=](Ref* sender) {
		UiManager::CloseUI();
	});
	setUpUIWithData();
    return true;
}
void StatisticsView::setUpUIWithData()
{
	
}
float StatisticsView::activeAction()
{
	
	return 0;
}
void StatisticsView::ShowCallback()
{

}
void StatisticsView::onEnter()
{

}
void StatisticsView::onEnterTransitionDidFinish()
{
	
}
void StatisticsView::onExitTransitionDidStart()
{

}
void StatisticsView::onExit()
{

}
void StatisticsView::cleanup()
{

}
void StatisticsView::CloseCallBack()
{
	EventCustom event1(Event_ContinueGame);
	_eventDispatcher->dispatchEvent(&event1);
}