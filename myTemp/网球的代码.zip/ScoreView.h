#ifndef __ScoreView_H__
#define __ScoreView_H__
#include "BaseView.h"
#include "UiManager.h"
class ScoreView :public BaseView
{
public:
    static Node* createWithVec(ValueVector vec);
    bool initwithWithVec(Node *node,ValueVector vec);
    void setUpUIWithData();
	virtual float activeAction();
	virtual void ShowCallback();
	void onEnter();
	void onEnterTransitionDidFinish();
	void onExitTransitionDidStart();
	void onExit();
	void cleanup();
	virtual void CloseCallBack();
protected:
    Node *m_nrootnode;
	Text *m_nCount_Text;
};

#endif // __ScoreView_H__
