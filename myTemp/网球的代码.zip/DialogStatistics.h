#ifndef __DialogStatistics_H__
#define __DialogStatistics_H__
#include "c2d/BaseDialog.h"
#include "UiManager.h"
class DialogStatistics :public BaseDialog
{
public:
	DIALOG_REGISTER_INFO;
	DIALOG_CREATE_FUNC_PARAM_0(DialogStatistics);

	virtual bool initWithNoParam();//û�в�����ʱ����Ҫʵ�ֵĳ�ʼ������
	virtual void onCloseCallback();

};

#endif // __PauseView_H__
