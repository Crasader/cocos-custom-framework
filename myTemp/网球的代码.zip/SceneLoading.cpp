#include "SceneLoading.h"
#include "SceneManager.h"
#include "PublicDefine.h"
#include "c2d/StringUtil.h"
#include "Resources.h"

Scene* SceneLoading::createScene(SceneType nextScene)
{
	auto scene = Scene::create();
	auto layer = SceneLoading::create(nextScene);
	scene->addChild(layer);
	return scene;
}

bool SceneLoading::init(SceneType nextScene)
{
	if (BaseScene::init(csb_SceneLoading)){
	
		_pNextScene = nextScene;
		onInit();
		return true;
	}
	return false;
}

void SceneLoading::onInit()
{
	scheduleUpdate();

	// init UI
	_pLoadingBar = static_cast<LoadingBar*> (getChildByPath("LoadingBg_Image/LoadingBar"));
	auto actio = CSLoader::createTimeline(csb_SceneLoading);
	actio->play("loading", true);
	_pRoot->runAction(actio);


	//init data
	switch (_pNextScene)
	{
	case cocos2d::eSceneMain:
		addCsb(csb_SceneMain);
		addCsb(csb_SceneDressing);
		addPlist(plist_PlistDressRoomShoe);
		addPlist(plist_PlistRacket);
		addJsonData(json_Entrances);
		addJsonData(json_Role);
		addJsonData(json_Shoes);
		addJsonData(json_Racquets);
		break;
	case cocos2d::eSceneGame:
		
		break;
	default:
		break;
	}

	beginLoad();

}

void SceneLoading::update(float delta)
{
	_pLoadingBar->setPercent(getVisualPercent(getPercent()));
}

void SceneLoading::onLoadEnd()
{
	BaseLoading::onLoadEnd();
	SceneManager::getInstance()->replaceScene(_pNextScene);
}

void SceneLoading::onLoadJsonDataCallBack(const std::string& filename)
{
	DELOG(__FILE__, __LINE__, "load the json data -> %s", filename.c_str());

}

