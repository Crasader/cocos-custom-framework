#ifndef _UiManager__
#define _UiManager__

#include "cocos2d.h"
#include "Macro.h"
//#include "GlobalData.h"
#include "BaseView.h"
#include "ScoreView.h"
#include "StatisticsView.h"
#include "ResultView.h"
#include "FaultView.h"
#include "c2d/BaseDialog.h"
#include "c2d/Align.h"
#include "VisibleRect.h"

using namespace c2d;

typedef enum{
	NormalTypeClose = 0,
	BackGround_Close = 1,
	Auto_Close = 2,
	Effect_Close = 3,
}CloseType;
typedef enum{
	Normal_Show = 0,
	Horn_Show = 1,

}UiEffectType;
typedef enum{
	Shake = 0,//ҡ�ڶ���
	Rock = 1,//���һζ�
	Postmark = 2,//�ʴ�
	Pop = 3,//����
	PopIn = 4,//����
	CFadeOut = 5,//����
	CFadeIn = 6,//����
	Shock = 7,//��
} ActionCombination;
class UiManager
{
public:
	static UiManager* shareManager();
	static UiManager* getInstance();
	bool init();

	static bool adaptScreen(Node * node, c2d::Align align);
	static bool adaptScreen(Node * node);
	static void adaptScreen(Node* root, const std::string& childPath, c2d::Align align = c2d::Align::center);
	static void adaptScreenChildren(Node*root, const std::string& rootPath, c2d::Align align = c2d::Align::center);


	static float PlayActionCombination(Node *node, ActionCombination nindex, CallFuncN * callback = nullptr);
	static ActionInterval *GetActionByIndex(ActionCombination nindex);
    static void PlayAnimation(Node* node,const std::string& filepath,const std::string& animateName,float delay,int times);
	static Node * ShowUI(const std::string& filepath, ValueVector vec, CloseType closetype = NormalTypeClose);
	static Node * ShowUIWithEffect(const std::string& filepath, ValueVector vec, CloseType closetype, UiEffectType effecttpye,ValueVector effectvec);
	static Node * createUi(const std::string& filepath,ValueVector vec);
	static Node * createEffectUi(UiEffectType effecttpye, ValueVector vec);
	static void setBMFontValue(Widget * label, string key,string addstr = "");
    static void LockScreen();
    static void UnLockScreen();
	static void CloseUI(float delay = 0);
	static bool EscCloseUI();
	static void ShowGuidebyStep(int mainstep=-1, int substep=-1);
	static void CloseGuide();
	static void clearUI();


	static BaseDialog* ShowUI(const std::string& filepath, bool push = true);
	static BaseDialog* ShowUI(const std::string& filepath, Ref* param, bool push = true);
	static BaseDialog* CloseUI(const std::string& filepath);
	static BaseDialog* CloseUI(BaseDialog* dialog);
	//static BaseDialog* CloseUI();
	static bool onKeyBack();



	static Node* GetChildByName(Node* root, const std::string& widgetname = "");
	template<typename T> inline
		static T GetChildByName(Node* root, const std::string& path)
	{
			return dynamic_cast<T>(GetChildByName(root, path));
		}

	static Node* GetChildByPath(Node* root, const std::string& path);
protected:

	
};

#endif /* _UiManager__ */
