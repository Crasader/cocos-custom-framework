#include "LoadingScene.h"
#include "GameScene.h"
#include "CommonMethod.h"
#define ThreadNum 5
#define Threadpercent 100.0

Scene*LoadingScene::createSceneWithType(LoadingType loadingtype,SCENEID sceneid)
{
	auto scene = Scene::create();
	auto layer = LoadingScene::create();
	if (layer && layer->initwithType(loadingtype, sceneid))
	{
		layer->setName("rootlayer");
		scene->addChild(layer);
		return scene;
	}
	else
	{
		return nullptr;
	}
}
// on "init" you need to initialize your instance
bool LoadingScene::initwithType(LoadingType loadingtype, SCENEID sceneid)
{
    if ( !Layer::init() )
    {
        return false;
    }
	m_nloadtype = loadingtype;
	m_nsceneid = sceneid;
	//ע��ϵͳ�¼�
	initSystemData();
	//ע��UI
	registerUI();
	setUpUIWithData();
	//ע��ϵͳ������Ӧ�¼�
	registerLoadingSceneSystemKeyBoard();
    return true;
}
void LoadingScene::initSystemData()
{
	if (m_nloadtype == LoadingType::ResLoad)
	{
		setKeypadEnabled(true);
		CommonMethod::SetRandomSeed();
		initSystemSchedule();
	}
}
void LoadingScene::initSystemSchedule()
{
	
}
void LoadingScene::registerUI()
{
	m_npercent = 4;
	m_nchangescene = false;
	m_nprocessThread = false;
	
	m_nrootNode = CSLoader::createNode("LoadingScene/LoadingScene.csb");
	addChild(m_nrootNode);

	m_nLoadingBar = static_cast<LoadingBar*>(UiManager::GetChildByName(m_nrootNode, "LoadingBar"));
	m_nLoadingBar->setPercent(m_npercent);
	scheduleUpdate();
}
void LoadingScene::setUpUIWithData()
{
	if (m_nloadtype == LoadingType::ResLoad)
	{
		
	}
	if (m_nloadtype== LoadingType::AdLoad)
	{
		
	}
	
}
void LoadingScene::registerLoadingSceneSystemKeyBoard()
{
	auto listener = EventListenerKeyboard::create();
	listener->onKeyPressed = CC_CALLBACK_2(LoadingScene::LoadingSceneonKeyPressed, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
}
void LoadingScene::LoadingSceneonKeyPressed(EventKeyboard::KeyCode code, Event* event)
{
	if (code == EventKeyboard::KeyCode::KEY_BACK)
	{
		CCLOG("$$$$$$$");
		//CommonMethod::SendJavaEvent(0);
	}
}
void LoadingScene::update(float dt)
{
	Layer::update(dt);
	if (m_nloadtype == LoadingType::ResLoad)
	{
		updateResloading(dt);
	}
	else if (m_nloadtype == LoadingType::NormalLoad)
	{
		updateNormalloading(dt);
	}
	else if (m_nloadtype == LoadingType::AdLoad)
	{
		updateAdloading(dt);
	}
}
void LoadingScene::updateResloading(float dt)
{
	//���½�����
	float npercent = m_nLoadingBar->getPercent();
	if (npercent < m_npercent)
	{
		npercent += 50*dt;
		m_nLoadingBar->setPercent(npercent);
	}
	//�л�����
	if (npercent >= 100 && !m_nchangescene)
	{
		m_nchangescene = true;
		Scene* nscene = nullptr;
		switch (m_nsceneid)
		{
		case SCENEID::TMainScene:
			
			break;
		case SCENEID::TGameScene:
			nscene = GameScene::createScene();
			break;
		default:
			
			break;
		}
		Director::getInstance()->replaceScene(nscene);
	}

	//������һ�׶��̼߳�������
	if (!m_nprocessThread)
	{
		for (int i = 0; i < ThreadNum; i++)
		{
			std::thread nthread(&LoadingScene::LoadData, this, i);//����һ����֧�̣߳��ص���myThread������
			nthread.detach();
			//nthread.join();
			
		}
		m_nprocessThread = true;
	}

	
}
void LoadingScene::updateNormalloading(float dt)
{
	float npercent = m_nLoadingBar->getPercent();
	if (npercent < 100)
	{
		npercent +=20* dt;
		m_nLoadingBar->setPercent(npercent);
	}
	//�л�����
	if (npercent >= 100 && !m_nchangescene)
	{
		m_nchangescene = true;
		Scene* nscene = nullptr;
		switch (m_nsceneid)
		{
		case SCENEID::TMainScene:
			
			break;
		case SCENEID::TGameScene:
			nscene = GameScene::createScene();
			break;
		default:
			
			break;
		}
		Director::getInstance()->replaceScene(nscene);
	}
}
void LoadingScene::updateAdloading(float dt)
{
	float npercent = m_nLoadingBar->getPercent();
	if (npercent < 100)
	{
		npercent += 20 * dt;
		m_nLoadingBar->setPercent(npercent);
	}
	//�л�����
	if (npercent >= 100 && !m_nchangescene)
	{
		m_nchangescene = true;
		Scene* nscene = nullptr;
		switch (m_nsceneid)
		{
		case SCENEID::TMainScene:
			
			break;
		case SCENEID::TGameScene:
			nscene = GameScene::createScene();
			break;
		default:
			
			break;
		}
		Director::getInstance()->replaceScene(nscene);
	}
}
void LoadingScene::LoadData(int threadid)
{
	if (threadid==0)
	{
		int count = sizeof(configdatas) / sizeof(configdatas[0]);
		for (int i = 0; i < count;i++)
		{
			DataManager::shareDataManager()->readDataFromFile(configdatas[i]);
		}
		//auto teststr = DataManager::shareDataManager()->getTextDescByStrKey("text1");
		//ValueMap nmainconfigdata = DataManager::shareDataManager()->m_nConfigdata;
		
	}
	else if (threadid == 1)
	{
		
	}
	else if (threadid == 2)
	{
		
	}
	else if (threadid == 3)
	{

	}
	else if (threadid == 4)
	{

	}
	m_npercent += Threadpercent / ThreadNum;
}
void LoadingScene::onEnter()
{
	Layer::onEnter();
	CCLOG("LoadingScene::onEnter");
}
void LoadingScene::onEnterTransitionDidFinish()
{
	Layer::onEnterTransitionDidFinish();
	UiManager::clearUI();
	CCLOG("LoadingScene::onEnterTransitionDidFinish");
}
void LoadingScene::onExitTransitionDidStart()
{
	Layer::onExitTransitionDidStart();
	CCLOG("LoadingScene::onExitTransitionDidStart");
}
void LoadingScene::onExit()
{
	Layer::onExit();
	CCLOG("LoadingScene::onExit");
}
void LoadingScene::cleanup()
{
	Layer::cleanup();
	CCLOG("LoadingScene::cleanup");
}