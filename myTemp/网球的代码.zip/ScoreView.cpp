#include "ScoreView.h"
#include "EventMacro.h"
Node* ScoreView::createWithVec(ValueVector vec)
{
    Node *nrootnode = CSLoader::createNode("GameScene/ScoreView.csb");
	ScoreView *node = new (std::nothrow) ScoreView();
	if (node &&  node->initwithWithVec(nrootnode, vec))
	{
		node->setName("SelfClass");
		nrootnode->addChild(node);
		node->autorelease();
		return nrootnode;
	}
	else
	{
		delete node;
		node = nullptr;
		return nullptr;
	}
}
bool ScoreView::initwithWithVec(Node *node, ValueVector vec)
{
    m_nrootnode = node;
	int nselfscore = vec.at(0).asInt();
	int nopponentscore = vec.at(1).asInt();

    m_nCount_Text = static_cast<Text*>(UiManager::GetChildByName(m_nrootnode, "Count_Text"));
	m_nCount_Text->setText(StringUtils::format("%d:%d",nselfscore,nopponentscore));
	setUpUIWithData();
    return true;
}
void ScoreView::setUpUIWithData()
{
	
}
float ScoreView::activeAction()
{
	
	return 0;
}
void ScoreView::ShowCallback()
{

}
void ScoreView::onEnter()
{

}
void ScoreView::onEnterTransitionDidFinish()
{
	
}
void ScoreView::onExitTransitionDidStart()
{

}
void ScoreView::onExit()
{

}
void ScoreView::cleanup()
{

}
void ScoreView::CloseCallBack()
{
	EventCustom event1(Event_ScoreViewClose);
	_eventDispatcher->dispatchEvent(&event1);
}