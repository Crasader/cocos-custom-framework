#ifndef __BASEVIEW_H__
#define __BASEVIEW_H__

#include "cocos2d.h"
#include "Macro.h"
class BaseView:public Node
{
public:
	virtual float activeAction();
	virtual float getActiveDuration();
	virtual void ShowCallback();
	virtual float closeAction();
	virtual float getCloseDuration();
    virtual void CloseCallBack();
};
#endif // __BASEVIEW_H__
