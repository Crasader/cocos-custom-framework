#include "Customer.h"
#define RoleWidth 112
#define RoleHeight 222

Customer* Customer::createWithId(int shopid, int chapterid, int roleid, ValueVector demondvec)
{
	Customer *pRet = new(std::nothrow) Customer();
	if (pRet && pRet->initWithId(shopid, chapterid, roleid, demondvec))
	{
		pRet->autorelease();
		return pRet;
	}
	else
	{
		delete pRet;
		pRet = nullptr;
		return nullptr;
	}
}
bool Customer::initWithId(int shopid,int chapterid,int roleid, ValueVector demondvec)
{
	if (!Node::init())
	{
		return false;
	}
	m_nroleid = roleid;
	m_nnrootnode = CSLoader::createNode("Customer/Customer.csb");
	addChild(m_nnrootnode);

	auto  nRole_Node = static_cast<Node*>(UiManager::GetChildByName(m_nnrootnode, "Role_Node"));
	m_nDemandBg_Image = static_cast<ImageView*>(UiManager::GetChildByName(m_nnrootnode, "DemandBg_Image"));
	m_nWait_LoadingBar = static_cast<LoadingBar*>(UiManager::GetChildByName(m_nnrootnode, "Wait_LoadingBar"));
	m_nFood_Panel = static_cast<Layout*>(UiManager::GetChildByName(m_nnrootnode, "Food_Panel"));
	
	ValueMap *nrolemap = DataManager::shareDataManager()->getRoleData(roleid);
	string nfilepath = nrolemap->at("spine").asString();
	auto jsonname = StringUtils::format("%s.json", nfilepath.c_str());
	auto atlasname = StringUtils::format("%s.atlas", nfilepath.c_str());
	m_nrole = SkeletonAnimation::createWithFile(jsonname, atlasname, 1.0f);
	nRole_Node->addChild(m_nrole);

	m_nwaitTime = nrolemap->at("wait").asInt();
	m_ntipTime = nrolemap->at("tipTime").asInt();
	m_nmaxTip = nrolemap->at("maxTip").asInt();
	m_nspeed = nrolemap->at("speed").asInt();

	m_nAnimationVec = &nrolemap->at("play").asValueVector();
	string nAnimationName = m_nAnimationVec->at(0).asValueMap().at("key").asString();
	m_nrole->setAnimation(0, nAnimationName, true);
	m_ncuranimationname = nAnimationName;
	m_nWait_LoadingBar->setPercent(100);
	m_nDemandBg_Image->setVisible(false);

	m_naddwaitTime = 0;
	m_naddtipTime = 0;
	m_naddtipNum = 0;
	m_nactivestatus = false;
	m_ntimeout = false;
	m_ncurwaitTime = 0;
	m_npayNum = 0;
	m_nbaseNum = 0;
	m_ncurtipnum = m_nmaxTip;
	
	m_ndemondVec = demondvec;
    m_nshopid = shopid;
	m_nchapterid = chapterid;
    int spacedis = 30;
	int npos_x = 40;//m_nFood_Panel->getContentSize().width/2;
    Vec2 pointvec1[] = {Vec2(npos_x,120)};
	Vec2 pointvec2[] = { Vec2(npos_x, 154),Vec2(npos_x, 72) };
	Vec2 pointvec3[] = { Vec2(npos_x, 182), Vec2(npos_x, 120), Vec2(npos_x, 52) };
    Vec2 * destpoint;
    if (m_ndemondVec.size()==1)
    {
        destpoint = pointvec1;
    }
    else if (m_ndemondVec.size()==2)
    {
        destpoint = pointvec2;
    }
    else if (m_ndemondVec.size()==3)
    {
        destpoint = pointvec3;
    }
    
    for (int i =0; i<m_ndemondVec.size(); i++)
    {
        int nmaterialid = m_ndemondVec.at(i).asInt();
        auto nimg = DataManager::shareDataManager()->generateimgbyid(m_nshopid,nmaterialid);
        nimg->setPosition(destpoint[i]);
		nimg->setVisible(false);
		ValueMap *nfoodmap = DataManager::shareDataManager()->getFoodData(m_nshopid, nmaterialid);
		if (nfoodmap->find("scale") != nfoodmap->end())
		{
			auto &scalemap = nfoodmap->at("scale").asValueMap();
			if (scalemap.find("menu") != scalemap.end())
			{
				float nscale = scalemap.at("menu").asFloat();
				nimg->setScale(nscale);
			}
		}
		
		//nimg->setScale(0.6);
        m_nFood_Panel->addChild(nimg);
		m_ndemondimgvec.pushBack(nimg);

		m_nbaseNum += DataManager::shareDataManager()->getMaterialOriginCost(m_nshopid, nmaterialid);
    }
   
	schedule(CC_SCHEDULE_SELECTOR(Customer::updateRoleStatus), 1.0f);
	//registerEventDispatcher();
	return true;
}
void Customer::setAdditionAttri(int waitTime, int tipTime, int tipNum)
{
	m_naddwaitTime = waitTime;
	m_naddtipTime = tipTime;
	m_naddtipNum = tipNum;
}
void Customer::registerEventDispatcher()
{
//	auto ntimelistener = EventListenerCustom::create(Event_TimeUpdate, [=](EventCustom* event){
//		float dt = *(static_cast<float*>(event->getUserData()));
//		if (m_nactivestatus)
//		{
//			updateRoleStatus(dt);
//		}
//	});
//	_eventDispatcher->addEventListenerWithSceneGraphPriority(ntimelistener, this);
}
void Customer::activeWithDestination(Vec2 point)
{
	float nduration = abs(getPositionX() - point.x) / m_nspeed;
	
	runAction(Sequence::create(
		MoveTo::create(nduration,point), 
		CallFuncN::create([=](Node *node){
			m_nDemandBg_Image->setVisible(true);
			string nAnimationName = m_nAnimationVec->at(1).asValueMap().at("key").asString();
			m_nrole->setAnimation(0, nAnimationName, true);
			popOutDemond();
			bool nguidestatus = GlobalData::shareGlobalData()->GetGuideStatus(m_nshopid, m_nchapterid, false);
			if (nguidestatus)
			{
				EventCustom event(Event_UpdateGuideData);
				event.setUserData(const_cast<char*>("guideevent4"));
				_eventDispatcher->dispatchEvent(&event);
			}
			/*UiManager::shareManager()->PlayActionCombination(m_nDemandBg_Image, ActionCombination::CFadeIn, CallFuncN::create([=](Node *node){
				m_nactivestatus = true;
			}));*/
		}),
		nullptr));
}
Rect Customer::getcustomerWorldRect()
{
	Rect nrect = CommonMethod::getWorldBoundingBox(m_nrole);
	Size nsize = Size( 238, 260);
	nrect.size = nsize;
	return nrect;
}
bool Customer::receiveFood(int foodid)
{
	bool isrightfood = false;
	float nactiontime = 0.0;
	//vec �Ƴ�ʳ��Ԫ��
	for (int i = 0; i < m_ndemondVec.size();i++)
	{
		if (foodid == m_ndemondVec.at(i).asInt())
		{
			AudioManager::shareManager()->PlayVoiceEffect("voice/recfood");
			GlobalData::shareGlobalData()->addupStatistics(0,foodid,1,-1);
			//ʳ�ķ���
			int ncost = DataManager::shareDataManager()->getMaterialCost(m_nshopid, foodid);
			m_npayNum += ncost;
			//����ʳ����ʧ����
			
			auto nimg = m_ndemondimgvec.at(i);
			auto nfinishimg = ImageView::create("SignInVIew/S139.png");
			nimg->addChild(nfinishimg);
			nfinishimg->setPosition(Vec2(nimg->boundingBox().size.width / 2.0 + nfinishimg->getSize().width*0.5*0.5, nimg->boundingBox().size.height/2));

			//nfinishimg->setScale();
			nfinishimg->setOpacity(30);
			nfinishimg->setScale((0.8 / nimg->getScale())*2.0);
			auto nfade = FadeIn::create(0.2);
			auto nscale = ScaleTo::create(0.2, 0.8 / nimg->getScale());
			auto nspawn = Spawn::create(nfade, nscale, nullptr);
			auto naction = EaseCircleActionIn::create(nspawn);
			auto ncallfunc = CallFuncN::create([=](Node *node){
				auto nguidestatus = GlobalData::shareGlobalData()->GetGuideStatus(m_nshopid, m_nchapterid,false);
				if (nguidestatus)
				{
					EventCustom event(Event_UpdateGuideData);
					event.setUserData(const_cast<char*>("guideevent14"));
					_eventDispatcher->dispatchEvent(&event);
				}
			});
			nfinishimg->runAction(Sequence::create(naction, ncallfunc,nullptr));
			nactiontime = 0.2;
			nactiontime += 0.1;

			/*nimg->runAction(Sequence::create(
				DelayTime::create(nactiontime),
				ScaleTo::create(0.1,0.1),
				CallFuncN::create([=](Node *node){
				node->removeFromParent();
			}),
				nullptr));*/
			m_ndemondimgvec.erase(i);
			m_ndemondVec.erase(m_ndemondVec.begin() + i);
			isrightfood = true;
			break;
		}
	}
	//�ж��Ƿ���Ԫ�أ������򸶿�
	if (m_ndemondVec.empty())
	{
		payAndLeave(false, nactiontime+0.2);
	}
	return isrightfood;
}
//void Customer::addupStatisticsFood(int foodid)
//{
//	auto nachievevaluedata = DataManager::shareDataManager()->getShopAchieveValueData();
//	auto nachievedata = DataManager::shareDataManager()->getTableDatabyName("achievement");
//	auto &nsubtypevec = nachievevaluedata->at("0").asValueVector();
//	for (int i = 0; i < nsubtypevec.size();i++)
//	{
//		auto nindex = nsubtypevec.at(i).asInt();
//		auto &nachievemap = nachievedata->at(nindex).asValueMap();
//		auto &ntagertvec = nachievemap.at("targetid").asValueVector();
//		for (int j = 0; j < ntagertvec.size();j++)
//		{
//			if (ntagertvec.at(j).asInt()== foodid)
//			{
//				auto nachieveid = nachievemap.at("id").asInt();
//				auto ntype = nachievemap.at("type").asInt();
//				auto nsubtype = nachievemap.at("subtype").asInt();
//				auto ntargetnum = nachievemap.at("goal").asInt();
//
//				auto ndbachievedata = GlobalData::shareGlobalData()->getAchieveDatabyIdandType(nachieveid, ntype, nsubtype);
//				
//				auto ndbachievevaluedata = GlobalData::shareGlobalData()->getAchieveValuebyIdandType(ntype, nsubtype);
//				
//				auto ncurnum = ndbachievevaluedata->at("value").asInt() ;
//				ndbachievevaluedata->at("value") = ncurnum + 1;
//				GlobalData::shareGlobalData()->FlushAchieveValue(ntype, nsubtype);
//				if (ndbachievedata->at("receive").asInt()==0)
//				{
//					if ((ncurnum + 1) >= ntargetnum)
//					{
//						ndbachievedata->at("receive") = 1;
//						GlobalData::shareGlobalData()->FlushAchieveData(nachieveid,ntype, nsubtype);
//					}
//				}
//			}
//		}
//	}
//	
//}
void Customer::setPayCallback(const NumCallback& callback)
{
	m_npaycallback = callback;
}
void Customer::setLeaveCallback(const ccMenuCallback& callback)
{
	m_nleavecallback = callback;
}
ValueVector * Customer::getDemondFood()
{
	if (m_nactivestatus)
	{
		return &m_ndemondVec;
	}
	
	return nullptr;
}
void Customer::popOutDemond()
{
	AudioManager::shareManager()->PlayVoiceEffect("voice/Order");
	ActionTimeline* nanimation = CSLoader::createTimeline("Customer/Customer.csb");
	m_nnrootnode->runAction(nanimation);
	nanimation->play("popout", false);
	nanimation->setLastFrameCallFunc([=](){
		float ntime = 0.0;
		for (int i = 0; i < m_ndemondimgvec.size();i++)
		{
			auto nimg = m_ndemondimgvec.at(i);
			float ncurscale = nimg->getScale();
			nimg->setVisible(true);
			nimg->setScale(0.01);
			
			if (i == m_ndemondimgvec.size()-1)
			{
				nimg->runAction(Sequence::create(
					DelayTime::create(ntime),
					ScaleTo::create(0.1, ncurscale + 0.1),
					ScaleTo::create(0.05, ncurscale),
					DelayTime::create(0.4),
					CallFuncN::create([=](Node *node){
					m_nactivestatus = true;
				}),
					nullptr));
				ntime += 0.1 + 0.05 + 0.4;
			}
			else
			{
				nimg->runAction(Sequence::create(
					DelayTime::create(ntime),
					ScaleTo::create(0.1, ncurscale + 0.1),
					ScaleTo::create(0.05, ncurscale),
					nullptr));
				ntime += 0.1 + 0.05;
			}
		}
	});
}
float Customer::popInDemond(float time)
{
	float ntime = time;
	for (int i = 0; i < m_ndemondimgvec.size(); i++)
	{
		auto nimg = m_ndemondimgvec.at(i);
		float ncurscale = nimg->getScale();
		nimg->runAction(Sequence::create(
			DelayTime::create(time),
			ScaleTo::create(0.1 , ncurscale + 0.1),
			ScaleTo::create(0.05, ncurscale),
			nullptr));
		ntime += 0.1 + 0.05;
	}
	ActionTimeline* nanimation = CSLoader::createTimeline("Customer/Customer.csb");
	//m_nnrootnode->runAction(nanimation);
	nanimation->play("popin", false);
	nanimation->setLastFrameCallFunc([=](){

	});

	m_nnrootnode->runAction(Sequence::create(
		DelayTime::create(ntime),
		CallFuncN::create([=](Node *node){
			ActionTimeline* nanimation = CSLoader::createTimeline("Customer/Customer.csb");
			nanimation->play("popin", false);
			node->runAction(nanimation);
		}),
		nullptr
		));
	
	int startframe = nanimation->getStartFrame();
	int endframe = nanimation->getEndFrame();
	ntime += (endframe - startframe)/ 60.0;
	return ntime;
}
void Customer::updateRoleStatus(float dt)
{
	if (!m_nactivestatus)
	{
		return;
	}
	
	m_ncurwaitTime += dt;
	//����С��
	if (m_ncurtipnum<=0)
	{
		m_ncurtipnum = 0;
	}
	else
	{
		m_ncurtipnum = ceil((m_ntipTime +m_naddtipTime- m_ncurwaitTime)*1.0 / (m_ntipTime+m_naddtipTime)*(m_nmaxTip+m_naddtipNum));
	}
	//�����������
	for (int i = 0; i < m_nAnimationVec->size();i++)
	{
		auto nanimationmap = m_nAnimationVec->at(i).asValueMap();
		float ntimePercent = nanimationmap.at("p").asFloat();
		//CCLOG("first = %f  second = %f", (m_nwaitTime + m_naddwaitTime - m_ncurwaitTime)*1.0, (m_nwaitTime + m_naddwaitTime)*ntimePercent);
		if ((m_nwaitTime+m_naddwaitTime - m_ncurwaitTime)*1.0 >= (m_nwaitTime+m_naddwaitTime)*ntimePercent)
		{
			string nanimationname = nanimationmap.at("key").asString();
			//CCLOG("m_ncuranimationname = %s  nanimationname = %s", m_ncuranimationname.c_str(), nanimationname.c_str());
			if (m_ncuranimationname != nanimationname)
			{
				m_ncuranimationname = nanimationname;
				m_nrole->setAnimation(0, nanimationname, true);
				if (nanimationmap.find("audio") != nanimationmap.end())
				{
					string naudiostr = nanimationmap.at("audio").asString();
					AudioManager::shareManager()->PlayVoiceEffect("voice/" + naudiostr);
				}
				
			}	
			break;
		}
	}
	//���½�����
    int curvalue = m_nwaitTime + m_naddwaitTime - m_ncurwaitTime;
    int totalvalue = m_nwaitTime + m_naddwaitTime;
	m_nWait_LoadingBar->setPercent((curvalue)*100.0 / (totalvalue));
	if (m_ncurwaitTime >= (m_nwaitTime+m_naddwaitTime)&&m_nactivestatus)
	{
		m_ntimeout = true;
		payAndLeave(false,0.0);
	}

}
void Customer::payAndLeave(bool immediately, float delaytime)
{
	m_nactivestatus = false;
	unschedule(CC_SCHEDULE_SELECTOR(Customer::updateRoleStatus));
	this->stopAllActions();
	m_ndemondVec.clear();
	//�任����
	//string nAnimationName = m_nAnimationVec->at(0).asValueMap().at("key").asString();
	//m_nrole->setAnimation(0, nAnimationName, true);
	
	//����ʳ�����
	float ntime = popInDemond(delaytime);
	//�߳���Ļ
	
	if (!immediately)
	{
		this->runAction(Sequence::create(
			DelayTime::create(ntime+0.1),
			CallFuncN::create([=](Node *node){
			float paytime = m_npaycallback(this, m_npayNum, m_ncurtipnum, m_nbaseNum, m_nmaxTip + m_naddtipNum);
				Vec2 destinationpoint[] = { Vec2(-RoleWidth / 2.0, 440), Vec2(DesignWidth + RoleWidth / 2.0, 440) };
				int randomindex = CommonMethod::getRand(0, 1);
				float nduration = abs(getPositionX() - destinationpoint[randomindex].x) / m_nspeed;

				node->runAction(
					Sequence::create(
					DelayTime::create(paytime),
					CallFuncN::create([=](Node *node){
					m_nrole->setTimeScale(0);
					auto nmoveup = MoveBy::create(16 / 60.0, Vec2(0, -18));
					auto nmovedown = MoveBy::create(16 / 60.0, Vec2(0, 18));
					auto nrepeataction = RepeatForever::create(Sequence::createWithTwoActions(nmoveup, nmovedown));
					node->runAction(nrepeataction);
				}),
					MoveTo::create(nduration, destinationpoint[randomindex]),
					CallFuncN::create([=](Node *node){
					m_nleavecallback(this);
					node->removeFromParent();
					}),
					nullptr));
				

			}),
			nullptr));
	}
	else
	{
		this->runAction(Sequence::create(
			DelayTime::create(ntime+0.1),
			CallFuncN::create([=](Node *node){
			float paytime = m_npaycallback(this, m_npayNum, m_ncurtipnum,m_nbaseNum, m_nmaxTip + m_naddtipNum);
				Vec2 destinationpoint[] = { Vec2(-RoleWidth / 2.0, 440), Vec2(DesignWidth + RoleWidth / 2.0, 440) };
				int randomindex = CommonMethod::getRand(0, 1);
				float nduration = abs(getPositionX() - destinationpoint[randomindex].x) / m_nspeed;

				node->runAction(
					Sequence::create(
					DelayTime::create(paytime),
					MoveTo::create(nduration, destinationpoint[randomindex]),
					CallFuncN::create([=](Node *node){
					node->removeFromParent();
					}),
					nullptr));
			}),
			nullptr));
	}
	
}
void Customer::pauseCustomer()
{
	Director::getInstance()->getActionManager()->pauseTarget(this);
	Director::getInstance()->getScheduler()->pauseTarget(this);
}
void Customer::resumeCustomer()
{
	Director::getInstance()->getActionManager()->resumeTarget(this);
	Director::getInstance()->getScheduler()->resumeTarget(this);
}
void Customer::MixCustomerAnimation()
{
	int nanimationcout = m_nAnimationVec->size();
	for (int i = 0; i < nanimationcout; i++)
	{
		auto nanimationname1 = m_nAnimationVec->at(i).asValueMap().at("key").asString();
		for (int j = 0; j < nanimationcout; j++)
		{
			if (i != j)
			{
				auto nanimationname2 = m_nAnimationVec->at(j).asValueMap().at("key").asString();
				m_nrole->setMix(nanimationname1, nanimationname2, 1.0);
			}
		}
	}
}
int Customer::getRoleId()
{
	return m_nroleid;
}
Customer::~Customer()
{
	_eventDispatcher->removeEventListenersForTarget(this);
}


