//
//  CommonMethod.cpp


#include "UiManager.h"
#include "c2d/StringUtil.h"
static UiManager *_uimanager;
static Vector<Layout *> m_nUiVectors;
static ValueMap m_nUiMap;
UiManager * UiManager::shareManager()
{
	if (!_uimanager)
	{
		_uimanager = new UiManager();
		_uimanager->init();
	}
	return _uimanager;
}

UiManager* UiManager::getInstance()
{
	return  UiManager::shareManager();
}

bool UiManager::init()
{

	return true;
}
float UiManager::PlayActionCombination(Node *node, ActionCombination nindex, CallFuncN * callback)
{
	switch (nindex)
	{
	case ActionCombination::Shake:
		node->setAnchorPoint(Vec2(0.5, 0.5));
		break;
	case ActionCombination::Rock:
		break;
	case ActionCombination::Postmark:
	{
		node->setAnchorPoint(Vec2(0.5, 0.5));
		node->setOpacity(30);
		node->setScale(2.0);
	}
	break;
	case ActionCombination::Pop:
	{
		node->setAnchorPoint(Vec2(0.5, 0.5));
		node->setScale(0.01);
	}
	break;
	case ActionCombination::PopIn:
	{
		node->setAnchorPoint(Vec2(0.5, 0.5));
	}
	break;
	case ActionCombination::CFadeOut:
	{
		node->setAnchorPoint(Vec2(0.5, 0.5));
		node->setOpacity(255);
	}
	break;
	case ActionCombination::CFadeIn:
	{
		node->setAnchorPoint(Vec2(0.5, 0.5));
		node->setOpacity(0.0);
	}
	break;
	case ActionCombination::Shock:
	{
		//node->setAnchorPoint(Vec2(0.5, 0.5));
	}
	break;
	default:
		break;
	}

	auto action = GetActionByIndex(nindex);
	
	if (callback)
	{
		node->runAction(Sequence::create(action, callback, nullptr));
	}
	else
	{
		node->runAction(action);
	}
	return action->getDuration();
}
ActionInterval *UiManager::GetActionByIndex(ActionCombination nindex)
{
	ActionInterval* action = nullptr;
	switch (nindex)
	{
	case ActionCombination::Shake:
		{
			auto nRotate1 = RotateTo::create(0.05, 10);
			auto nRotate2 = RotateTo::create(0.05, 0);
			auto nRotate3 = RotateTo::create(0.05, -10);
			auto nRotate4 = RotateTo::create(0.05, 0);
			auto nSeq = Sequence::create(nRotate1, nRotate2, nRotate3, nRotate4, NULL);
			action = Repeat::create(nSeq, 3);
		}
		break;
	case ActionCombination::Rock:
		{
			auto nMove1 = MoveBy::create(0.05, Vec2(-20, 0));
			auto nMove2 = MoveBy::create(0.05, Vec2(20, 0));
			auto nMove3 = MoveBy::create(0.05, Vec2(20, 0));
			auto nMove4 = MoveBy::create(0.05, Vec2(-20, 0));
			auto nSeq = Sequence::create(nMove1, nMove2, nMove3, nMove4, NULL);
			action = Repeat::create(nSeq, 2);
		}
		break;
	case ActionCombination::Postmark:
		{
			auto nfade = FadeIn::create(0.2);
			auto nscale = ScaleTo::create(0.2, 1.0);
			auto nspawn = Spawn::create(nfade, nscale, nullptr);
			action = EaseCircleActionIn::create(nspawn);
		}
		break;
	case ActionCombination::Pop:
	{
		action = EaseBackInOut::create(ScaleTo::create(0.2, 1.0));
	}
	break;
	case ActionCombination::PopIn:
	{
		action = EaseBackInOut::create(ScaleTo::create(0.2, 0.1));
	}
	break;
	case ActionCombination::CFadeOut:
	{
		action = FadeOut::create(0.2);
	}
	break;
	case ActionCombination::CFadeIn:
	{
		action = FadeIn::create(0.2);
	}
	break;
	case ActionCombination::Shock:
	{
		/*int nmindis = 1;
		int nmaxdis = 5;
		int x = CommonMethod::getRand(nmindis, nmaxdis);
		int y = CommonMethod::getRand(nmindis, nmaxdis);
		auto nmove1 = MoveBy::create(0.05, Vec2(x, y));
		auto nmove2 = MoveBy::create(0.05, Vec2(-x, -y));
		x = CommonMethod::getRand(nmindis, nmaxdis);
		y = CommonMethod::getRand(nmindis, nmaxdis);
		auto nmove3 = MoveBy::create(0.05, Vec2(x, y));
		auto nmove4 = MoveBy::create(0.05, Vec2(-x, -y));
		x = CommonMethod::getRand(nmindis, nmaxdis);
		y = CommonMethod::getRand(nmindis, nmaxdis);
		auto nmove5 = MoveBy::create(0.05, Vec2(x, y));
		auto nmove6 = MoveBy::create(0.05, Vec2(-x, -y));
		auto nSeq = Sequence::create(nmove1, nmove2, nmove3, nmove4, nmove5, nmove6, NULL);
		action = nSeq;*/
	}
	break;
	default:
		break;
	}
	return action;
}
void UiManager::PlayAnimation(Node* node,const std::string& filepath,const std::string& animateName,float delay,int times)
{
    if (times==0)
    {
        return;
    }
    ActionTimeline* nanimation = CSLoader::createTimeline(filepath);
    node->runAction(nanimation);
    if (times <= -1)
    {
        times= -1;
    }
    
    nanimation->play(animateName, false);
    nanimation->setLastFrameCallFunc([=](){
        node->runAction(Sequence::create(
                            DelayTime::create(delay),
                            CallFuncN::create([=](Node *node){
                                PlayAnimation(node,filepath,animateName,delay,times-1);
                            }),
                            nullptr));
    });
    
    
    
}
Node* UiManager::GetChildByName(Node* root, const std::string& widgetname)
{
    
		if (!root || widgetname == "")
		{
			return nullptr;
		}
		for (auto node : root->getChildren())
		{
			const std::string nstr = node->getName();
			if (nstr != "" && nstr == widgetname)
			{
				return node;
			}
			auto childnode = GetChildByName(node, widgetname);
			if (childnode)
			{
				return childnode;
			}
			
		}
		return nullptr;
}

Node* UiManager::GetChildByPath(Node* root, const std::string& path)
{

	std::vector<std::string> vec = StringUtil::split(path, "/");

	Node* node = nullptr;

	for (auto str : vec)
	{
		if (node == nullptr){
			node = root->getChildByName(str);
			if (node == nullptr)break;
		}
		else{
			node = node->getChildByName(str);
			if (node == nullptr)break;
		}
	}

	return node;
}

Node *  UiManager::ShowUI(const std::string& filepath, ValueVector vec, CloseType closetype )
{
	auto nscene = Director::getInstance()->getRunningScene();
	auto nrootlayer = nscene->getChildByName("rootlayer");
	Node * rootNode = nullptr;
	if (nrootlayer)
	{
		//���ñ���
		auto clickedpanel = Layout::create();
		clickedpanel->setTouchEnabled(true);
		clickedpanel->setBackGroundColorType(Layout::BackGroundColorType::SOLID);
		clickedpanel->setBackGroundColor(Color3B(0,0,0));
		clickedpanel->setContentSize(Size(DesignWidth, DesignHeight));
		clickedpanel->setOpacity(0);
		if (closetype == Auto_Close)
		{
			clickedpanel->runAction(Sequence::create(FadeTo::create(0.1, 255 * 0.6),
				DelayTime::create(2.0),
				CallFuncN::create([=](Node *node){
				auto rootNode = node->getChildByName("rootNode");
				rootNode->runAction(EaseBackInOut::create(ScaleTo::create(0.2, 0.01)));
			}),
				DelayTime::create(0.15),
				CallFuncN::create([=](Node *node){
                auto rootNode = node->getChildByName("rootNode");
                auto classnode = static_cast<BaseView*>(rootNode->getChildByName("SelfClass"));
                classnode->CloseCallBack();
                
				node->removeFromParent();
				m_nUiVectors.popBack();
			}),
				nullptr));
		}
		else
		{
			clickedpanel->runAction(FadeTo::create(0.1, 255 * 0.6));
		}
		clickedpanel->addClickEventListener([=](Ref* sender) {
			//Layout* npanel = static_cast<Layout*>(sender);
			if (closetype == BackGround_Close)
			{
				UiManager::CloseUI();
			}
		});
		
        rootNode = createUi(filepath,vec);//CSLoader::createNode(filepath);
		rootNode->setName("rootNode");
		rootNode->setAnchorPoint(Vec2(0.5, 0.5));
		rootNode->setPosition(Vec2(DesignWidth / 2.0, DesignHeight / 2.0));
		clickedpanel->addChild(rootNode);
		rootNode->setScale(0.01);
		rootNode->runAction(
			Sequence::create(
			EaseBackInOut::create(ScaleTo::create(0.2, 1.0)),
			CallFuncN::create([=](Node *node){
			auto classnode = static_cast<BaseView*>(node->getChildByName("SelfClass"));
			classnode->ShowCallback();
		}),
			nullptr));


		nrootlayer->addChild(clickedpanel);
		m_nUiVectors.pushBack(clickedpanel);
		//ui������ѭ�����ȳ�ԭ��
		m_nUiMap.insert(map<std::string, cocos2d::Value>::value_type(StringUtils::format("%d", m_nUiVectors.size()), cocos2d::Value(filepath)));
	}
	return rootNode;
}

BaseDialog* UiManager::ShowUI(const std::string& filepath, bool push /*= true*/)
{
	return DialogHelper::ShowUI(filepath, push);
}

BaseDialog* UiManager::ShowUI(const std::string& filepath, Ref* param, bool push /*= true*/)
{
	return DialogHelper::ShowUI(filepath, param, push);
}


Node * UiManager::ShowUIWithEffect(const std::string& filepath, ValueVector vec, CloseType closetype, UiEffectType effecttpye, ValueVector effectvec)
{
	auto nscene = Director::getInstance()->getRunningScene();
	auto nrootlayer = nscene->getChildByName("rootlayer");
	Node * rootNode = nullptr;
	Node *effectNode = nullptr;
	if (nrootlayer)
	{
		//���ñ���
		auto clickedpanel = Layout::create();
		clickedpanel->setTouchEnabled(true);
		clickedpanel->setBackGroundColorType(Layout::BackGroundColorType::SOLID);
		clickedpanel->setBackGroundColor(Color3B(0, 0, 0));
		clickedpanel->setContentSize(Size(DesignWidth, DesignHeight));
		clickedpanel->setOpacity(0);
		
		
		clickedpanel->runAction(FadeTo::create(0.1, 255 * 0.6));
		//������Ч�ڵ�
		effectNode = createEffectUi(effecttpye, effectvec);
		if (effectNode)
		{
			effectNode->setName("effectNode");
			effectNode->setAnchorPoint(Vec2(0, 0));
			effectNode->setPosition(Vec2(0, 0));
		}
		
		//����UI�ڵ�
		rootNode = createUi(filepath, vec);//CSLoader::createNode(filepath);
		if (!rootNode)
		{
			return nullptr;
		}
		
		rootNode->setName("rootNode");
		rootNode->setAnchorPoint(Vec2(0.5, 0.5));
		rootNode->setPosition(Vec2(DesignWidth / 2.0, DesignHeight / 2.0));

		clickedpanel->addChild(rootNode);
		if (effectNode)
		{
			clickedpanel->addChild(effectNode);
		}
		
		
		//ִ�ж���
		//��Ч��ִ�ж���
		float ndelay = 0;
		if (effectNode)
		{
			auto classnode = static_cast<BaseView*>(effectNode->getChildByName("EffectClass"));
			 ndelay = classnode->activeAction();
		}
		//UI����ִ�ж���
		rootNode->setScale(0.01);
		rootNode->setOpacity(0);
		rootNode->runAction(Sequence::create(
			DelayTime::create(ndelay),
			CallFuncN::create([=](Node *node){
			node->setOpacity(255);
		}),
			EaseBackInOut::create(ScaleTo::create(0.2, 1.0)),
			CallFuncN::create([=](Node *node){
			auto classnode = static_cast<BaseView*>(node->getChildByName("SelfClass"));
			classnode->ShowCallback();
				float ndelay = classnode->activeAction();

				if (closetype == Auto_Close)
				{
					clickedpanel->runAction(Sequence::create(
						DelayTime::create(ndelay+1.3),
						CallFuncN::create([=](Node *node){
						UiManager::CloseUI();
					}),
						nullptr));
				}
				else if (closetype == BackGround_Close)
				{
					clickedpanel->runAction(Sequence::create(
						DelayTime::create(ndelay + 1.3),
						CallFuncN::create([=](Node *node){
						clickedpanel->addClickEventListener([=](Ref* sender) {
							UiManager::CloseUI();
						});
					}),
						nullptr));	
				}
		}),
			nullptr
			));

		nrootlayer->addChild(clickedpanel);
		m_nUiVectors.pushBack(clickedpanel);
		//ui������ѭ�����ȳ�ԭ��
		m_nUiMap.insert(map<std::string, cocos2d::Value>::value_type(StringUtils::format("%d", m_nUiVectors.size()), cocos2d::Value(filepath)));

	}
	return rootNode;
}
Node * UiManager::createUi(const std::string& filepath,ValueVector vec)
{
    if (filepath=="GameScene/ResultView.csb")
    {
		return ResultView::createWithVec(vec);
    }
    else if(filepath =="GameScene/ScoreView.csb")
    {
		return ScoreView::createWithVec(vec);
    }
	else if(filepath =="GameScene/StatisticsView.csb")
    {
		return StatisticsView::createWithVec(vec);
    }
	 else if(filepath =="GameScene/FaultView.csb")
    {
        return FaultView::createWithVec(vec);
    }
	/*else if (filepath == "VideoView/VideoView.csb")
	{
		return VideoView::createWithVec(vec);
	}
	else if (filepath == "UnLockShop/UnLockShop.csb")
	{
		return UnLockShop::createWithVec(vec);
	}
    else if(filepath =="TargetPrompt/TargetPrompt.csb")
    {
        return TargetPrompt::createWithVec(vec);
    }
    else if(filepath =="SettlementView/SettlementView.csb")
    {
        return SettlementView::createWithVec(vec);
    }
	else if (filepath == "ShopMenu/ShopMenu.csb")
	{
		return ShopMenu::createWithVec(vec);
	}
	else if (filepath == "UpGradePrompt/UpGradePrompt.csb")
	{
		return UpGradePrompt::createWithVec(vec);
	}
	else if (filepath == "Evaluate/Evaluate.csb")
	{
		return Evalute::createWithVec(vec);
	}*/
    
    return nullptr;
}
Node * UiManager::createEffectUi(UiEffectType effecttpye, ValueVector vec)
{
	if (effecttpye == UiEffectType::Normal_Show)
	{
		return nullptr;
	}
	else if (effecttpye == UiEffectType::Horn_Show)
	{
		//return HornRibbon::createWithVec(vec);
	}
	return nullptr;
	
}
void UiManager::setBMFontValue(Widget * label, string key, string addstr)
{
	if (key=="")
	{
		return;
	}
	
	/*auto ndatamap = DataManager::shareDataManager()->getTextDescMapByStrKey(key);
	if (ndatamap)
	{
		string nlanguagekey = GlobalData::shareGlobalData()->getcurLanguage();
		auto nstrdescri =  ndatamap->at(nlanguagekey.c_str()).asString();
		auto ntypestr = ndatamap->at("Type").asString();
		if (ntypestr == "title" || ntypestr == "label")
		{
			auto nBMlabel = static_cast<TextBMFont*>(label);
			nBMlabel->setFntFile(StringUtils::format("%s.fnt", ntypestr.c_str()));
			nBMlabel->setString(nstrdescri + addstr);
		}
		else if (ntypestr=="describe")
		{
			auto nttflabel = static_cast<Text*>(label);
			nttflabel->setFontName(StringUtils::format("%s.ttf", ntypestr.c_str()));
			nttflabel->setString(nstrdescri + addstr);
		}
		
	}*/
	
	
}
void UiManager::LockScreen()
{
    auto nscene = Director::getInstance()->getRunningScene();
    auto nrootlayer = nscene->getChildByName("rootlayer");
    auto nLockPanel = nrootlayer->getChildByName("LockPanel");
    if (nLockPanel)
    {
        return;
    }
    auto nLockpanel = Layout::create();
    nLockpanel->setTouchEnabled(true);
    nLockpanel->setContentSize(Size(DesignWidth, DesignHeight));
    nLockpanel->setName("LockPanel");
    nrootlayer->addChild(nLockpanel);
    
}
void UiManager::UnLockScreen()
{
    auto nscene = Director::getInstance()->getRunningScene();
    auto nrootlayer = nscene->getChildByName("rootlayer");
    auto nLockPanel = nrootlayer->getChildByName("LockPanel");
    if (nLockPanel)
    {
        nLockPanel->removeFromParent();
    }
    
    
}
void UiManager::CloseUI(float delay)
{
	int nsize = m_nUiVectors.size();
	if (nsize<=0)
	{
		m_nUiMap.clear();
		return;
	}
	
	auto clickedpanel =  m_nUiVectors.at(nsize - 1);
	auto effectNode = clickedpanel->getChildByName("effectNode");
	float ndelytime = 0;
	if (effectNode)
	{
		auto effectclassnode = static_cast<BaseView*>(effectNode->getChildByName("EffectClass"));
		ndelytime += effectclassnode->closeAction();
	}

	auto rootNode = clickedpanel->getChildByName("rootNode");
	auto uiclassnode = static_cast<BaseView*>(rootNode->getChildByName("SelfClass"));
	ndelytime += uiclassnode->closeAction();

	rootNode->runAction(Sequence::create(DelayTime::create(ndelytime+delay),
		EaseBackInOut::create(ScaleTo::create(0.2, 0.01)),nullptr));

	clickedpanel->runAction(Sequence::create(DelayTime::create(ndelytime + delay),
		FadeTo::create(0.2, 0.0),
		CallFuncN::create([=](Node *node){
        auto rootNode = node->getChildByName("rootNode");
        auto classnode = static_cast<BaseView*>(rootNode->getChildByName("SelfClass"));
        classnode->CloseCallBack();
		node->removeFromParent();
		int keyindex = m_nUiVectors.size();
		m_nUiVectors.popBack();
		//ui������ѭ�����ȳ�ԭ��
		auto nitem = m_nUiMap.find(StringUtils::format("%d", keyindex));
		if (m_nUiMap.end() != nitem)
		{
			m_nUiMap.erase(nitem);
		}
		if (m_nUiVectors.empty())
		{
			m_nUiMap.clear();
		}
		
		}),
		nullptr));
}

BaseDialog* UiManager::CloseUI(const std::string& filepath)
{
	return DialogHelper::CloseUI(filepath);
}

BaseDialog* UiManager::CloseUI(BaseDialog* dialog)
{
	return DialogHelper::CloseUI(dialog);
}

// BaseDialog* UiManager::CloseUI()
// {
// 	DialogHelper::CloseUI();
// }



bool UiManager::EscCloseUI()
{
	int nsize = m_nUiVectors.size();
	if (nsize <= 0)
	{
		m_nUiMap.clear();
		return false;
	}
	for (auto nitem : m_nUiMap)
	{
		
		auto nstr = nitem.second.asString();
		CCLOG("EscCloseUI = %s",nstr.c_str());
		if (nstr == "SetView/SetView.csb")
		{
			UiManager::CloseUI();
			return true;
		}
		else if (nstr == "Achieve/AchieveView.csb")
		{
			UiManager::CloseUI();
			return true;
		}
		else if (nstr == "SignView/SignView.csb")
		{
			
		}
		else if (nstr == "ChargeShop/ChargeShopView.csb")
		{
			UiManager::CloseUI();
			return true;
		}
		else if (nstr == "VideoView/VideoView.csb")
		{
			
		}
		else if (nstr == "UnLockShop/UnLockShop.csb")
		{
			
		}
		else if (nstr == "TargetPrompt/TargetPrompt.csb")
		{
			
		}
		else if (nstr == "SettlementView/SettlementView.csb")
		{
			
		}
		else if (nstr == "ShopMenu/ShopMenu.csb")
		{
			UiManager::CloseUI();
			return true;
		}
		else if (nstr == "UpGradePrompt/UpGradePrompt.csb")
		{
			
		}
		else if (nstr == "Evaluate/Evaluate.csb")
		{
			
		}
	}
	
	return false;
}

void UiManager::ShowGuidebyStep(int mainstep, int substep)
{
	/*int nmainstep = GlobalData::shareGlobalData()->mainstep;
	if (mainstep != -1)
	{
		nmainstep = mainstep;
	}
	int nsubstep = GlobalData::shareGlobalData()->substep;
	if (substep != -1)
	{
		nsubstep = substep;
	}
	auto nscene = Director::sharedDirector()->getRunningScene();
	auto nguidelayer = nscene->getChildByName("guidelayer");
	if (nguidelayer)
	{
		nguidelayer->removeFromParent();
	}
	ValueMap *nguidemap = DataManager::shareDataManager()->getGuideDataByStep(nmainstep);
	if (nguidemap)
	{
		nguidelayer = GuideLayer::createWithStep(nmainstep, nsubstep);
		if (nguidelayer)
		{
			nguidelayer->setName("guidelayer");
			nscene->addChild(nguidelayer);
		}
	}*/
}
void UiManager::CloseGuide()
{
	auto nscene = Director::sharedDirector()->getRunningScene();
	auto nguidelayer = nscene->getChildByName("guidelayer");
	if (nguidelayer)
	{
		nguidelayer->removeFromParent();
	}
}
 void UiManager::clearUI()
{
	m_nUiVectors.clear();
	m_nUiMap.clear();
}

 bool UiManager::onKeyBack()
 {
	 return DialogHelper::onKeyBack();
 }

 bool UiManager::adaptScreen(Node * node, c2d::Align align)
 {

	 Vec2 point = node->getPosition();
	 Size size = node->getBoundingBox().size;
	 auto _ResolutionPolicy = Director::getInstance()->getOpenGLView()->getResolutionPolicy();
	 if (_ResolutionPolicy == ResolutionPolicy::NO_BORDER){
		 Size designResolutionSize = Director::getInstance()->getOpenGLView()->getDesignResolutionSize();

		 switch (align)
		 {
		 case Align::left:
			 node->setPosition(Vec2(VisibleRect::left().x + point.x, point.y));
			 break;
		 case Align::right:
			 node->setPosition(Vec2(VisibleRect::right().x - (designResolutionSize.width - point.x), point.y));
			 break;
		 case Align::top:
			 node->setPosition(Vec2(point.x, VisibleRect::top().y - (designResolutionSize.height - point.y)));
			 break;
		 case Align::bottom:
			 node->setPosition(Vec2(point.x, VisibleRect::bottom().y + point.y));
			 break;
		 case Align::center:
			 break;
		 case Align::topLeft:
			 break;
		 case Align::topRight:
			 break;
		 case Align::bottomLeft:
			 break;
		 case Align::bottomRight:
			 break;
		 default:
			 break;
		 }
	 }
	 
	 return true;
 }

 bool UiManager::adaptScreen(Node * node)
 {
	 auto _designSize = Size(1536,768);
	 auto pos = node->getPosition();
	 if (pos.x < _designSize.width / 2){
		 return adaptScreen(node, Align::left);
	 }
	 else if (pos.x > _designSize.width / 2){
		 return adaptScreen(node, Align::right);
	 }
	 return false;
 }

 void UiManager::adaptScreen(Node* root, const std::string& childPath, c2d::Align align /*= c2d::Align::center*/)
 {
	 Node* node = GetChildByPath(root, childPath);
	 if (align == c2d::Align::center){
		 UiManager::adaptScreen(node);
	 }
	 else{
		 UiManager::adaptScreen(node, align);
	 }
 }

 void UiManager::adaptScreenChildren(Node*root, const std::string& rootPath, c2d::Align align /*= c2d::Align::center*/)
 {
	 Node* node = GetChildByPath(node, rootPath);
	 for (auto child : node->getChildren())
	 {
		 if (align == c2d::Align::center){
			 UiManager::adaptScreen(child);
		 }
		 else{
			 UiManager::adaptScreen(child, align);
		 }
	 }
 }
