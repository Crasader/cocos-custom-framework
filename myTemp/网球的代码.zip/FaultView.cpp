#include "FaultView.h"
#include "EventMacro.h"
Node* FaultView::createWithVec(ValueVector vec)
{
    Node *nrootnode = CSLoader::createNode("GameScene/FaultView.csb");
	FaultView *node = new (std::nothrow) FaultView();
	if (node &&  node->initwithWithVec(nrootnode, vec))
	{
		node->setName("SelfClass");
		nrootnode->addChild(node);
		node->autorelease();
		return nrootnode;
	}
	else
	{
		delete node;
		node = nullptr;
		return nullptr;
	}
}
bool FaultView::initwithWithVec(Node *node, ValueVector vec)
{
    m_nrootnode = node;
	m_nFault_Text = static_cast<Text*>(UiManager::GetChildByName(m_nrootnode, "Fault_Text"));
	m_nFault_Text->setText("Fault"); 
	setUpUIWithData();
    return true;
}
void FaultView::setUpUIWithData()
{
	
}
float FaultView::activeAction()
{
	
	return 0;
}
void FaultView::ShowCallback()
{

}
void FaultView::onEnter()
{

}
void FaultView::onEnterTransitionDidFinish()
{
	
}
void FaultView::onExitTransitionDidStart()
{

}
void FaultView::onExit()
{

}
void FaultView::cleanup()
{

}
void FaultView::CloseCallBack()
{
	EventCustom event(Event_FaultViewClose);
	_eventDispatcher->dispatchEvent(&event);
}